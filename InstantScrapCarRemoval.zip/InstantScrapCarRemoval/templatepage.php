<html lang="en">

<head>
    <title> </title><!--title here-->
    <!--head----->
    <?php include'php/head.php'?>

</head>

<body>
    <!--header----->
    <?php include'php/header.php'?>
    <!--navigation----->
    <?php include'php/navigation.php'?>
    <!---Page Header---->
    <div class="container-fluid header service-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h4>   </h4> <!--heading here-->
                </div>
            </div>
        </div>
    </div>


    <!---Content Section For Contact us Page---->
    <div class="container margin-tb">
        <div class="row">
            <div class="col-md-8 col-sm-12 contact-content"> 
                <!----paragraph------>
                <p>
                
                </p>
                
                <p>
                    
                </p>
                <!---Heading------>
                <h4>Cash for junk cars</h4>
                <!----paragraph------>
                <p>
                    
                </p>
                <!---Image Content----->
                <p>
                    <img class="content-img" src="img/services/" alt="" title="">
                </p>
                <!---Heading------>
                <h4> </h4>
                <!----paragraph------>
                <p>
                   

                </p>


            </div>
            <div class="col-md-4 col-sm-12 contact-form">
                <?php include "php/form.php"?>
                <!---Reveiw Section---->
                <?php include'php/services-Review.php'?>
            </div>
        </div>
    </div>
    <!---Map Section---->
    <div class="container">
        <div class="row">
            <div class="col-md-12 map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d990653.2672887635!2d-80.24848684983473!3d43.65583373221037!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b3760d44c33c5%3A0x59e9c8bf2149d577!2sEtobicoke%2C+Toronto%2C+ON%2C+Canada!5e0!3m2!1sen!2s!4v1558776150303!5m2!1sen!2s" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>

    <!--footer----->
    <?php include'php/footer.php'?>
</body>

</html>