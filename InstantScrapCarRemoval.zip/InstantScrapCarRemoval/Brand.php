<html lang="en">

<head>
    <title>Brand - Instant Scrap Car Removal Etobicoke UpTo $666 A</title>
    <!--head----->
    <?php include'php/head.php'?>

</head>

<body>
    <!--header----->
    <?php include'php/header.php'?>
    <!--navigation----->
    <?php include'php/navigation.php'?>
    <!---Page Header---->
    <div class="container-fluid header service-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h4>Brand</h4>
                </div>
            </div>
        </div>
    </div>
    <!---Content Section For Contact us Page---->
    <div class="container margin-tb">
        <div class="row">
            <div class="col-md-8 col-sm-12 contact-content">
                <h4>Car Brands</h4>
                <div class="brand">
                    <div class="mzr-content">
                        <ul class="spcl splitng">
                            <li>Suzuki</li>
                            <li>SAAB</li>
                            <li>Oldsmobile</li>
                            <li>Kia</li>
                            <li>Hyundai</li>
                            <li>Mercury</li>
                            <li>Mazda</li>
                            <li>Jeep</li>
                            <li>GMC</li>
                            <li>Lincoln</li>
                            <li>Daewoo</li>
                            <li>Isuzu</li>
                            <li>Toyota</li>
                            <li>RAM</li>
                            <li>Nissan</li>
                            <li>Mercury</li>
                            <li>Hummer</li>
                            <li>Subaru</li>
                            <li>GEO</li>
                            <li>Chevy</li>
                            <li>Plymouth</li>
                            <li>Proton</li>
                            <li>Honda</li>
                            <li>Mercedes-Benz</li>
                            <li>Ford</li>
                            <li>BMW</li>
                            <li>Alfa Romeo</li>
                            <li>Austin Martin</li>
                            <li>Buick</li>
                            <li>Holden</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 brand-form">
                <?php include "php/form.php"?>
            </div>
        </div>
        <!---Second Row--->
        <div class="row">
            <div class="col-md-8 col-sm-12 contact-content">
                <h4>Truck Brands</h4>
                <div class="brand">
                    <div class="mzr-content">
                        <ul class="spcl splitng"> 
                            <li>Isuzu</li>
                            <li>Volvo</li>
                            <li>Kenworth</li>
                            <li>Mack</li>
                            <li>Scania</li> 
                            <li>Mercedes-Benz Truck</li>
                            <li>Freightliner</li>
                            <li>Hino</li>
                            <li>DAF</li>
                            <li>Western Star</li>
                            <li>UD</li>
                            <li>Cat Trucks</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!---Car Brands Image---->
            <div class="col-md-4 col-sm-12 brand-img">
                <img src="img/Instant-scrap-car-removal-mississuaga-car-brands.jpg" alt="Instant-scrap-car-removal-mississuaga-car-brands" title="Instant-scrap-car-removal-mississuaga-car-brands">
            </div>
        </div>
    </div>
    <!---Content Section 2---->
    <div class="container margin-tb">
        <div class="row">
            <div class="col-md-12">
                <?php include'php/Rview.php' ?>
            </div>
        </div>
    </div>
    <!--footer----->
    <?php include'php/footer.php'?>
</body>

</html>