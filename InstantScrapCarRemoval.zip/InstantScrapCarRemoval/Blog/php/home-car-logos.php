 
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-xs-12 col-lg-12 col-sm-12 _section-white text-center">
                <img src="img/Instant-scrap-car-removal-mississuaga-car-logos.jpg" alt="Instant Scrap Car removal Onatrio" title="Car Scrapper Mississauga">
            </div>
        </div>
    </div>
 


<style>
._section-white {
    background-color: #fff;
     
     margin: 20px auto;
}
    ._section-white img
    {
        max-width: 100%;
    }


</style>