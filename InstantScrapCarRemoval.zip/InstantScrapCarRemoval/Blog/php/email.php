<?php
$errors = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$myemail = 'carclunker@gmail.com';//<-----Put Your email address here.
	if(empty($_POST['name'])  || empty($_POST['phone']) ||	empty($_POST['email']) ||	empty($_POST['message']))
		{
			$errors = "Error: all fields are required";
		}
		$name = $_POST['name'];
		$email_address = $_POST['email'];
		$phone = $_POST['phone'];
	    $address=$_POST['address'];
		$message = $_POST['message'];
		 
		if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",$email_address))
		{
			$errors = "Error: Invalid email address";
		}

		if( empty($errors))
		{
		$to = $myemail;
		$email_subject = "Instant Scrap Car Removal Etobicoke\n";
		$email_body = "Message From: $name\n".  
		"Phone: $phone\nAddress: $address\n".
		"Email: $email_address\nMessage:\n$message";
		$headers = "From: $name \n";
		$headers .= "Reply-To: $email_address";
		if( mail($to,$email_subject,$email_body,$headers) )
		{
			$errors = "yes";
		}
		else
		{
			$errors = "Sorry, there has been an error!!";
		}
	}
	echo $errors;
}
else{
echo "<h2>Access Denied</h2>";
}
?>