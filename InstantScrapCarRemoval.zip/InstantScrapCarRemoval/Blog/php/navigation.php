<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="../index" title="Home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../Brand" title="Our Top Car Brands">Brand</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../company" title="Company">Company</a>
                </li>


                <!--Drop Down List--->
                <li class="nav-item dropdown"><a href="../services" title="We provide top Services">Services</a>
                    <!--div class="DivId"> </div-->
                    <div class="dropdown-menu hide">
                        <a href="../scrap-car-removal-Toronto" title="Scrap Car Removal Toronto">Scrap Car Removal Toronto</a>
                        <a href="../junk-car-removal-brampton" title="Junk Car Removal Brampton">Junk Car Removal Brampton</a>
                        <a href="../Sell-My-Used-Car" title="sell my Used car toronto">Sell My Used Car Toronto</a>
                        
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="../contact_us" title="Contact Us" title="Contact With Us">Contact Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../blog_posts" title="Blog">Blog</a> 
                </li>
                 
            </ul>
        </div>
    </div>
</nav>