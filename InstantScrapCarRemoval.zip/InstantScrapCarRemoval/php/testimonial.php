<div class="container-fluid R-bg well">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 text-center">
                <h4 class="text-center R-head">Testimonials</h4>
                <div class="carousel slide " data-ride="carousel" data-interval="2000">
                    <div class="carousel-inner">
                        <div class="carousel-item active Review-content">
                            <p>When I called Instant Scrap Car Removal Toronto to get my old car disposed of, I never assumed I would take any great amount of money from them. But instant car scrapper was the soundest deal I got! I made the top cash arrangement from them, & they are extraordinarily very active in their service.<img draggable="false" class="emoji" alt="🙂" src="img/imo.svg"><span>David Milly</span></p> 
                        </div> 
                        <div class="carousel-item Review-content">
                            <p>Instant Scrap Car Removal Toronto is absolutely the most experienced scrap car removal service in Etobicoke, Mississauga, Ontario and in Toronto. I just profited from their service, & I’m completely satisfied with their quick service. Instant Car Scrappers are really professional in the industry.<span>Michael Johnson</span></p> 
                        </div> 
                        <div class="carousel-item Review-content">
                            <p>when I needed to dispose of my dead vehicle as it was defective beyond repair. Someone suggested me Instant Scrap Car Removal Etobicoke, and I just call them. Their service was Quick and trustworthy! Not only did they buy my Junk Car, Even gave me very fair cash for that!<span>Ronald Waston</span></p> 
                        </div> 
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>