<div class="container-fluid banr">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 bannInn">
                <div class="bannStrip">
                    <h2>WELCOME to Instant Scrap Car Removal Toronto</h2> 
                    
                    <p>Let us pay you cash for your junk car near me. We offer top dollar cash on the spot for all type of scrap/junk cars. </p> 
                     
                    <a class="enq-butn" title="Contact With Us" href="contact_us.php">sell scrap car</a>
                </div>
            </div>
            <div class="col-md-4 banner-form">
                <?php include 'form.php'?>

            </div>
        </div>
    </div>
</div>