 
    <div class="container margin-tb">
        <div class="row">
           <div class="col-sm-12">
               <h4>Our Free Scrap Car Removal Services In Toronto</h4>
           </div>
            <div class="col-md-12 text-center">
               
                <div class="owl-carousel home owl-theme">
                    <!--- Scrap Car Removal Toronto--->
                    <div class="">
                        <a href="scrap-car-removal-Toronto">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Instant-scrap-car-removal-Toronto.jpg" data-lazy-type="image" data-src="img/services/Instant-scrap-car-removal-Toronto.jpg" title="Scrap Car Removal Toronto" alt="Scrap Car Removal Toronto" width="264" height="175"><noscript><img src="img/services/Instant-scrap-car-removal-Toronto.jpg" title="Scrap Car Removal Toronto" alt="Cash For Unwanted Cars " width="264" height="175"></noscript></div>
                            <div class="sldTit">Scrap Car Removal</div>
                        </a>
                        <a href="scrap-car-removal-Toronto" title="Read More About Scrap Car Removal Toronto " class="rdmrs">Read More</a>
                    </div>
                    
                    
                    <!---Junk Car Removal Brampton--->
                    <div class="">
                        <a href="junk-car-removal-brampton">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/junk-car-removal-brampton.jpg" data-lazy-type="image" data-src="img/services/junk-car-removal-brampton.jpg" title="junk-car-removal-brampton" alt="junk-car-removal-brampton" width="264" height="175"><noscript><img src="img/services/junk-car-removal-brampton.jpg" alt="junk-car-removal-brampton" width="264" height="175"></noscript></div>
                            <div class="sldTit">Junk Car Removal Brampton</div>
                        </a>
                        <a href="junk-car-removal-brampton" title="Read More About Unwanted Car Removal " class="rdmrs">Read More</a>
                    </div>
                    
                    <!---Item Sell My Used Car--->
                    <div class="">
                        <a href="Sell-My-Used-Car">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Sell My Used Car.jpg" data-lazy-type="image" data-src="img/services/Sell My Used Car.jpg" title="Sell My Used Car" alt="Sell My Used Car" width="264" height="175"><noscript><img src="img/services/Sell My Used Car.jpg" alt="Sell My Used Car" width="264" height="175"></noscript></div>
                            <div class="sldTit">Sell My Used Car</div>
                        </a>
                        <a href="Sell-My-Used-Car" title="Read More About Sell My Used Car" class="rdmrs">Read More</a>
                    </div>
                    
                    
                    <!---Item Junk Car Removal--->
                    <div class="">
                        <a href="#">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Junk Car Removal.jpg" data-lazy-type="image" data-src="img/services/Junk Car Removal.jpg" title="Junk Car Removal" alt="Junk Car Removal" width="264" height="175"><noscript><img src="img/services/Junk Car Removal.jpg" alt="Junk Car Removal" width="264" height="175"></noscript></div>
                            <div class="sldTit">Junk Car Removal</div>
                        </a>
                        <a href="#" title="Read More About Junk Car Removal " class="rdmrs">Read More</a>
                    </div>
                    <!---Item Car Salvage Mississauga--->
                    <div class="">
                        <a href="#">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Car Salvage Mississauga.jpg" data-lazy-type="image" data-src="img/services/Car Salvage Mississauga.jpg" title="Car Salvage Mississauga" alt="Car Salvage Mississauga" width="264" height="175"><noscript><img src="img/services/Car Salvage Mississauga.jpg" alt="Car Salvage Mississauga" width="264" height="175"></noscript></div>
                            <div class="sldTit">Car Salvage Mississauga</div>
                        </a>
                        <a href="#" title="Read More About Car Salvage Mississauga " class="rdmrs">Read More</a>
                    </div>
                    <!---Item Recycle your car--->
                    <div class="">
                        <a href="#">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Recycle your car.jpg" data-lazy-type="image" data-src="img/services/Recycle your car.jpg" title="Recycle your car" alt="Recycle your car" width="264" height="175"><noscript><img src="img/services/Recycle your car.jpg" alt="Recycle your car" width="264" height="175"></noscript></div>
                            <div class="sldTit">Recycle your car</div>
                        </a>
                        <a href="#" title="Read More About Recycle your car " class="rdmrs">Read More</a>
                    </div>
                    <!---Item Auto Wreckers--->
                    <div class="">
                        <a href="#">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Auto Wreckers.jpg" data-lazy-type="image" data-src="img/services/Auto Wreckers.jpg" title="Auto Wreckers" alt="Auto Wreckers" width="264" height="175"><noscript><img src="img/services/Auto Wreckers.jpg" alt="Auto Wreckers" width="264" height="175"></noscript></div>
                            <div class="sldTit">Auto Wreckers</div>
                        </a>
                        <a href="#" title="Read More About Auto Wreckers " class="rdmrs">Read More</a>
                    </div>
                    <!---Item Towing Dead Cars--->
                    <div class="">
                        <a href="#">
                            <div class="dscrD"><img class="lazy-loaded" src="img/services/Towing Dead Cars.jpg" data-lazy-type="image" data-src="img/services/Towing Dead Cars.jpg" title="Towing Dead Cars" alt="Towing Dead Cars" width="264" height="175"><noscript><img src="img/services/Towing Dead Cars.jpg" alt="Towing Dead Cars" width="264" height="175"></noscript></div>
                            <div class="sldTit">Towing Dead Cars</div>
                        </a>
                        <a href="#" title="Read More About Towing Dead Cars " class="rdmrs">Read More</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
 