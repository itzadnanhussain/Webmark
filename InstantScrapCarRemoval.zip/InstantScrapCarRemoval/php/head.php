<!--Meta tags Here--->
<meta charset="utf-8">
<meta name="description" content="Instant Scrap Car Removal | Junk car Removal offers high-quality service in Toronto Wide removing your Used car, Unwanted car, Old car, scrap car, and Junk cars & pay top dollar cash for cars near me.">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0">
<!--Short cut Icon--->
<link rel="shortcut icon" type="img/jpeg" href="img/Instant-scrap-car-removal-Ontario-Brampton-logo.jpeg">
<!--Bootstrap Plugins Here--->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
<!--Load Css Files Here--->
<?php include "load_css.php"?> 
<link href="https://fonts.googleapis.com/css?family=Hind&display=swap" rel="stylesheet">

<!---------------------Google Analytics Code----------------------------------->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-143362753-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-143362753-1');
</script>


<!---------------------Facebook Open Graph Meta Tags----------------------------->
 <meta property="og:title" content="Instant Scrap Car Removal Mississauga|Ontario|Etobicoke"/>
 <meta property="og:type" content="image"/>
 <meta property="og:url" content="http://instantscrapcarremoval.com/"/>
 <meta property="og:image" content="http://instantscrapcarremoval.com/img/Instant-scrap-car-removal-mississauga-banner.jpg"/> 
 <meta property="og:description" content="Instant Scrap Car Removal offers high-quality service in Toronto Wide removing your Used car,Unwanted, Old, scrap  and Junk cars & paying top dollar cash for cars." />
 <meta property="og:site_name" content="Instant Scrap Car Removal Ontario"/>
 <!--meta property="og:locale" content="en_US" /--->