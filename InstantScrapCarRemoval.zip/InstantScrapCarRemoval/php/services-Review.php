<div class="container-fluid S-R-bg well">
    <div class="container">
        <div class="row ">
            <div class="col-md-12 col-sm-12 text-center">
                <h4 class="text-center S-R-head">Customer Reviews</h4>
                <div class="carousel slide " data-ride="carousel" data-interval="2000">
                    <div class="carousel-inner">
                        <div class="carousel-item active S-Review-content">
                            <p>When I called Scrap Car Removal Toronto to get my old car disposed of, I never assumed I would take any great amount of money from them. But junk car removal Toronto was the soundest deal I got! I made the top cash arrangement from them, & they are extraordinarily very active in their quick car recycling service.<img draggable="false" class="emoji" alt="🙂" src="img/imo.svg"><span>David Milly</span></p> 
                        </div> 
                        <div class="carousel-item S-Review-content">
                            <p>Instant Scrap Car Removal Toronto is absolutely the most experienced used car removal service in Toronto and its greater areas. I just profited from their car removal service, & I’m completely satisfied with their quick service. scrap car buyers in Toronto are really professional in the industry.<span>Michael Johnson</span></p> 
                        </div> 
                        <div class="carousel-item S-Review-content">
                            <p>when I needed to dispose off my old car as it was defective beyond repair. Someone suggested to me about old car removal Toronto, and I just call them. Their service was Quick and trustworthy! Not only did they buy my Junk Car, Even gave me very fair cash for that!<span>Ronald Waston</span></p> 
                        </div> 
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>