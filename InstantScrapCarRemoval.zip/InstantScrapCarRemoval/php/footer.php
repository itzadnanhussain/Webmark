<section class="primay_footer">
    <div class="container">
        <div class="row">
            <!--The Company----->
            <div class="col-md-4 text">
                <h4 class="">The Company</h4>
                <ul>
                    <li><a href="index" title="Home">Home</a></li>
                    <li><a href="company" title="Company">Company</a></li>
                     <li><a href="Brand" title="Our Brands">Brand</a></li> 
                   <li><a href="services" title="We provide top Services">Services</a></li>
                    <li><a href="contact_us" title="Contact with car Scrappers">Contact Us</a></li>
                    <li><a href="blog_posts" title="Blog">Blog</a></li>
                </ul>
            </div>
            <!--Services----->
            <div class="col-md-4 text">
                <h4 class="">Our Services</h4>
                <ul>
                    <li><a href="scrap-car-removal-Toronto" title="Scrap Car Removal Toronto">Scrap Car Removal Toronto</a></li>
                    <li><a href="junk-car-removal-brampton" title="Junk Car Removal Brampton">Junk Car Removal Brampton</a></li>
                     <li><a href="Sell-My-Used-Car" title="Sell My Used Car">Sell My Used Car Toronto</a></li>
                     
                        <li><a href="cash-for-scrap-cars-etobicoke" title="Cash for Scrap cars Etobicoke">Cash for Scrap Cars Etobicoke</a></li>
                        <li>
                        <a href="junk-car-removal-service-in-etobicoke" title="Junk Car Removal Service in Etobicoke">Junk Car Removal Service in Etobicoke</a>
                        </li>
                        <li>
                        <a href="instant-scrap-car-removal-near-me" title="Instant scrap car removal near me">Instant Scrap Car Removal Near me</a>
                        </li>
                     
                </ul>
            </div>
            <!--Contact Us----->
            <div class="col-md-4 text" id="contact">
                <h4>Contact Us</h4>
                <ul>
                    <li><strong itemprop="name">Instant Scrap Car Removal Located at: </strong>  <span>Etobicoke Toronto, ON, Canada
                        </span>
                    </li>
                    <li>Email: <a href="#" title="carclunker@gmail.com">carclunker@gmail.com</a></li>
                    <li>Telephone: <a href="#" title="647 484 7006" href="tel:647 484 7006">647 484 7006</a></li>
                    <li><strong>We Provide 24 Hours Canada Wide Service</strong></li>
                </ul>
            </div>
        </div>
        <!--------Second row----->
        <div class="row _pf-sub">
            <div class="col-md-8 col-sm-8 ">
                <p class="copyright">
                    © Copyright 2019 Scrap Car Removal Toronto– Top Cash For Cars Toronto and all surrounding areas. All Rights Reserved.
                </p>
            </div>
            <div class="col-md-4 col-sm-4 _pfs-links">
                <a title="Sitemap" href="#">Sitemap</a> | <a title="Contact Us" href="contact_us">Contact Us</a>
            </div>
        </div>
    </div>
</section>










<!--Js Plugins--->
<?php include'load_js.php'?>