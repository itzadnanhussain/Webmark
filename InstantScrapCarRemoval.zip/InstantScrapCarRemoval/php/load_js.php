<!--JQuery Plugins--->
<script src="js/jquery.min.js"></script>
<!--Js Plugins--->
<script src="js/bootstrap.min.js"></script> 
<!--Owl Carousel Plugins--->
<script src="js/owl.carousel.min.js"></script>
<!--Custom Plugins--->
<script src="js/custom.js"></script>
<!--SweetAlert Plugins--->
<script src="js/sweetalert.min.js"></script>