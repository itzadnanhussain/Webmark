<style>
    <?php
    include'css/header.min.css';
    include'css/style.min.css';
    include'css/banner.min.css';
    include'css/navigation.min.css'; 
    include'css/form.min.css'; 
    include'css/owl.carousel.min.css';
    include'css/owl.theme.default.min.css';
    include'css/home-owl-cerousel.min.css';
    include'css/footer.min.css';
    include'css/services.min.css';
    include'css/sweetalert.min.css';
    include'css/blog-post.min.css';
    include'css/Rview.min.css'; 
    include 'css/custom.css';
    ?>
</style>