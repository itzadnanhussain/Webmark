<div class="_primary-header">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-3 col-md-3 logo_alignment">
                <a href="index" title="Instant Scrap Car Removal Mississauga" class="_logo fixed-elemnt">
                    <img src="img/Instant-scrap-car-removal-Ontario-Brampton-logo.jpeg" alt="Instant-scrap-car-removal-Ontario" title="Instant-scrap-car-removal-Ontario"> 
                </a> 
            </div>
            <div class="col-md-5 col-lg-5">
                 <p class="_desc hidden-xs hidden-sm">Junk Scrap Car removal Toronto  &amp;<br>Cash for Cars Toronto <span>Upto $6000</span></p>
            </div>
            <div class="col-md-4 col-sm-12 col-lg-4 _ph-right">
                <div class="_call-us">Call Us Now <span>or</span> <a title="Get a Quote" href="contact_us">Get an instant Quote</a></div>
                <div class="_phone">
                    <a class="mobile" title="647 484 7006" href="tel:647 484 7006">647 484 7006  
                    </a>
                </div><!-- /._phone -->
            </div><!-- /.col-sm-7 -->
        </div>
    </div><!-- /.container -->
</div>