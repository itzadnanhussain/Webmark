/***********************Home Slider******************************/
$('.owl-Carousel').owlCarousel({
    loop:true,
    margin:10,
    items:4, 
    autoplay:true,
    autoplayTimeout:5000,
    nav:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
}) 
/***********************Email Coding******************************/
//sending mail message
$("#messageform").submit(function (event) {
	/* stop form from submitting normally */
	event.preventDefault();
	/* get some values from elements on the page: 
	 */
	var $form = $(this),
		$submit = $form.find('button[type="submit"]'),
		name_value = $form.find('input[name="name"]').val(),
		email_value = $form.find('input[name="email"]').val(),
		phone_value = $form.find('input[name="phone"]').val(),
		address_value = $form.find('input[name="address"]').val(),
		message_value = $form.find('textarea[name="message"]').val(),
		url = $form.attr('action'); /* Send the data using post */
	var posting = $.post(url, {
		name: name_value,
		email: email_value,
		phone: phone_value,
		address:address_value,
		message: message_value, 
	});
	posting.done(function (data) {
		if (data == 'yes') {
			(function () {
				swal("Mail Sent!!", "You will be contacted in 24 hours.", "success");
			})();
			$("#submitbtn").prop("disabled", true);
		} else {
			(function () {
				swal("Mail Not Sent!!", "Sorry, there has been an error!", "error")
			})();
		}
	});
});
