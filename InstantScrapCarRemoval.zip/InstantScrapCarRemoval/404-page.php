<html lang="en">

<head>
    <title>Page-Not-Found|scrap car removal Toronto</title>
    <!--head----->
    <?php include'php/head.php'?>

</head>

<body>
    <!--header----->
    <?php include'php/header.php'?>
    <!--navigation----->
    <?php include'php/navigation.php'?>
    <!---Page Header---->
    <div class="container-fluid header service-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h4>Page not found</h4>
                </div>
            </div>
        </div>
    </div>
    <!---Content Section For Contact us Page---->
    <div class="container margin-tb">
        <div class="row">
            <div class="col-md-8 col-sm-12 contact-content">
                <h4>Oops! Error 404 - Page Not Found</h4> 


            </div>
            <div class="col-md-4 col-sm-12 contact-form">
                <?php include "php/form.php"?>
            </div>
        </div>
    </div>
    <!---Content Section 2---->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
            </div>
        </div>
    </div>
    
    <!--footer----->
    <?php include'php/footer.php'?>
</body>

</html>