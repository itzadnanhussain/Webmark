<html lang="en">
<title>Faq----</title>

<head><?php include'php/head.php'?></head>

<body>
   
    <!------Open Header------>
    <?php include'php/header.php'?>
    <!------End Header------>
    <div class="banner_box services-banner">
        <div class="container">
            <div class="row"> <svg preserveAspectRatio="none" viewBox="0 0 600 250">
                    <polygon points="600,0 0,0 0,800" opacity="1"></polygon>
                </svg>
                <div class="col-sm-8 le_box ">
                    <div class="left_box">
                        <h1><span> WE PAY CASH </span> FOR CARS!</h1>
                        <p>Get up to $9999 Cash For Cars in Melbourne We’ll Buy Your Car, Ute, Van and Truck for the Right Price</p>
                    </div>
                </div>
                <div class="col-sm-4 out">
                    <div class="right_right">
                        <h6>Find Out How Much Your Car is Worth</h6>
                        <div role="form" class="wpcf7" id="wpcf7-f21-o1" lang="en-US" dir="ltr">
                            <div class="screen-reader-response"></div>
                            <form action="https://www.rapidcarremoval.com.au/faq/#wpcf7-f21-o1" method="post" class="wpcf7-form" novalidate="novalidate">
                                <div style="display: none;"> <input type="hidden" name="_wpcf7" value="21" /> <input type="hidden" name="_wpcf7_version" value="5.1.4" /> <input type="hidden" name="_wpcf7_locale" value="en_US" /> <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f21-o1" /> <input type="hidden" name="_wpcf7_container_post" value="0" /></div>
                                <div class="form-group"> <span class="wpcf7-form-control-wrap full-name"><input type="text" name="full-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required your" aria-required="true" aria-invalid="false" placeholder="Full Name*" /></span></div>
                                <div class="form-group"> <span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email your" aria-required="true" aria-invalid="false" placeholder="Email Address*" /></span></div>
                                <div class="form-group"> <span class="wpcf7-form-control-wrap phone"><input type="tel" name="phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel your" aria-required="true" aria-invalid="false" placeholder="Phone*" /></span></div>
                                <div class="form-group"> <span class="wpcf7-form-control-wrap make-model-year"><input type="text" name="make-model-year" value="" size="40" class="wpcf7-form-control wpcf7-text your" aria-invalid="false" placeholder="Make/Model/Year" /></span></div>
                                <div class="form-group"> <span class="wpcf7-form-control-wrap location-message"><textarea name="location-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea coment" aria-invalid="false" placeholder="Location/Message"></textarea></span></div>
                                <div class="form-group"> <input type="submit" value="Send Now" class="wpcf7-form-control wpcf7-submit btn" /></div>
                                <div class="wpcf7-response-output wpcf7-display-none"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cashfor-car cashfor-car-list faq-collapse">
        <div class="container">
            <h2>Frequently Asked Questions – <span> How We Buy Cars for Cash</span></h2>
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 1. I want to sell my car but still need it for a few days. Am I allowed to get a cash quote today and sell later </a></h4>
                    </div>
                    <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>Yes! You can get your valuation today here at Rapid Car Removal. We always value our customers so your convenience is always on top of our priorities. We can arrange the time you are most convenient to collect the car.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 2. Are my personal details safe with you? </a></h4>
                    </div>
                    <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>The information you provide to us, be it on your car and other personal details necessary in the transaction we made are confidential. Your details are safe with us. Rest assured that no third party will have any access to this information.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 3. Can I sell my car even when I owe some finance to it still? </a></h4>
                    </div>
                    <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>No! We don’t buy cars on finance, to sell your car on finance, first get the title cleared by clearing any dues. We only buy cars which are not financed.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 4. What kind of car do you buy? </a></h4>
                    </div>
                    <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>We buy all kinds of models and make. However, purchasing every vehicle presented to us is not guaranteed due to some circumstances such as major accidents, poor condition, stolen vehicles and other major reasons. With this, we ask that before you book n inspection from us, you must tell our staff if your car has a major issue that will affect the chances of it being purchased.v</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 5. Where can I sell my car? </a></h4>
                    </div>
                    <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>With us, selling your car will be easy, convenient and simple. We will be there with your and collect the car and deliver the payment at the same time.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 6. How can I sell my car? </a></h4>
                    </div>
                    <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>With Rapid Car Removal, selling your car for cash is simple. We ensure that we will meet your needs. With that, we make sure that our options are flexible. To sell your car, you can Call us at <a href="tel:0438942754">0438 942 754</a> Complete our <a href="https://www.designandrank.com/Proposal/rapidcarremoval/html/faq.html#">form online Contact us via email</a> and send details.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 7. Is there any fee or charge I need to think of? </a></h4>
                    </div>
                    <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>There are no extra or hidden charges for selling your car. We just offer the best cash quote for your car and if you agree then we will pay it to you. On top of it, we will also pick up the car from your home for free!</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 8. If I bring my vehicle in your quarters, what can I expect? </a></h4>
                    </div>
                    <div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>Our staff will entertain you and evaluate your car along with the competitive appraisal. If we have an agreement with the deal, rest assured that we will work on the paper as soon as possible.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title"> <a role="button" class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="true" aria-controls="collapseOne"> <i class="more-less glyphicon glyphicon-plus"></i> 9. Why should I sell my car with you? </a></h4>
                    </div>
                    <div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>Here at Rapid Car Removal, you have the guarantee that you have a smooth and convenient sale process in the quickest way possible. With us, you no longer need to deal with any hassle such as the paperwork as we will take care of all the heavy works for you. We provide courteous, fast and efficient services with all the conveniences you are looking for.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <div class="bottom-info">
        <div class="container">
            <div class="row">
                <section id="custom_html-10" class="widget_text widget widget_custom_html">
                    <div class="textwidget custom-html-widget">
                        <div class="col-sm-4">
                            <p class="tel">+1 647-699-6361</p> <a href="tel: +1 647-699-6361"> </a>
                            <p>* Our Terms and conditions for Clients.</p>
                            <p>*We cannot get vehicles that are still being financed....</p>
                        </div>
                        <div class="col-sm-8">
                            <h4>Call Scrap Car Removal and get an instant quote.</h4>
                            <h6>Today, you can get top dollar cash for scrap vehicles! Enquire now!</h6>
                            <h3>Get up to $6666 cash for scrap cars in Milton</h3>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>


    <!---- Open Footer----->
    <?php include'php/footer.php'?>
    <!---- End Footer----->

</body>

</html>