<div class="right_right">
    <h6>Get a Junk Car Quote</h6>
    <div role="form" class="wpcf7" id="wpcf7-f21-o1" lang="en-US" dir="ltr">
        <div class="screen-reader-response"></div>
        <form action="php/email.php" method="post" id="messageform" class="wpcf7-form" novalidate="novalidate">
            <div style="display: none;"> <input type="hidden" name="_wpcf7" value="21" /> <input type="hidden" name="_wpcf7_version" value="5.1.4" /> <input type="hidden" name="_wpcf7_locale" value="en_US" /> <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f21-o1" /> <input type="hidden" name="_wpcf7_container_post" value="0" /></div>
            
            <div class="form-group"> <span class="wpcf7-form-control-wrap full-name"><input type="text" name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required your" aria-required="true" aria-invalid="false" placeholder="Name" /></span></div>
            
            <div class="form-group"> <span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email your" aria-required="true" aria-invalid="false" placeholder="Email" /></span></div>
            
            <div class="form-group"> <span class="wpcf7-form-control-wrap phone"><input type="tel" name="phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel your" aria-required="true" aria-invalid="false" placeholder="Phone" /></span></div>
            
            <div class="form-group"> <span class="wpcf7-form-control-wrap make-model-year"><input type="text" name="address" value="" size="40" class="wpcf7-form-control wpcf7-text your" aria-invalid="false" placeholder="Address" /></span></div>
            
            <div class="form-group"> <span class="wpcf7-form-control-wrap location-message"><textarea name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea coment" aria-invalid="false" placeholder="Message"></textarea></span></div>
            
            <div class="form-group"> <input type="submit" value="Send Now" class="wpcf7-form-control wpcf7-submit btn" /></div>
            <div class="wpcf7-response-output wpcf7-display-none"></div>
        </form>
    </div>
</div>