 <script type="text/javascript">
     var script = document.createElement("script");
     script.async = true;
     script.type = "text/javascript";
     var target = '../../www.clickcease.com/monitor/stat.js';
     script.src = target;
     var elem = document.head;
     elem.appendChild(script);
 </script> <noscript><a href="https://www.clickcease.com/" rel="nofollow"><img src="https://monitor.clickcease.com/stats/stats.aspx" alt="Clickcease" /></a></noscript>
 <header id="header">
     <div class="container">
         <div class="row">
             <div class="col-sm-3"> <a class="logo" href="index.php"></a></div>
             <div class="col-sm-9 margin">
                 <div class="col-sm-12">
                     <section id="custom_html-2" class="widget_text widget widget_custom_html">
                         <div class="textwidget custom-html-widget">
                             <div class="call_box">
                                 <ul>
                                     <li> <a href="tel:+1 647-699-6361">+1 647-699-6361</a></li>
                                 </ul>
                             </div>
                         </div>
                     </section>
                 </div>
                 <div class="col-sm-12">
                     <nav class="navbar navbar-default wow fadeInDown">
                         <div class="navbar-header"> <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button></div>
                         <div id="navbar" class="navbar-collapse collapse">
                             <div class="ul">
                                 <ul id="my_menu_id" class="nav navbar-nav navbar-right">
                                     <li id="menu-item-39" class="active menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-39"><a href="index.php">Home</a></li>
                                     <li id="menu-item-288" class="dropdown menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-288 sub-menu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Services <b class="caret"></b></a>
                                         <ul class="dropdown-menu mega">
                                             <li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-40 current_page_item menu-item-53"><a href="Get-Top-Cash-For-Car-In-Milton.php">Get Top Cash For Car In Milton</a></li>
                                             <li id="menu-item-53" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-40 current_page_item menu-item-53"><a href="New-To-Old-Car.php">New To Old Car Removal Milton</a></li>

                                         </ul>
                                     </li>
                                     <li id="menu-item-39" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-39"><a href="company.php">Company</a></li>
                                     <li id="menu-item-58" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-58"><a href="blog.php">Blog</a></li>

                                     

                                     <li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-59"><a href="contact.php">Contact</a></li>
                                 </ul>
                             </div>
                         </div>
                     </nav>
                 </div>
             </div>
         </div>
     </div>
 </header>