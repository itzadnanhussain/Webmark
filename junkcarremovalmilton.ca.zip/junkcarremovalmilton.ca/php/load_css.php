<style>
    <?php 
    include'css/style.css';
    include'css/custome.css';
    include'css/Responsive.css';
    include'css/sweetalert.min.css';
    ?>
</style>