  <footer id="footer">
        <div class="top_footer">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 footer_logo">
                        <section id="custom_html-5" class="widget_text widget widget_custom_html">
                            <div class="textwidget custom-html-widget"><a class="f_log" href="index.php"></a>
                                <ul>
                                    <li>384 Coombs Ct, Milton, ON L9T 7N5, Canada</li>
                                    <li><a href="mailto:carclunker@gmail.com">carclunker@gmail.com</a></li>
                                    <li><a href="tel:+1 647-699-6361">+1 647-699-6361</a></li>
                                </ul>
                            </div>
                        </section>
                    </div>
                    <div class="col-sm-3">
                        <div class="ser">
                            <h5>Services</h5>
                            <ul id="menu-services" class="menu">
                                <li id="menu-item-266" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-266"><a href="Get-Top-Cash-For-Car-In-Milton.php">Get Top Cash For Car</a></li>
 
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="ser">
                            <h5>Quick Links</h5>
                            <ul id="menu-services-area" class="menu">
                                <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="company.php">Company</a></li>
                                 <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="blog.php">Blog</a></li>
                                  <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="#">Quote</a></li>
                                   <li id="menu-item-269" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-269"><a href="contact.php">Contact</a></li>
                                 
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="ser">
                            <h5>Social Network</h5>
 
                                    <ul class="social">
                                        <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                        <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                    </ul>
 
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy_box">
            <section id="custom_html-8" class="widget_text widget widget_custom_html">
                <div class="textwidget custom-html-widget">
                    <p>© Copyright 2019. All Rights Reserved. Scrap Car Removal Milton</p>
                </div>
            </section>
        </div>
    </footer>
 <?php include'php/load_js.php'?> 
    
  
   