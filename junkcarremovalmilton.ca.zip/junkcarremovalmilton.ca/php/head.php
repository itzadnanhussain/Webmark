<meta name="title" content="Junk Car Removal Milton| Get Top Dollar Cash For Junk Cars">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="We are the best Milton Auto wreckers. If you have an Old, Scrap, Used, Junk, Unwanted Cars.Dont Worry about at this conditoin, we are here!">
<meta name="keywords" content="Junk Car Removal, Milton Car Removal, Cash For Junk Cars">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="English"> 
    <link rel="shortcut icon" href="img/logo.png" type="img/logo.png" /> 
    <?php include'php/load_css.php'?>
    <!--Google Fonts---------->
   <link href="https://fonts.googleapis.com/css?family=PT+Serif|PT+Serif+Caption|Roboto+Slab&display=swap" rel="stylesheet">
   <!---Tags------------>
   <?php include'php/Tags.php'?>
