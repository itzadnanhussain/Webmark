<!----Schema Tags----------------->
<script type="application/ld+json">
{
	"@context": "http://schema.org",
	"@type": "AutomotiveBusiness",
	"name": "Scrap Car Removal Milton",
	"address": {
		"@type": "PostalAddress",
		"streetAddress": "384 Coombs Ct",
		"addressLocality": "Milton",
		"addressRegion": "ON",
		"postalCode": "L9T 7N5"
	},
	"image": "http://junkcarrremovalmilton.ca/img/banner.jpg",
	"email": "carclunker@gmail.com",
	"telePhone": "+1 647-699-6361",
	"url": "http://junkcarrremovalmilton.ca/",
	"paymentAccepted": [ "cash" ],
	"openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 07:00-22:00",
	"openingHoursSpecification": [ {
		"@type": "OpeningHoursSpecification",
		"dayOfWeek": [
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
			"Sunday"
		],
		"opens": "07:00",
		"closes": "22:00"
	} ],
	"geo": {
		"@type": "GeoCoordinates",
		"latitude": "43.495672",
		"longitude": "-79.892291"
	},
	"priceRange":"$$$"

}
</script>
