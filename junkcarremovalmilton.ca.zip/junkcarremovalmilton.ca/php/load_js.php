   <script async src="js/jquery.min.js"></script>
   <script async src="js/bootstrap.min.js"></script>
   <script async src="js/owl.carousel.js"></script>
   <script async src="js/email.js"></script>
   <script async src="js/sweetalert.min.js"></script>
   <script async src="js/plugin.js"></script>