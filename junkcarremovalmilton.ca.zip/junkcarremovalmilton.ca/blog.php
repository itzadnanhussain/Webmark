<html lang="en">
<title>Blogs Main Page----</title>
<?php include'php/head.php'?>

<body>
    <!------Open Header------>
    <?php include'php/header.php'?>
    <!------End Header------>
    <div class="blog-title">
        <div class="container">
            <h1 class="page-title">Blog</h1>
        </div>
    </div>
    <div class="blog">
        <div class="container">
            <article id="post-2489" class="post-2489 post type-post status-publish format-standard has-post-thumbnail hentry category-tips">
                <div class="post-thumbnail"> <a href="How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.php" class="img-responsive" alt=""><img src="img/blogs/How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.jpg" class="img-responsive" alt=""></a></div>
                <header class="entry-header">
                    <h2 class="entry-title"> <a href="How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.php" rel="bookmark">How To Know If a Company is a Licensed Wrecker in Milton </a></h2>
                    <div class="entry-meta"> <span class="posted-on">Posted on <a href="How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.php"><time class="entry-date published" datetime="2018-10-02T06:26:22+00:00">Oct-20-2019</time></a></span></div>
                </header>
                <div class="entry-content">
                    <p>In order to buy the end of life vehicle like junk, damaged, old, accident and non-running cars for scrap metal...</p>
                    <p class="link-more"><a href="How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.php" class="more-link business-booster-excerpt-btn">Read More</a></p>
                </div>
            </article>
            
            
            
            
            <article id="post-2489" class="post-2489 post type-post status-publish format-standard has-post-thumbnail hentry category-tips">
                 <div class="post-thumbnail"> <a href="selling-your-old-car.php" class="img-responsive" alt=""><img src="img/blogs/Selling-your-old-car.jpg" class="img-responsive" alt=""></a></div>
                <header class="entry-header">
                    <h2 class="entry-title"> <a href="selling-your-old-car.php" rel="bookmark">Selling Your Old Car? Get Instant Cash on the Spot!</a></h2>
                    <div class="entry-meta"> <span class="posted-on">Posted on <a href="selling-your-old-car.php"><time class="entry-date published" datetime="2018-10-02T06:26:22+00:00">Oct-20-2019</time></a></span></div>
                </header>
                <div class="entry-content">
                    <p>If you have old, scrap, damaged, unwanted or used car it doesn’t mean you have no more options...</p>
                    <p class="link-more"><a href="selling-your-old-car.php" class="more-link business-booster-excerpt-btn">Read More</a></p>
                </div>
            </article>  
            
        
               
            <article id="post-2489" class="post-2489 post type-post status-publish format-standard has-post-thumbnail hentry category-tips">
                <div class="post-thumbnail"> <a href="Junk-Car-Removal-Milton.php" class="img-responsive" alt=""><img src="img/blogs/Junk-Car-Removal-Milton.jpg" class="img-responsive" alt=""></a></div>
                <header class="entry-header">
                    <h2 class="entry-title"> <a href="Junk-Car-Removal-Milton.php" rel="bookmark">Junk car? Get Instant Cash For Its Removal</a></h2>
                    <div class="entry-meta"> <span class="posted-on">Posted on <a href="Junk-Car-Removal-Milton.php"><time class="entry-date published" datetime="2018-10-02T06:26:22+00:00">Oct-20-2019</time></a></span></div>
                </header>
                <div class="entry-content">
                    <p>With hard times, a lot of property owners are attempting to search out the way to make some money...</p>
                    <p class="link-more"><a href="Junk-Car-Removal-Milton.php" class="more-link business-booster-excerpt-btn">Read More</a></p>
                </div>
            </article>
            
              </div>
    </div>
    
    
    
    <div class="bottom-info">
        <div class="container">
            <div class="row">
                <section id="custom_html-10" class="widget_text widget widget_custom_html">
                    <div class="textwidget custom-html-widget">
                        <div class="col-sm-4">
                            <p class="tel">+1 647-699-6361</p> <a href="tel: +1 647-699-6361"> </a>
                            <p>* Our Terms and conditions for Clients.</p>
                            <p>*We cannot get vehicles that are still being financed....</p>
                        </div>
                        <div class="col-sm-8">
                            <h4>Call Scrap Car Removal and get an instant quote.</h4>
                            <h6>Today, you can get top dollar cash for scrap vehicles! Enquire now!</h6>
                            <h3>Get up to $6666 cash for scrap cars in Milton</h3>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>



    <!---- Open Footer----->
    <?php include'php/footer.php'?>
    <!---- End Footer----->
</body>

</html>