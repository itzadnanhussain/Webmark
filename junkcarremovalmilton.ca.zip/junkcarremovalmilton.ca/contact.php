<html lang="en">
<title>contact--</title>
<?php include'php/head.php'?>

<body>
    <!------Open Header------>
    <?php include'php/header.php'?>
    <!------End Header------>
    
  <div class="banner_box">
        <div class="container">
            <div class="row"> <svg preserveAspectRatio="none" viewBox="0 0 600 250">
                    <polygon points="600,0 0,0 0,800" opacity="1"></polygon>
                </svg>
                <div class="col-sm-8 le_box ">
                    <div class="left_box">
                        <h1>Scrap Car Removal Milton</h1>
                        <p>FREE TOWING. We Come To You | Fast Cash On The Spot Same Day Free
                            Pick Up. scrap Used Scrap Car removal In Milton</p>
                    </div>
                </div>
                <div class="col-sm-4 out">
                    <!--Contact Form---->
                    <?php include'php/form.php'?>
                </div>
            </div>
        </div>
    </div> 
    
    
    <div class="cashfor-car cashfor-car-list">
        <div class="container">
            <h1 class="heading-1 center margin-bottom-1">Contact Scrap Car Removal <span class="yellow"> Milton</span></h1>
            <div class="row">
                <div class="unwnt_txt">
                    <p class="un_txt">If you have a question for scrap car removal Milton, Without any hesitation free to email or call us. We are every time to ready to give  answer to your query. If you want an instant quote for a junk car, just provide our estimates team with the complete details of the used or unwanted vehicles & the location for pickup.

</p>
                </div>
            </div>
        </div>
    </div>
    <div class="faq-form-outer contact-info">
        <div class="container">
            <div class="contact-info-box">
                <h1 class="heading-1 center margin-bottom-1"><span class="yellow">CONTACT DETAILS:</span></h1>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="left-info">
                            <div class="cont-details-outer">
                                <div class="cont_sidebar cont_sidebar_adres ">
                                    <h3 class="widget-title">Our Office:</h3>
                                    <p>384 Coombs Ct, Milton,<br> ON L9T 7N5, Canada.</p>
                                </div>
                                <div class="cont_sidebar cont_sidebar_mail ">
                                    <h3 class="widget-title">Email:</h3>
                                    <p><a href="mailto:carclunker@gmail.com">carclunker@gmail.com</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="left-info">
                            <div class="cont-details-outer">
                                <div class="cont_sidebar phone">
                                    <h3 class="widget-title">Phone Number:</h3>
                                    <p><a href="tel:+1 647-699-6361">+1 647-699-6361</a></p>
                                </div>
                                <div class="cont_sidebar cont_sidebar_adres gen_info">
                                    <p><strong>SCRAP CAR REMOVAL MILTON</strong><br> 384 Coombs Ct, Milton,ON L9T 7N5, Canada.<br> Phone: <a href="tel:+1 647-699-6361">+1 647-699-6361</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
   <div class="bottom-info">
        <div class="container">
            <div class="row">
                <section id="custom_html-10" class="widget_text widget widget_custom_html">
                    <div class="textwidget custom-html-widget">
                        <div class="col-sm-4">
                            <p class="tel">+1 647-699-6361</p> <a href="tel: +1 647-699-6361"> </a>
                            <p>* Our Terms and conditions for Clients.</p>
                            <p>*We cannot get vehicles that are still being financed....</p>
                        </div>
                        <div class="col-sm-8">
                            <h4>Call Scrap Car Removal and get an instant quote.</h4>
                            <h6>Today, you can get top dollar cash for scrap vehicles! Enquire now!</h6>
                            <h3>Get up to $6666 cash for scrap cars in Milton</h3>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>


    <!---- Open Footer----->
    <?php include'php/footer.php'?>
    <!---- End Footer----->

</body>

</html>