<html lang="en">
    <title>Scrap Car Removal Toronto|..</title>
    <?php include'php/head.php'?>
    <body>
        <div id="wrapper" class="page6 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code----->
        
             <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                    <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="home.html" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="cur lastItem"><a href="faq.php" title="FAQ"><i class="fa fa-angle-right"></i>FAQ</a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_112">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">FAQ - Frequently asked questions on car sale</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p>Autoexport Center Erfurt buys your used car. How does it work? How does the evaluation work? Will my car be picked up?</p>
                                    <p>When selling your car, you will encounter a lot of question which we are answering on this page.</p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div id="contentColumnFix"></div>
            </div>
        </div>
        
        
        
        
         <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
        </div>
    </body>
</html>