<html lang="en">
<title>Junk Car Removal Toronto|Our Charity Work </title>
<?php include'php/head.php'?>

<body>
    <div id="wrapper" class="page6 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code----->

        <!--Close Header Code----->
        <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                    <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="index.php" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="act"><a href="blog.php" title="Junk car removal services"><i class="fa fa-angle-right"></i>blog</a></li>
                        <li class="cur lastItem"><a href="Our-Charity-Work.php" title="Our Charity Work "><i class="fa fa-angle-right"></i>Our Charity Work </a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_109">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">Our Charity Work – Junk My Car and Help My Community </h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">When you say “Junk My Car”, all the web services will begin to blur into one, can’t they? However, there is just one automotive scrapping service that comes properly with its personal social welfare charity - and that is Junk car removal service, Stratford.Read on to search out how to Junk your car! With Junk car removal Stratford, they will facilitate communities close to you to thrive and grow. </p>
                                    <p class="text-justify">Cars do not last forever, and if you think your car is no longer roadworthy, you may need to sell your old or unwanted vehicle. If so, make sure that you just get the maximum price for it. We have a tendency to tell you what your junk car is price, and we will collect your vehicle at a time to suit you. Once you sell your unwanted or old car with us then you feel relax to knowing that your Junk car is recycled to the best place at an Authorised Treatment Facility.</p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_110">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h2 class="title">Our Social Welfare Charity</h2>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">Junk car removal Stratford is a part of Recycling and waste management companies. Recycling facility helps people to concentrate on work and skills and also help them to maintain a stable routine. Residents are those people who unable to find their way. They could be people who face many personal losses and debt issues. Our social welfare charity, provides work experience, accommodation, training or coaching and employment opportunities to folks in need. </p>
                                    <p class="text-justify">We have a tendency to still expand our range of company partners. We hope these people are excited to know more about our social welfare charity, they have to think about working with us in the future. We can help the resident who is homeless and face poor working condition. We will provide equipment, work expertise and training to ready for their first work placement. </p>
                                    <p class="text-justify">Recycling facility undertakes a wide range of commercial and domestic services. These services are the recycling of junk metal, old and unwanted cars, car batteries, useless electronic equipment.Junk car removal service is one of our charity’s most useful financial gain streams – each and every one of the Junk cars helps to maximize the funding that we can offer to helpless people. </p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">Improving the Environment and Employment</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">At Junk car removal Stratford – the Junk cars we tend to process are recycled at Authorised Treatment Facilities across Canada, we are helping to improve the economy in your region.The recycling centers near us also offer much-needed work expertise, training and skills development and employment opportunities to the individuals we tend to facilitate. The recycling industry has advanced over the years. Therefore, education and skill in that area are the best bet for people searching for a steady job. It is also best for the environment.</p>
                                    <p class="text-justify">It is simple to underestimate the impact that Junk cars have on our environment. Old and Junk cars may be harmful to the environment because older cars can leak many hazardous fluids into the ground that causing damage to our water supplies and soil, such as antifreeze, battery fluid, brake fluid, power steering fluid and many others like mercury and sodium azide. Getting these older cars and damaged cars off the road can help the environment on different levels from air quality to water conservation. Decreasing the number of Junk cars can also provide advantages to the car owner as well. The government of the Canada and US have managed programs that help owners to remove their old car as a way of encouraging environmental ethics and air quality.</p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">Car Donation VS Cash for Junk Cars</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">Most of us have “Junk Car” and we don’t know what to do with it. You can donate a car to charity as well as also get cash for your car. If you want to donate a car to charity you will make a charitable contribution to your community in need. You can often take benefit of tax deductions. If you are skeptical about car donation you can also make money for your car is the best choice. You get cash whether you select a proper “cash for cars” program or sell your old car to Junk yard. You get maximum cash in your pocket. This money also acts as an incentive to buy a new one, a lot of fuel-efficient vehicle. You can also help the people and environment by reducing greenhouse gas emissions. </p>

                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">Real Charity Benefits</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">While Junk car may be useless to their owner, they are a significant source of financial gain for the Recycling company charity and they also help the homeless people. Car scrapping not only gives the opportunity to make a profit from the junk materials found in damaged or old cars, they also offer the opportunities for people who otherwise wouldn’t have them.We are working with collection partners across Canada, helping to maximize their income and improve the local economy. </p>
                                    <p class="text-justify">If you want to Junk your car just contact us or visit our homepage. Our service is one of the best services. Get the instant quote for your vehicle today!</p>

                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div id="contentColumnFix"></div>
            </div>
        </div>
        <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
    </div>
</body>

</html>