$(document).ready(function() { 
	// Icons Navi
	$('#naviMain .firstItem DIV A').prepend('<i class="fa fa-home"></i>');
//	$('#naviMain .sub > A').append('<i class="fa fa-caret-right"></i>');
//	$('#naviMain LI UL LI A').prepend('<i class="fa fa-angle-right"></i>');
	$('.naviSeo LI A').prepend('<i class="fa fa-caret-right"></i>');
	// Icons Links
	$('.CMM_Contents_contentBlock P A').each(function() {
		if($(this).hasClass('button') || $(this).has('I').length > 0) {} else { $(this).prepend('<i class="fa fa-angle-right"></i>'); }
		});

	// Hauptnavi - responsive
	$('#naviArea').responsiveMenu({toggleText:'<i class="fa fa-bars"></i> NAVIGATION',switchWidth:960,sticky:true});

	// Wrapper-padding for sticky footer
	$('#wrapper').css('padding-bottom', $('#footWrapper').height());
		$(window).bind("resize", function(){
			$('#wrapper').css('padding-bottom', $('#footWrapper').height());
			});

	// Slider News-Ticker
	$('#contentContainer .CMM_News_short UL').bxSlider({auto:true, pager:true, controls:false, mode:'vertical', speed:500, pause:6000, tickerHover:true });

	// Bild-Karussel
	$('.CMM_Contents_imagesSlider UL').bxSlider({auto:false, pager:false, controls:true, mode:'horizontal', speed:500, pause:6000, minSlides:2, maxSlides:6, moveSlides:1, slideWidth:160, slideMargin:20, tickerHover:true, prevText:'', nextText:''});

	// Login-Box
	$('#loginBox').hoverIntent(function() {
		$('#loginBoxContent').slideDown();
		}, function() {
		$('#loginBoxContent').fadeOut();
		});

	// Table-Scroll
	if(!$('.pagePrint').length)
		{
		$('.CMM_tableType_5').each(function() {
			var currentPage = 0;
			var numPerPage = 10;
			var $table = $(this);
			$table.bind('repaginate', function() {
				$table.find('tbody tr').hide().slice(currentPage * numPerPage, (currentPage + 1) * numPerPage).show();
			});
			$table.trigger('repaginate');
			var numRows = $table.find('tbody tr').length;
			var numPages = Math.ceil(numRows / numPerPage);
			var $pager = $('<div class="CMM_pagination"><div class="CMM_pageNavi"><ul></ul></div></div>');
			for (var page = 0; page < numPages; page++) {
				$('<li class="CMM_pageNaviPage"><a href="javascript:void(0);">'+(page + 1)+'</a></li>').bind('click', {
					newPage: page
				}, function(event) {
					currentPage = event.data['newPage'];
					$table.trigger('repaginate');
					$(this).addClass('CMM_pageNaviPageSelected').siblings().removeClass('CMM_pageNaviPageSelected');
				}).appendTo($pager.find('UL'));
			}
			$pager.insertAfter($table).find('LI.CMM_pageNaviPage:first').addClass('CMM_pageNaviPageSelected');
			});

/*		$('.CMM_tableType_5').parent().each(function() {
			$('table',this).wrap('<div class="CMM_tableScroll"></div>');
			$currentScrollContainer = $('.CMM_tableScroll',this);
			$(this).prepend('<div class="CMM_tableHead"></div>');
			$currentHeadContainer = $('.CMM_tableHead',this);
			$currentHeadContainer.html($currentScrollContainer.html());
			if($currentScrollContainer.height() < $currentScrollContainer[0].scrollHeight)
				{ $currentHeadContainer.addClass('CMM_tableHeadScroll'); }	
			});
*/		}

	// Such-Box
	$('#searchBoxHead A').click(function(event) {
		event.preventDefault();
		$('#searchBoxContent').animate({ 'width':'210px' }); $('#searchBoxHead').animate({ 'width':'0' });
		});
	// Such-Box ausblenden, wenn Klick ausserhalb
	searchBoxHover = false; 
	$('#searchBox').hover(function() { searchBoxHover = true; }, function() { searchBoxHover = false; });
	$('BODY').click(function(){ if(!searchBoxHover) { $('#searchBoxContent').animate({ 'width':'0' }); $('#searchBoxHead').animate({ 'width':'40px' }); } });

	}); 
