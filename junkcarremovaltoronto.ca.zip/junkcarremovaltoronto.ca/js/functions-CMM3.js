/* CMM3 - Scripts */
////////////////////////////////////////////////////////////////
// V 1.0.0 erstes Release
// V 1.1.0 some recodes
// V 1.2.0 check extended for Select / Radio / Checkbox
// V 1.3.0 check against value
// V 1.3.1 Changed RegEx for Phone
// V 1.3.2 Changed field value grabbing
// V 1.4.0 CMM_equalizeContentBlockHeight() hinzugefuegt
// V 1.4.1 CMM_equalizeContentBlockHeight() angepasst
// V 1.4.2 CMM_equalizeContentBlockHeight() angepasst
// V 1.4.3 CMM_equalizeContentBlockHeight() angepasst
// V 1.4.4 CMM3_paginateTable() hinzugefuegt
// V 1.4.5 CMM3_changeListType() hinzugefuegt
// V 1.4.6 CMM3_equalizeContentBlockHeight() optimiert fuer nested contents
// V 1.4.7 CMM3_sendMailForm() angepasst fuer input type file per Ajax
// V 1.4.8 CMM3_equalizeContentBlockHeight() angepasst
// V 1.4.9 CMM3_sendMailForm() erweitert filetype/filesize
// V 1.5.0 CMM3_toggleBox() hinzugefuegt
// V 1.5.1 CMM3_sendMailForm() Teile in 3 weitere Funktionen ausgelagert
// V 1.5.2 CMM3_sendMailForm() Bugfix: Antwort-Verzoegerung eingebaut
// V 1.5.3 Added function CMM3_isTouch()
////////////////////////////////////////////////////////////////


/*
Counter.js
https://github.com/tombruijn/counter.js
Version: 0.0.2
Copyright (c) 2014 Tom de Bruijn
Counter.js is licensed under the MIT license.
https://github.com/tombruijn/counter.js/LICENSE
*/
!function(){!function($){var Counter,defaults,pluginName;return pluginName="counter",defaults={autoStart:!0,duration:1500,countFrom:void 0,countTo:void 0,runOnce:!1,placeholder:void 0,easing:"easeOutQuad",onStart:function(){},onComplete:function(){}},Counter=function(){function Counter(element,options){this.element=element,this.options=$.extend(!0,{},defaults,options),this.init()}return Counter}(),Counter.prototype.init=function(){var givenNumber;;if(givenNumber=parseInt(this.element.innerHTML),null==givenNumber||isNaN(givenNumber)||(this.options.countFrom<givenNumber?this.options.countTo=givenNumber:this.options.countFrom=givenNumber),void 0===this.options.countFrom&&(this.options.countFrom=0),void 0===this.options.countTo&&(this.options.countTo=0),null!=this.options.placeholder&&(this.element.innerHTML=this.options.placeholder),this.options.autoStart)return this.start()},Counter.prototype.start=function(){var self;if(this.options.runOnce&&this.runCount()>=1)return!1;if(!this.running)return this.running=!0,this.updateRunCount(),this.options.onStart(),self=this,jQuery({count:this.options.countFrom}).animate({count:this.options.countTo},{duration:this.options.duration,easing:this.options.easing,step:function(){return self.setNumber(this.count)},complete:function(){return self.setNumber(self.options.countTo),self.running=!1,self.options.onComplete()}})},Counter.prototype.updateRunCount=function(){return $(this.element).data("counterRunCount",(this.runCount()||0)+1)},Counter.prototype.runCount=function(){return $(this.element).data("counterRunCount")},Counter.prototype.setNumber=function(number){return this.element.innerHTML=Math.round(number).toLocaleString()},$.fn.counter=function(options){var self;return self=this,this.each(function(){var plugin;if(!(plugin=$(this).data("plugin_"+pluginName)))return $(this).data("plugin_"+pluginName,new Counter(this,options));if("string"==typeof options)switch(options){case"start":return plugin.start()}})}}(jQuery)}.call(this);


////////////////////////////////////////////////////////////////


// Check if is touch device
function CMM3_isTouch()
	{
	return (('ontouchstart' in window)
    || (navigator.MaxTouchPoints > 0)
    || (navigator.msMaxTouchPoints > 0));
	}


////////////////////////////////////////////////////////////////


// Function for toggle-boxes
function CMM3_toggleBox(box,speed)
	{
	speed === 'undefined' ? speed = 500 : '';

	// Disable A-Tags in Box head
	$('.boxHead A',box).on('click', function(event) {
		event.preventDefault();
		});
	// Toggle box if click on head 
	$('.boxHead',box).on('click', function(event) {
		$('.boxContent',box).stop(true, true).slideToggle(speed);
		box.toggleClass('act',speed);
		});
	// Hide box if click outside
	$(document).on('click', function(event) {
		if(this !== event.target && !box.has(event.target).length) {
			$('.boxContent',box).stop().fadeOut(speed);
			box.removeClass('act',speed);
			}
		});
	}


////////////////////////////////////////////////////////////////


// Funktion zur Generierung einer Tabellen-Paginierung
function CMM3_paginateTable(tableSelector)
	{
	var $table = tableSelector;
	var currentPage = 0;
	var numPerPage = 10;
	if($table.data('rowsperpage'))
		{ numPerPage = parseFloat($table.data('rowsperpage')); }
	$table.bind('repaginate', function() {
		$table.find('tbody tr').hide().slice(currentPage * numPerPage, (currentPage + 1) * numPerPage).show();
	});
	var numRows = $table.find('tbody tr').length;
	var numPages = Math.ceil(numRows / numPerPage);
	if(numRows > numPerPage)
		{
		$table.trigger('repaginate');
		var $pager = $('<div class="CMM_pagination"><div class="CMM_pageNavi"><ul></ul></div></div>');
		for (var page = 0; page < numPages; page++) {
			$('<li class="CMM_pageNaviPage"><a href="javascript:void(0);">'+(page + 1)+'</a></li>').bind('click', {
				newPage: page
			}, function(event) {
				currentPage = event.data['newPage'];
				$table.trigger('repaginate');
				$(this).addClass('CMM_pageNaviPageSelected').siblings().removeClass('CMM_pageNaviPageSelected');
			}).appendTo($pager.find('UL'));
		}
		$pager.insertAfter($table).find('LI.CMM_pageNaviPage:first').addClass('CMM_pageNaviPageSelected');
		}
	}


////////////////////////////////////////////////////////////////


// Funktion zum umschalten des Listentyps
function CMM3_changeListType(listTypeBarSelector)
	{
	// select list type bar
	$listTypeBar = listTypeBarSelector;
	// indentify list
	listselector = $listTypeBar.attr('data-listselector');
	// read cookie
	listtype = $.cookie('listtype');
	// set list type
	listtype==null ? listtype='list' : '';
	$(listselector).removeClass().addClass(listtype);
	// bind list type links
	$('A',$listTypeBar).each(function() { 
		// mark as active
		if(listtype == $(this).attr('data-listtype'))	
			{ $(this).addClass('act'); }
		// bind click
		$(this).on('click',function() {
			$(this).parent().parent().find('A').removeClass('act');
			$(this).addClass('act');
			listtype = $(this).attr('data-listtype');
			$(listselector).fadeOut(250, function() {
				$(listselector).removeClass().addClass(listtype);
				$(listselector).fadeIn(250);
				});
			// set cookie
			$.cookie('listtype', listtype, { expires: 7 });
			// prevent default click
			return false;
			});
		});
	}


////////////////////////////////////////////////////////////////


// Funktion zum Ausgleich der Hoehen von Content-Bloecken einer Zeile
function CMM3_equalizeContentBlockHeight(contentColumn,element)
	{
	if(typeof element == "undefined")
		{ element = '.CMM_Contents_contentBlock_Inner'; }

	var contentBlockOffsets = new Array();
	// Loop fuer alle Bloecke in Spalte contentColumn
	$(element,contentColumn).each(function() {
		// wenn nicht Content = Slider
		if($(this).parents('.CMM_Contents_Type105').length > 0)
			{}
		// sonst
		else
			{
			// Elemente mit gleichem Y-Offset einsammeln
			var currentOffset = 'Y'+$(this).parent().offset()['top'].toString();
			// Subcontents von Contents trennen - durch Zusatz "S" im Offset-Index
			if($(this).parents('.CMM_Contents_contentBlock_Subcontents').length > 0)
				{ currentOffset+= 'S'; }
			// Subcontents von Subcontents von Contents trennen - noch ein "S" im Offset-Index
			if($(this).parents('.CMM_Contents_contentBlock_Subcontents').parents('.CMM_Contents_contentBlock_Subcontents').length > 0)
				{ currentOffset+= 'S'; }

			if(!contentBlockOffsets[currentOffset])
				{ contentBlockOffsets[currentOffset] = new Array(); }
			contentBlockOffsets[currentOffset].push($(this));

			// Min-Hoehe entfernen
			$(this).css('min-height','');
			}
		});

	// Loop je Y-Offset (Zeile)
	for(key in contentBlockOffsets) {
		//console.log(key+': ');
		maxBlockHeight = 0;
		// hoechtses Element in Zeile ermitteln - Loop fuer alle DIVs der Zeile
		$(contentBlockOffsets[key]).each(function(key,value) {
			//console.log($(this));
			$(this).css('min-height','');
			// Get current block height
			currentBlockHeight = $(this).outerHeight();
			// Recognize (negative) margin of subcontents
			if($('.CMM_Contents_contentBlock_Subcontents',this).length)
				{
				currentBlockHeight+= parseInt($('.CMM_Contents_contentBlock_Subcontents',this).css('margin-top'));
				currentBlockHeight+= parseInt($('.CMM_Contents_contentBlock_Subcontents',this).css('margin-bottom'));
				}
			// Update max-height
			currentBlockHeight > maxBlockHeight ? maxBlockHeight = currentBlockHeight : '';
			});

		// Wenn mehr als ein Block in Zeile -> Hoehe ausgleichen
		if(contentBlockOffsets[key].length > 1)
			{
			// Allen Elemente mit gleichem y-Offset neue Hoehe zuweisen
			$(contentBlockOffsets[key]).each(function(key,value) {

				currentBlockPadding = 0;
			//	currentBlockPadding = $(element,value).first().outerHeight()-$(element,value).first().height();
				$(this).css('min-height',maxBlockHeight);
				});
			}
		}
	}


////////////////////////////////////////////////////////////////


// Funktion zum Versenden eines Formulars
function CMM3_sendMailForm(button)
	{
	formContainer = $(button).parents('.CMM_formContainer');
	var formForm = $('.CMM_form',formContainer).parents('FORM');
	var formContent = $('.CMM_formContent',formContainer);
	var formFoot = $('.CMM_formFoot',formContainer);
	var formType = $('[name=CMM_formType]',formContainer).val();
	formID = $('[name=CMM_formID]',formContainer).val();

	var formFields = $('INPUT, SELECT, TEXTAREA',formContent);
	var formErrorFields = '';
	var errorMessage = $('#CMM_JSerrorMessage',formContainer).text();

	// define check type patterns
	typePatterns = new Array();
	typePatterns['integer'] = /^[0-9\-]+$/;
	typePatterns['float'] = /^[0-9\-]+[.,]*[0-9]*$/;
	typePatterns['phone'] = /^[0123456789.\+\-\/\(\) ]+$/;
	typePatterns['streetnoNo'] = /^[0-9a-zA-Z\-]+$/;
	typePatterns['zipcityZip'] = /^[0-9a-zA-Z\-]+$/;
	typePatterns['email'] = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
	typePatterns['url'] = /([a-z0-9]+)(:\/\/)([a-z0-9\/?=&\-.]+)/;
	typePatterns['date'] = /^[0-9]{2}[.]+[0-9]{2}[.]+[0-9]{4}$/;
	typePatterns['datetimeDate'] = /^[0-9]{2}[.]+[0-9]{2}[.]+[0-9]{4}$/;

	// remove all errors fields
	formFields.each(function() {
		// remove error class from field container
		$(this).parent().removeClass('CMM_formFieldError');
		});

	// check fields
	formFields.each(function() {
		// get label
		if($(this).attr('placeholder'))
			{ fieldLabel = $(this).attr('placeholder'); }
		else
			{ fieldLabel = $(this).parent().find('> label').text(); }
		// get validat
		if($(this).data('validate'))
			{ validateType = $(this).data('validate'); }
		else
			{ validateType = ''; }
		// get value
		fieldValue = $(this).val();
		// error
		fieldError = false;

		// Check content against pattern
		if(typeof typePatterns[validateType] != 'undefined')
			{
			// check value against pattern
			if($(this).val().trim() != '' && typePatterns[validateType].test(fieldValue) == false)
				{ fieldError = true; console.log(fieldLabel+': Pattern error'); }
			}

		// Check field against required
		if($(this).attr('required'))
			{
			// checkbox
			if($(this).attr('type')=='checkbox' && $(this).prop('checked')==false)
				{ fieldError = true; }
			// other fields
			else if(fieldValue.trim() == '')
				{ fieldError = true; console.log(fieldLabel+': Required error'); }
			}

		// Check filetype against accept
		if(validateType=='file' && $(this).val()!='')
			{
			// Filetype
			if($(this).attr('accept') && $(this).attr('accept')!='')
				{
				var ext = $(this).val().split('.').pop().toLowerCase();
				var extlist = $(this).attr('accept').split(',');
				if(extlist.indexOf('.'+ext) <= 0)
					{ fieldError = true; console.log(fieldLabel+': Filetype error'); }
				}
			// Filesize
			if($(this).data('filesize') && $(this).data('filesize')!='')
				{
				// Check if browser supports file api
				if(window.File && window.FileReader && window.FileList && window.Blob)
					{
					var filesize = $(this)[0].files[0].size;
					var filesizemax = $(this).data('filesize');
					if(filesize > filesizemax)
						{ fieldError = true; console.log(fieldLabel+': Filesize error'); }
					}
				}
			}

		// Set error message and class
		if(fieldError == true)
			{
			// add error class on field container
			$(this).parent().addClass('CMM_formFieldError');
			// add field label to error list
			formErrorFields+= "- "+fieldLabel+"\n"; }
		});

	// alert error message
	if(formErrorFields != '')
		{ alert(errorMessage+"\n"+formErrorFields); }
		

	// catch all fields and send form
	if(formErrorFields == '')
		{
		// senden per ajax
		if(formType=='ajax')
			{
			// collect form data
	//		var formData = $(formForm).serialize(); // by serialize - no files possible
			var	formData = new FormData(formForm[0]); // by FormData object
		//	console.log(formForm[0]);

			// Send form
			$.ajax({
				type: "POST",
				url: location.href, //'CMM/incl/ajax-mailer.php',
				data: formData,
				beforeSend: CMM3_sendMailFormBefore,
				success: CMM3_sendMailFormSuccess,
				error: CMM3_sendMailFormError,
				// Not to process data or worry about content-type.
				processData: false,
				contentType: false,
				cache: false
				});
			}
		// normal senden
		else
			{
			$(formForm).submit();
			}
		}
	}


////////////////////////////////////////////////////////////////


// Function to prepare contents before form sending
function CMM3_sendMailFormBefore(data)
	{
	// Show loader
	$(formContainer).before('<div class="CMM_formLoader" style="display:none;"></div>');
	$(formContainer).prev().slideDown(500);

	// Hide form and empty form contents
	$(formContainer).slideUp(500, function(){
		$(formContainer).empty();
		// Resize colorbox
		if(jQuery().colorbox)
			{ $.colorbox.resize(); }
		});
	}


////////////////////////////////////////////////////////////////


// Function to proccess after form sending
function CMM3_sendMailFormSuccess(data)
	{
	// Get data and make it hidden
	relevantData = $(data).find('#form_'+formID).contents();

	// Set timeout to wait for extracting contents from response
	setTimeout(function ()
		{
		// Insert data, hide loader, show form
		$(formContainer).append(relevantData).each(function() {
			$(formContainer).slideDown(500);
			$(formContainer).prev('.CMM_formLoader').slideUp(500,function() {
				$(formContainer).prev('.CMM_formLoader').remove();
				// Resize colorbox
				if(jQuery().colorbox)
					{ $.colorbox.resize(); }
				});
			});

		}, 1000);
	}


////////////////////////////////////////////////////////////////


// Function for form error handling
function CMM3_sendMailFormError(response, error, reqObj)
	{
	console.log(response);
	console.log(error);
	}


////////////////////////////////////////////////////////////////


// decrypt spam-protected emails
function CMM3_uncryptMailto(s)
	{
	location.href = CMM3_decryptString(s,-2);
	}
// decrypt string
function CMM3_decryptString(enc,offset)
	{
	var dec = "";
	var len = enc.length;
	for(var i=0; i < len; i++)
		{
		var n = enc.charCodeAt(i);
		// 0-9 . , - + / :
		if(n >= 0x2B && n <= 0x3A)
			{ dec += CMM3_decryptCharcode(n,0x2B,0x3A,offset); }
		// A-Z @
		else if(n >= 0x40 && n <= 0x5A)
			{ dec += CMM3_decryptCharcode(n,0x40,0x5A,offset); }
		// a-z
		else if(n >= 0x61 && n <= 0x7A)
			{ dec += CMM3_decryptCharcode(n,0x61,0x7A,offset); }
		else
			{ dec += enc.charAt(i); }
		}
	return dec;
	}
// decrypt helper function
function CMM3_decryptCharcode(n,start,end,offset)
	{
	n = n + offset;
	if(offset > 0 && n > end)
		{ n = start + (n - end - 1); }
	else if(offset < 0 && n < start)
		{ n = end - (start - n - 1); }

	return String.fromCharCode(n);
	}


////////////////////////////////////////////////////////////////


function CMM3_openWindow(url,w,h)
	{
	l = screen.width/2-50;
	t = screen.height/2-150;
	w = eval(w) + 16;
	options = "width="+w+",height="+h+",left="+l+",top="+t+",menubar=yes,resizable=yes,scrollbars=yes,status=yes";
	Druckwindow = window.open(url,'Details',options);
	Druckwindow.focus();
	}


////////////////////////////////////////////////////////////////


// Funktion zum Setzen einer Bookmark / eines Favoriten
function CMM3_createBookmarkLink(url,title)
	{
	//url = "Webpage URL";
	//title = "Webpage Title";
	if(window.sidebar)
		{
		// Mozilla Firefox Bookmark
		window.sidebar.addPanel(title, url,"");
		}
	else if(window.external)
		{ // IE Favorite
		window.external.AddFavorite( url, title);
		}
	else if(window.opera && window.print)
		{ // Opera Hotlist
		return true;
		}
	}


