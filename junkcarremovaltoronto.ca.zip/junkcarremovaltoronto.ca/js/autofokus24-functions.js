requestUrl = 'autofokus24/autofokus24-soap.php';


//////////////////////////////////////////////////////////


// GET FORM
function G21_getFormInput(container)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=all&LanguageCode='+lang;
	url = encodeURI(url);

	// get makes
	$(container).load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// Bind change focus on change
		$("#carSetupForm").on('change','SELECT',function() {
			G21_focusInput();
			});
		});
	}


//////////////////////////////////////////////////////////


// GET BOX
function G21_getBoxInput(container)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=box&LanguageCode='+lang;
	url = encodeURI(url);

	// get makes
	$(container).load(url, function(data) { 
		console.log(data);
		});
	}


//////////////////////////////////////////////////////////


// SET FOCUS ON NEXT REQUIRED FIELD
function G21_focusInput()
	{
	if($("#containerMake").find('SELECT').val() == 0 || $("#containerMake").find('SELECT').val() == '')
		{ $("#containerMake").find('SELECT').delay(500).focus(); }
	else if($("#containerMonth").find('SELECT').val() == 0 || $("#containerMonth").find('SELECT').val() == '')
		{ $("#containerMonth").find('SELECT').delay(500).focus(); }
	else if($("#containerYear").find('SELECT').val() == 0 || $("#containerYear").find('SELECT').val() == '')
		{ $("#containerYear").find('SELECT').delay(500).focus(); }
	else if($("#containerModel").find('SELECT').val() == 0 || $("#containerModel").find('SELECT').val() == '')
		{ $("#containerModel").find('SELECT').delay(500).focus(); }
	else if($("#containerSubmodel").find('SELECT').val() == 0 || $("#containerSubmodel").find('SELECT').val() == '')
		{ $("#containerSubmodel").find('SELECT').delay(500).focus(); }
	else if($("#containerBodywork").find('SELECT').val() == 0 || $("#containerBodywork").find('SELECT').val() == '')
		{ $("#containerBodywork").find('SELECT').delay(500).focus(); }
	else if($("#containerEngine").find('SELECT').val() == 0 || $("#containerEngine").find('SELECT').val() == '')
		{ $("#containerEngine").find('SELECT').delay(500).focus(); }
	else if($("#containerFokuscode").find('SELECT').val() == 0 || $("#containerFokuscode").find('SELECT').val() == '')
		{ $("#containerFokuscode").find('SELECT').delay(500).focus(); }
	else if($("#containerMileage").find('SELECT').val() == 0 || $("#containerMileage").find('SELECT').val() == '')
		{ $("#containerMileage").find('SELECT').delay(500).focus(); }
	else if($("#containerColor").find('SELECT').val() == 0 || $("#containerColor").find('SELECT').val() == '')
		{ $("#containerColor").find('SELECT').delay(500).focus(); }
	else
		{ $("#containerColor").find('SELECT').blur(); }
	}


//////////////////////////////////////////////////////////


// GET MAKES
function G21_getMakeInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=make&LanguageCode='+lang;
	url = encodeURI(url);

	// empty following fields
//	$("#containerMake").empty();
//	$("#containerModel").empty();
	$("#containerSubmodel").empty();
	$("#containerBodywork").empty();
	$("#containerEngine").empty();
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$.get(url, function(data) { 
		console.log(data);
		$("#containerMake").html(data);
		$("#containerMake").find('SELECT').delay(1000).focus();
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET MODELS
function G21_getModelInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=model&LanguageCode='+lang+'&make='+$('#inputMake').val()+'&month='+$('#inputMonth').val()+'&year='+$('#inputYear').val();
	url = encodeURI(url);

	// empty following fields
//	$("#containerModel").empty();
	$("#containerSubmodel").empty();
	$("#containerBodywork").empty();
	$("#containerEngine").empty();
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$.get(url, function(data) { 
		console.log(data);
		// empty field
		$("#containerModel").html(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET SUBMODELS
function G21_getSubmodelInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=submodel&LanguageCode='+lang+'&model='+$('#inputModel').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerSubmodel").empty();
	$("#containerBodywork").empty();
	$("#containerEngine").empty();
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$.get(url, function(data) { 
		$("#containerSubmodel").html(data);
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET BODYWORKS
function G21_getBodyworkInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=bodywork&LanguageCode='+lang+'&submodel='+$('#inputSubmodel').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerBodywork").empty();
	$("#containerEngine").empty();
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$("#containerBodywork").load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET ENGINES
function G21_getEngineInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=engine&LanguageCode='+lang+'&bodywork='+$('#inputBodywork').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerEngine").empty();
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$("#containerEngine").load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET FOCUSCODES
function G21_getFokuscodeInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=fokuscode&LanguageCode='+lang+'&engine='+$('#inputEngine').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerFokuscode").empty();
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$("#containerFokuscode").load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET MILEAGE
function G21_getMileageInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=mileage&LanguageCode='+lang+'&fokuscode='+$('#inputFokuscode').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerMileage").empty();
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get items
	$("#containerMileage").load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET COLOR
function G21_getColorInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=color&LanguageCode='+lang+'&mileage='+$('#inputMileage').val();
	url = encodeURI(url);

	// empty following fields
	$("#containerColor").empty();
	$("#containerEquipment").empty();

	// get makes
	$("#containerColor").load(url, function(data) { 
		console.log(data);
		// Set focus
		G21_focusInput();
		// update submit button
		G21_getSubmitButton();
		});
	}


//////////////////////////////////////////////////////////


// GET EQUIPMENT
function G21_getEquipmentInput(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	if($('#inputMake').val()!='' && $('#inputMonth').val()!='' && $('#inputYear').val()!='' && $('#inputModel').val()!='' && $('#inputSubmodel').val()!='' && $('#inputBodywork').val()!='' && $('#inputEngine').val()!='' && $('#inputFokuscode').val()!='' && $('#inputMileage').val()!='' && $('#inputColor').val()!='')
		{
		// url + action + vars
		var url = requestUrl+'?action=equipment&LanguageCode='+lang+'&color='+$('#inputColor').val();
		url = encodeURI(url);

		// get makes
		$("#containerEquipment").load(url, function(data) { 
			//console.log(data);
			// Bugfix - weil sonst equipment sonst nicht zuverlaessig befuellt
			$("#containerEquipment").html(data);
			});
		}
	else
		{
		// empty field
		$("#containerEquipment").empty();
		}

	// update submit button
	G21_getSubmitButton();
	}


//////////////////////////////////////////////////////////


// UPDATE EQUIPMENT
function G21_updateEquipment(field)
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	// url + action + vars
	var url = requestUrl+'?action=equipmentupdate&LanguageCode='+lang+'&warranty='+$('#inputWarranty').val();

	// get selected options
	if($('input','#containerBasic').length > 0)
		{
		$('input','#containerBasic').each(function() {
			if($(this).prop('checked')==true)
				{ url+= '&' + $(this).attr('name') + '=' + $(this).val(); }
			});
		}
	// URL-Fragment to enable delete all equipments
	url+= '&equipments[]=';

	// get selected options
	if($('input','#containerOption').length > 0)
		{
		$('input','#containerOption').each(function() {
			if($(this).prop('checked')==true)
				{ url+= '&' + $(this).attr('name') + '=' + $(this).val(); }
			});
		}

	// get selected options
	if($('input','#containerElse').length > 0)
		{
		$('input','#containerElse').each(function() {
			if($(this).prop('checked')==true)
				{ url+= '&' + $(this).attr('name') + '=' + $(this).val(); }
			});
		}
	// URL-Fragment to enable delete all options
	url+= '&options[]=';

	// HU/AU
	url+= '&huau='+$('#inputHuau').val()

	url = encodeURI(url);

	// get makes
	$.get(url, function(data) { 
		console.log(data);
		});

	// update submit button
//	G21_getSubmitButton();
	}


//////////////////////////////////////////////////////////


// GET SUBMIT-BUTTON
function G21_getSubmitButton()
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

//	if($('#inputMake').val()!='' && $('#inputMonth').val()!='' && $('#inputYear').val()!='' && $('#inputModel').val()!='' && $('#inputSubmodel').val()!='' && $('#inputBodywork').val()!='' && $('#inputEngine').val()!='' && $('#inputFokuscode').val()!='' && $('#inputMileage').val()!='' && $('#inputColor').val()!='')
//		{
		// url + action + vars
		var url = requestUrl+'?action=button&LanguageCode='+lang+'';
		url = encodeURI(url);

		// get submit button
		$("#containerSubmit").load(url, function(data) { 
			//console.log(data);
			});
//		}
//	else
//		{
//		// empty field
//		$("#containerSubmit").empty();
//		}

	// Temp preiscontainer loeschen
	$("#containerPrice").empty();
	}


//////////////////////////////////////////////////////////


// Fahrzeugpreis berechnen
function G21_calcCar()
	{
	// get current language from url
	var lang = window.location.pathname.split("/")[1];

	if($('#inputMake').val()!='' && $('#inputMonth').val()!='' && $('#inputYear').val()!='' && $('#inputModel').val()!='' && $('#inputSubmodel').val()!='' && $('#inputBodywork').val()!='' && $('#inputEngine').val()!='' && $('#inputFokuscode').val()!='' && $('#inputMileage').val()!='' && $('#inputColor').val()!='')
		{
		// url + action + vars
		var url = requestUrl+'?action=calc&LanguageCode='+lang+'';
		// get submit button
		$("#containerPrice").load(url, function(data) { 
			//console.log(data);
			});
		}
	else
		{
		// empty field
		$("#containerPrice").empty();
		}
	}

