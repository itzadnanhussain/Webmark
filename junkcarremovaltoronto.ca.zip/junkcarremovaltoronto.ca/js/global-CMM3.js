// V 1.0.0 erstes Relaese
// V 1.0.1 Image-Caroussel added
// V 1.0.2 Scroll to content added

// BEGIN CMM3 STANDARD
$(document).ready(function()
	{
	// Check touch
	if(CMM3_isTouch())
		{ $('BODY').addClass('is-touch'); }
	else
		{ $('BODY').addClass('is-no-touch'); }

	// Lightbox
	$("A.lightbox").each(function(){ 
		$(this).colorbox({rel:$(this).attr('data-group'), maxWidth:'95%', maxHeight:'95%',previous:'&#xf053;' ,next:'&#xf054;' ,close:'&#xf00d;', current:'', slideshow:true, slideshowAuto:false, slideshowStart:'&#xf04b;' , slideshowStop:'&#xf04c;'}); 
		}); 

	// Galerie im Content
	$('.CMM_Contents_imagesGallery').cmm3gallery();

	// Image-Slider im Content
	$('.CMM_Contents_imagesSlider UL').bxSlider({auto:true, mode:'horizontal', touchEnabled:false, speed:1000, pause:6000, pager:true, controls:true, tickerHover:true, prevText:'&#xf053;', nextText:'&#xf054;'});

	// Image-Caroussel im Content
	var tempCaroussel = new Array;
	$('.CMM_Contents_imagesCaroussel').append('<DIV class="slideMargin" />');
	$('.CMM_Contents_imagesCaroussel').imagesLoaded(function(){
		$('.CMM_Contents_imagesCaroussel').each(function(index) {
			tempCarousselItemWidth = $('UL LI',$(this)).first().width();
			tempCarousselItemMargin = $('.slideMargin',$(this)).width();
			tempCaroussel[index] = $('UL',$(this)).bxSlider({auto:false, pager:true, controls:true, mode:'horizontal', speed:500, pause:8000, minSlides:1, maxSlides:10, moveSlides:1, slideWidth:tempCarousselItemWidth, slideMargin:tempCarousselItemMargin, tickerHover:true, prevText:'&#xf053;', nextText:'&#xf054;' });
			});
		}); 
	// Reload on window resize
	$(window).bind("resize", function(){
		$('.CMM_Contents_imagesCaroussel').each(function(index) {
			tempCaroussel[index].destroySlider();
			tempCarousselItemWidth = $('UL LI',$(this)).first().width();
			tempCarousselItemMargin = $('.slideMargin',$(this)).width();
			tempCaroussel[index].reloadSlider({auto:false, pager:true, controls:true, mode:'horizontal', speed:500, pause:8000, minSlides:1, maxSlides:10, moveSlides:1, slideWidth:tempCarousselItemWidth, slideMargin:tempCarousselItemMargin, tickerHover:true, prevText:'&#xf053;', nextText:'&#xf054;' });
			});
		}); 

	// Datepicker
	$('INPUT.date, INPUT.datetimeDate').Zebra_DatePicker({format:'d.m.Y',zero_pad:true});

	// Video-Player
	$('.videoPlayer').flowplayer("CMM/template/js/flowplayer-3.2.16.swf");

	// Audio-Player
	$('.CMM_audio AUDIO').mediaelementplayer({alwaysShowControls:true, features:['playpause','progress','current','duration','volume'], audioVolume:'horizontal', audioWidth:'100%'});

	// E-Mail-Icon
	$('.iconMailAt').text('@');

	// Remove error-class on input-fields
	$('.CMM_formField').on('click',function() {
		$(this).removeClass('CMM_formFieldError');
		});

	// Top-Links
	$('#linkTop A,.CMM_topLink A').on('click',function(){
		$('html, body').animate({scrollTop: '0px'}, 600);
		return false;
		});

	// Scroll to content
	$(".CMM_Contentindex A").on('click',function(e) { 
	    e.preventDefault();
		contentLink = $(this).attr('href');
		contentLinkHash = contentLink.substring(contentLink.indexOf("#")+1);
      	// Call the scroll function
	  	$('html,body').animate({scrollTop: $("#"+contentLinkHash).offset().top},'slow');
		});

	// Sitemap
	$(".CMM_sitemap").treeview({collapsed:true, animated: "medium"});

	// List type
	if($('.CMM_listtypebar').length)
		{ $('.CMM_listtypebar').each(function() { CMM3_changeListType($(this)); }); }

	// nur wenn nicht Druckansicht
	if(!$('.pagePrint').length)
		{
		// Table pagination
		$('.CMM_tablePagination').each(function() { CMM3_paginateTable($(this)); });

		// Toggle
		$('.CMM_Contents_Type100 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Head').showhide({target_obj: '$obj.next()', use_cookie: false, default_open: false});

		// Tabs - aus Inhalten konstruieren
		$('.CMM_Contents_Type101 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents').each(function() {
			tabsHead = $('<ul class="tabs">');
			$('> .CMM_Contents_contentBlock',$(this)).each(function() {
				tabid = $(this).attr('id');
				tabtitle = $(' > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Head',this).text();
				tabsHead.append('<li><a href="#'+tabid+'" title="">'+tabtitle+'</a></li>');
				});
			$(this).wrapInner('<div class="items">');
			$(this).prepend(tabsHead);
			});
		$(".CMM_Contents_Type101 .CMM_Contents_contentBlock_Subcontents > UL").idTabs(function(id,list,set){ 
			$("a",set).removeClass("selected").filter("[href='"+id+"']",set).addClass("selected");
			for(i in list) $(list[i]).hide(); $(id).fadeIn(); return false;
			});

		// Accordion aus Subinhalten
		$('.CMM_Contents_Type102 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents').find('> .CMM_Contents_contentBlock > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Head').each(function(){
			$(this).addClass('accordionToggle'); 
			$(this).next().addClass('accordionContent'); 
			});
		tempAcc = $('.CMM_Contents_Type102 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents').accordion({ header:'.accordionToggle', active:false, alwaysOpen:false, autoheight:false });
		$('.CMM_Contents_Type102 .CMM_Contents_Type104').each(function() {
			tempAcc.activate($(this).index());
			});

		// Accordion im Inhalt
		$('.CMM_Contents_Type103 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content').find('H2,H3,H4').each(function(){ 
			var $accContentSet = $(this).nextUntil("H2,H3,H4");
			$accContentSet.wrapAll('<div class="accordionContent" />'); 
			$(this).wrapAll('<div class="accordionToggle" />'); 
			});
		$('.CMM_Contents_Type103 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content').accordion({ header:'.accordionToggle', active:false, alwaysOpen:false, autoheight:false });

		// Content-Slider aus Inhalten
		$('.CMM_Contents_Type105 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents').bxSlider({auto:false, mode:'fade', touchEnabled:false, speed:1000, pause:6000, pager:true, controls:true, tickerHover:true, prevText:'&#xf053;', nextText:'&#xf054;'});

		// Timeline - aus Inhalten konstriueren und Plugin
		$('.CMM_Contents_Type106 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents').each(function() {
			$(this).wrapInner('<div class="items">');
			tabsHead = $('<ul class="tabs">');
			$(this).prepend(tabsHead);
			$('.CMM_Contents_contentBlock_Head',this).each(function() {
				id = $(this).closest('.CMM_Contents_contentBlock').attr('id');
				tabsHead.append('<li><a href="#'+id+'" title="">'+$(this).text()+'</a></li> ');
				});
			});
		$(".CMM_Contents_Type106 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content > .CMM_Contents_contentBlock_Subcontents > UL").idTabs(function(id,list,set){ 
			$("a",set).removeClass("selected").filter("[href='"+id+"']",set).addClass("selected");
			for(i in list) $(list[i]).hide(); $(id).fadeIn(); return false;
			});
		}
	
	// Text-Spalten
	$('.CMM_Contents_Type51 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content').columnize({columns:2, lastNeverTallest:true});
	$('.CMM_Contents_Type52 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content').columnize({columns:3, lastNeverTallest:true});
	$('.CMM_Contents_Type53 > .CMM_Contents_contentBlock_Inner > .CMM_Contents_contentBlock_Content').columnize({columns:4, lastNeverTallest:true});

	// Count-Up - requires counter-plugin from functions-CMM3.js and easing-plugin
	countUpElem = new Array();
	$('.CMM_Contents_Type64 .CMM_Contents_contentBlock_Head H1, .CMM_Contents_Type64 .CMM_Contents_contentBlock_Head H2, .CMM_Contents_Type64 .CMM_Contents_contentBlock_Head H3, .countUp').each(function(index) {
		viewportHeight = (window.innerHeight || document.documentElement.clientHeight);
		countUpElem[index] = $(this);
		countUpElem[index].data('countUp',countUpElem[index].text()).text('0');
		countUpElem[index].counter({ autoStart:false, duration:2500, countFrom:0, countTo:countUpElem[index].data('countUp'), placeholder:0, easing:"easeOutCubic", onComplete:function() { countUpElem[index].addClass('counted'); } });
		if(countUpElem[index].offset().top <= $(window).scrollTop()+viewportHeight * 1)
			{ countUpElem[index].counter('start'); }
		// CountUp if scrolled into viewport
		$(document).on('scroll',function() {
			if(countUpElem[index].offset().top < $(window).scrollTop()+viewportHeight-50 && !countUpElem[index].hasClass('counted'))
				{ countUpElem[index].counter('start'); }
			else if(countUpElem[index].offset().top > $(window).scrollTop()+viewportHeight+100 && countUpElem[index].hasClass('counted'))
				{ countUpElem[index].removeClass('counted').text('0');
				}
			});
		});
	// Hoehe der Content-Bloecke in einer Zeile ausgleichen
	$('#contentTop').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
	$('#contentLeft').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
	$('#contentCenter').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
	$('#contentRight').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
	$('#contentBottom').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
	$(window).bind("resize", function(){
		$('#contentTop').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
		$('#contentLeft').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
		$('#contentCenter').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
		$('#contentRight').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
		$('#contentBottom').imagesLoaded(function(){ CMM3_equalizeContentBlockHeight(this); });
		});

	}); 
// ENDE CMM3 STANDARD
