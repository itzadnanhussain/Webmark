     <meta charset="utf-8"> 
     <meta name="description" content="Scrap Car Removal Toronto Buy All type Of Used, Unwanted, Old, Junk vehicles and Offer Top Cash For All these...">  
     <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.75, maximum-scale=1.25">
     <base>
     <link rel="shortcut icon" href="img/logo.png" type="image/x-icon"> 
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
     <?php include'php/load_css.php'?>
     <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
     <script type="text/javascript" src="js/jquery-migrate-1.2.1.min.js"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <!---Tags---------->
     <?php include'php/Tags.php'?>