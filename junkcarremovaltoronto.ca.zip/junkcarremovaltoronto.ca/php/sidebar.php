 <div class="col-sm-4 sidebar-main">
     <aside id="secondary" class="widget-area">
         <section id="search-2" class="widget1 widget_search">
             <form action="#"> <label for=""> <span class="screen-reader-text">Search for:</span> <input type="search" id="" class="search-field" placeholder="Search …" value="" name="s"> </label> <input type="submit" class="search-submit" value="Search"></form>
         </section>
         <section id="recent-posts-2" class="widget widget_recent_entries">
             <h2 class="widget-title">Recent Posts</h2>
             <ul>
                 <li> <a href="How-To-Know-If-a-Company-is-a-License- Wrecker-in-Milton.php">How To Know If a Company is a Licensed Wrecker in Milton&hellip;</a></li>
             </ul>
              <ul>
                 <li> <a href="selling-your-old-car.php">Selling Your Old Car? Get Instant Cash on the Spot!</a></li>
             </ul>
              
             <ul>
                 <li> <a href="Junk-Car-Removal-Milton.php" rel="bookmark">Junk car? Get Instant Cash For Its Removal</a></li>
             </ul>
              
              
         </section>
         
     </aside>
 </div>