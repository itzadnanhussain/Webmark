 <footer id="footWrapper">
     <div id="footArea">
         <div id="footContainer">
             <div id="contentColumnFoot">
                 <div id="contentFoot">
                     <section class="CMM_Contents_contentBlock CMM_Contents_Size31" id="content_113">
                         <div class="CMM_Contents_contentBlock_Inner">
                             <div class="CMM_Contents_contentBlock_Head">
                                 <h3 class="title">Our Services</h3>
                             </div>
                             <div class="CMM_Contents_contentBlock_Content">
                                 <div class="naviSeo">
                                     <ul>
                                         <li class="nor firstItem lastItem"><a href="Accident-Car-Removal-Toronto.php" title=" ">Accident Car Removal Toronto</a></li>
                                    <li class="nor firstItem lastItem"><a href="Old-Car-Removal-Toronto.php" title=" ">Old Car Removal Toronto</a></li>
                                    <li class="nor firstItem lastItem"><a href="Damaged-Car-Removals-Toronto.php" title=" ">Damaged Car Removal Toronto</a></li>
                                     <li class="nor firstItem lastItem"><a href="Unwanted-Car-Removal-Toronto.php" title=" ">Unwanted Car Removal Toronto</a></li>
                                     <li class="nor firstItem lastItem"><a href="Wrecked-Car-Removals-Toronto.php" title=" ">Wrecked Car Removal Toronto</a></li>
                                     </ul>
                                 </div>
                             </div>
                         </div>
                     </section>
                     <section class="CMM_Contents_contentBlock CMM_Contents_Size31" id="content_114">
                         <div class="CMM_Contents_contentBlock_Inner">
                             <div class="CMM_Contents_contentBlock_Head">
                                 <h3 class="title">Recent Posts</h3>
                             </div>
                             <div class="CMM_Contents_contentBlock_Content">
                                 <div class="naviSeo">
                                     <ul>
                                         <li class="nor firstItem lastItem"><a href="4-Indications-For-Scrap-Your-Car.php" title="4 Indications For Scrap Your Car">4 Indications For Scrap Your Car</a></li>
                                    <li class="nor firstItem lastItem"><a href="Our-Charity-Work.php" title="Our Charity Work">Our Charity Work </a></li>
                                    <li class="nor firstItem lastItem"><a href="Top-Dollar-Cash-for-Written-Off-Cars-Removal.php" title="Top Dollar Cash for Written Off Cars Removal">Top Dollar Cash for cars</a></li>
                                     <li class="nor firstItem lastItem"><a href="Why-Your-Car-Is-Not-Start-when-its-Cold.php" title="Why Your Car Is Not Start when it’s Cold?">Why Your Car Is Not Start when..</a></li>
                                      <li class="nor firstItem lastItem"><a href="What-is-a-V5C.php" title="What is a V5C and Do I Need a V5C to Scrap My Car?">What is a V5C...</a></li>
                                     </ul>
                                 </div>
                             </div>
                         </div>
                     </section>
                      <section class="CMM_Contents_contentBlock CMM_Contents_Size31" id="content_114">
                         <div class="CMM_Contents_contentBlock_Inner">
                             <div class="CMM_Contents_contentBlock_Head">
                                 <h3 class="title">Contact Us</h3>
                             </div>
                             <div class="CMM_Contents_contentBlock_Content">
                                 <div class="naviSeo">
                                     <ul>
                                    <li class="nor firstItem lastItem"><a href="#" title="Our Email">Email: Carclunker@gmail.com</a></li>
                                    <li class="nor firstItem lastItem"><a href="#" title="Contact Number">Phone:(647) 484-7006 </a></li>
                                    <li class="nor firstItem lastItem"><a href="#" title="Our Location"> Address: Toronto, ON, Canada</a></li>
                                     
                                     </ul>
                                 </div>
                             </div>
                         </div>
                     </section>
                     
                 </div>
             </div>
             <div style="clear:both;"></div>
         </div>
     </div>
     <div id="bottomArea">
         <div id="bottomContainer">
             
             <div id="copyright">&copy; 2019 Junk Car Removal Toronto &bull; All rights reserved</div>
         </div>
     </div>
 </footer>
 <?php include'php/load_js.php'?>