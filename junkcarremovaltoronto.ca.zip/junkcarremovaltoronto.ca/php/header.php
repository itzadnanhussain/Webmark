  <header id="headArea">
            <div id="headContainer">
                <div id="logo"><a href="index.php" title="Home"><img src="img/logo.png" alt="Logo"></a></div>
                <div id="hotline"> <span>Free Toronto junk car removal Company</span>
                    <p><i class="fa fa-phone-square"></i> <a href="tel: (647) 484-7006"> (647) 484-7006</a></p>
                    <ul>
                         
                        <li><i style="width: 1em; text-align: center;" class="fa fa-envelope"> </i><strong><a href=" ');">E-Mail:Carclunker@gamil.com</a></strong></li>
                    </ul>
                </div>
                
                
                <div id="socialIcons">
                    <ul>
                        <li class="facebook"><a href=" " target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                        <li class="googleplus"><a href=" " target="_blank" title="Google+"><i class="fa fa-google-plus"></i></a></li>
                    </ul>
                </div>
            </div>
            
            <div id="naviArea">
                <div id="naviContainer">
                    <nav id="naviMain">
                        <ul>
                            <li class="cur firstItem">
                                <div id="naviMain_6"><a href="index.php" title="Home">Home</a></div>
                            </li>
                             <li class="nor">
                                <div id="naviMain_10"><a href="about-us.php" title="About us">About us</a></div>
                            </li> 
                            <li class="nor sub">
                                <div id="naviMain_12"><a href="services.php" title="Car sale tips">Services</a></div>
                                <ul>
                                    <li class="nor firstItem lastItem"><a href="Accident-Car-Removal-Toronto.php" title=" ">Accident Car Removal Toronto</a></li>
                                    <li class="nor firstItem lastItem"><a href="Old-Car-Removal-Toronto.php" title=" ">Old Car Removal Toronto</a></li>
                                    <li class="nor firstItem lastItem"><a href="Damaged-Car-Removals-Toronto.php" title=" ">Damaged Car Removal Toronto</a></li>
                                     <li class="nor firstItem lastItem"><a href="Unwanted-Car-Removal-Toronto.php" title=" ">Unwanted Car Removal Toronto</a></li>
                                     <li class="nor firstItem lastItem"><a href="Wrecked-Car-Removals-Toronto.php" title=" ">Wrecked Car Removal Toronto</a></li>
                                </ul>
                            </li>
                            <li class="nor sub">
                                <div id="naviMain_12"><a href="blog.php" title="">Blog</a></div>
                                <ul>
                                    <li class="nor firstItem lastItem"><a href="4-Indications-For-Scrap-Your-Car.php" title="4 Indications For Scrap Your Car">4 Indications For Scrap Your Car</a></li>
                                    <li class="nor firstItem lastItem"><a href="Our-Charity-Work.php" title="Our Charity Work">Our Charity Work </a></li>
                                    <li class="nor firstItem lastItem"><a href="Top-Dollar-Cash-for-Written-Off-Cars-Removal.php" title="Top Dollar Cash for Written Off Cars Removal">Top Dollar Cash for cars</a></li>
                                     <li class="nor firstItem lastItem"><a href="Why-Your-Car-Is-Not-Start-when-its-Cold.php" title="Why Your Car Is Not Start when it’s Cold?">Why Your Car Is Not Start when it’s Cold?</a></li>
                                      <li class="nor firstItem lastItem"><a href="What-is-a-V5C.php" title="What is a V5C and Do I Need a V5C to Scrap My Car?">What is a V5C...</a></li>
                                </ul>
                            </li>
                            <li class="nor">
                                <div id="naviMain_13"><a href="#" title="FAQ">FAQ</a></div>
                            </li>
                           
                            <li class="nor lastItem">
                                <div id="naviMain_14"><a href="contact.php" title="Contact">Contact</a></div>
                            </li>
                        </ul>
                    </nav>
                    <div id="searchBox">
                        <div id="searchBoxHead"> <a href="#"><i class="fa fa-search"></i></a> </div>
                        <div id="searchBoxContent">
                            <form class="searchBoxForm" id="searchBoxForm" action="#" method="get">
                                <fieldset> <input type="text" name="CMM_Search[q]" id="searchBoxInput" onblur="javascript:if(this.value == '') this.value = 'Search word';" onclick="javascript:if(this.value == 'Search word') this.value = '';" value="Search word" /> <input id="searchBoxSection" type="hidden" name="CMM_Search[section]" value="" /> <input type="submit" id="searchBoxSubmit" value="&#xf002;" /> </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </header>
      
        