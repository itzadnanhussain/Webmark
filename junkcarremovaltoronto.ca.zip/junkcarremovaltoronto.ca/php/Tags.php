<!----Schema Tags----------------->
 <script type="application/ld+json">
{
	"@context": "http://schema.org",
	"@type": "AutomotiveBusiness",
	"name": "Junk Car Removal Toronto",
	"address": {
		"@type": "PostalAddress",
		"streetAddress": "",
		"addressLocality": "Toronto",
		"addressRegion": "ON",
		"postalCode": ""
	},
	"email": "carclunker@gamil.com",
	"paymentAccepted": [ "cash" ],
	"openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 07:00-21:00",
	"openingHoursSpecification": [ {
		"@type": "OpeningHoursSpecification",
		"dayOfWeek": [
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
			"Sunday"
		],
		"opens": "07:00",
		"closes": "21:00"
	} ],
	"priceRange":"$$$"

}
</script>
