<style>
    <?php 
    include'css/style.css';
    include'css/custom.css';
    include'css/sweetalert.min.css';
    ?>
</style>