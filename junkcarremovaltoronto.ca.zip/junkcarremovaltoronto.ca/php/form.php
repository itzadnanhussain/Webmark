 <form action="php/email.php"  method="post" data-action="ajax" id="messageform">
     <div class="CMM_form">
         <div class="CMM_formContent">
             <fieldset class="CMM_formColumn CMM_formColumn_Size11">
                <!---Name--->
                 <div class="CMM_formField CMM_formFieldTypeText" data-type="text"> <label class="fieldLabel" for="content_75_form_Name">Name <span class="requiredMarker"></span></label><input type="text" name="name" class="text" id="content_75_form_Name" maxlength="50" data-validate="text" required placeholder="Name*" value=""></div>
                 
                  <!---Email--->
                 <div class="CMM_formField CMM_formFieldTypeText" data-type="text"> <label class="fieldLabel" for="content_75_form_Name">Email <span class="requiredMarker"></span></label><input type="text" name="email" class="text" id="content_75_form_Name" maxlength="50" data-validate="text" required placeholder="Email*" value=""></div>
                 <!---Phone--->
                 <div class="CMM_formField CMM_formFieldTypePhone" data-type="phone"> <label class="fieldLabel" for="content_75_form_Telefon">Phone <span class="requiredMarker"></span></label><input type="text" name="phone" class="phone" id="content_75_form_Telefon" maxlength="50" data-validate="phone" required placeholder="Phone*" value=""></div>
                 
                 
                  <!---Address--->
                 <div class="CMM_formField CMM_formFieldTypeText" data-type="text"> <label class="fieldLabel" for="content_75_form_Name">Address <span class="requiredMarker"></span></label><input type="text" name="address" class="text" id="content_75_form_Name" maxlength="50" data-validate="text" required placeholder="Address*" value=""></div>
                 
                 <div class="CMM_formField CMM_formFieldTypeTextarea" data-type="textarea"> <label class="fieldLabel" for="content_75_form_Nachricht">Message</label><textarea name="message" class="textarea" id="content_75_form_Nachricht" data-validate="textarea" rows="2" placeholder="Message"></textarea></div>
             </fieldset>
             <div style="clear:both;"></div>
         </div>
         <div class="CMM_formFoot">
         <input type="submit" class="CMM_button CMM_submit" value="Send"> 
         </div>
 </form>