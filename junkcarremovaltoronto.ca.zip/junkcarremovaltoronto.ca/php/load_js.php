 <script type="text/javascript" src="js/jquery.min.js"></script>
 <script type="text/javascript" src="js/sweetalert.min.js"></script>
 <script type="text/javascript" src="js/email.js"></script>
 <!---Clear------------>
 <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
 <script type="text/javascript" src="js/jquery.hoverIntent.min.js"></script>
 <script type="text/javascript" src="js/jquery.colorbox.min.js"></script>
 <script type="text/javascript" src="js/jquery.cookie.min.js"></script>
 <script type="text/javascript" src="js/jquery.showhide.min.js"></script>
 <script type="text/javascript" src="js/jquery.datepicker.min.js"></script>
 <script type="text/javascript" src="js/jquery.easing.min.js"></script>
 <script type="text/javascript" src="js/jquery.imagesloaded.min.js"></script>
 <script type="text/javascript" src="js/jquery.gomap.min.js"></script>
 <script type="text/javascript" src="js/jquery.cmm3gallery.min.js"></script>
 <script type="text/javascript" src="js/jquery.bxslider.min.js"></script>
 <script type="text/javascript" src="js/jquery.columnizer.min.js"></script>
 <script type="text/javascript" src="js/jquery.accordion.min.js"></script>
 <script type="text/javascript" src="js/jquery.idTabs.min.js"></script>
 <script type="text/javascript" src="js/jquery.treeview.min.js"></script>
 <script type="text/javascript" src="js/jquery.responsiveMenu2.min.js"></script>
 <script type="text/javascript" src="js/jquery.flowplayer.min.js"></script>
 <script type="text/javascript" src="js/mediaelement-and-player.min.js"></script>
 <script type="text/javascript" src="js/functions-CMM3.js"></script>
 <script type="text/javascript" src="js/global-CMM3.js"></script>
 <script type="text/javascript" src="js/global.js"></script>