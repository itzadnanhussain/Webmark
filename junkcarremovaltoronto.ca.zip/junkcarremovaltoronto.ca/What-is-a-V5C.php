<html lang="en">
<title>What is a V5C and Do I Need a V5C to Junk My Car?</title>
<?php include'php/head.php'?>

<body>
    <div id="wrapper" class="page6 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code----->

        <!--Close Header Code----->
        <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                    <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="index.php" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="act"><a href="blog.php" title="Junk car removal services"><i class="fa fa-angle-right"></i>blog</a></li>
                        <li class="cur lastItem"><a href="What-is-a-V5C.php" title="What is a V5C and Do I Need a V5C to Junk My Car?"><i class="fa fa-angle-right"></i>What is a V5C and Do I Need a V5C to Junk My Car?</a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_109">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">What is a V5C and Do I Need a V5C to Junk My Car?</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">If you have decided to Junk your car then there is a great option, there are some things that most people not sure about it. One of the questions is about “The V5C and Is it important or not” - to Junk my car.</p>
                                    <p class="text-justify">V5C is a vehicle Registration document or log book. It is the document that registers your vehicle with the Driver and Vehicle Licensing Agency (DVLA). It contains all the important information regarding your automotive, like the data it had been first registered, its manufacturer and also the color and engine size. It also shows who is the registered keeper of the vehicle. It’s vital to know that the registered keeper and owner are different things. You have to tell the DVLA if your car has been scrapped or written off. Normally you don’t want to contact DVLA to change the details on the V5C. Although, if there are any mistakes on it, you modify your name or address and you may also make changes to the vehicle, otherwise you sell your vehicle. So, you have to contact them. V5C is normally maroon and blue on the front side and pale green and blue on the back side.If you are planning to sell your Junk car and you don’t have the log book, you have to read this to find out the answer. Because the important things that we are going to tell you will save your money and assist you to avoid some of the less honorable junk car dealers out there. </p>
                                    <p class="text-justify">Legally, you don’t need the V5C document to Junk a car. Mostly, to switch a V5C document you have to contact the DVLA s and pay a fee. But once scrapping your car, you just inform DVLA in writing to allow them to recognize that you have sold-out the vehicle for scrap. It is very important to provide DVLA with all the details and information, registration number, make and model of the car. They will update your data or records. </p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_110">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h2 class="title">Don’t Buy a Car Without a V5C (logbook)</h2>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify"> Some companies won’t purchase a Junk car from you unless you have got the V5C or logbook. This is actually because, in the past years, few local authorities force the dealers to possess documentation for purchases and sales. However, having the V5C document is not vital anymore, as the Junk Metal Dealers Act 2013 means that dealers need to get photo ID and proof of</p>
                                    <p class="text-justify">Address from sellers. when you sell your Junk car to Junk car removal service Stratford, you are unlikely to run into this condition. Mostly Junk car dealers simply accept your car without any log book. If you live in one of the few places wherever our dealers still want log books or V5C document and if your log book has been stolen or lost then you don’t have to worry we will help you and do everything for you. We are ready to convince our team members to just accept the Junk car and do everything to buy your end of life vehicles. It helps if you have got the log book, however it is not important. What we need to ask for, by law, utility bill and photo ID of those people who are selling the car. </p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">Can I Still Junk My Car?</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">Have you lost your V5C document? </p>
                                    <p class="text-justify">I have good news for you; Yes! you will be able to still Junk your car without your log book. Don’t need to worry, we can still collect your car – there is actually no legal requirement for it. Registering your automobile as scrapped may be a little more complicated without a log book or V5C document.</p>
                                    <p class="text-justify">If you want to Junk your car with us, however you don’t have the log book. First of all, you need to know. We will be ready to set a collection date for you. Our well-trained and experienced drivers arrive at your property and tow your car away at no cost to you. You need to inform the DVLA that you are scrapping the car with us. You have to give the following information. </p>
                                    <ul>
                                        <li>Your complete detail and details about your car like registration number, model and make</li>
                                        <li>Our details</li>
                                        <li>The selling date – from you to us</li>
                                    </ul>
                                    <p class="text-justify">With that data, the DVLA are ready to update your details and make sure now you are not registered.Warning: If Junk car removal Stratford, Junk your vehicle without V5C, you are legally required to inform the DVLA in writing to declare that your unwanted car prepared to be de-registered. If you don’t inform the DVLA then you will pay a heavy fine. </p>
                                    <p class="text-justify">Are you ready to Junk your car? We will offer you the best services. Visit our website and get an instant quote!</p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div id="contentColumnFix"></div>
            </div>
        </div>
        <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
    </div>
</body>

</html>