<html lang="en">
<title>Junk Car Removal Toronto|About Us..</title>
<?php include'php/head.php'?>

<body>
    <div id="wrapper" class="page10 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code-----> 
        <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                    <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="index.php" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="cur lastItem"><a href="about-us.php" title="About us"><i class="fa fa-angle-right"></i>About us</a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_109">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title">We Pay Top Dollar Cash</h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">Do you have an old or Junk car? Looking for fast cash? Well, we are able to assist you to get top dollar cash for your old car. Any make and model we are going to buy for money. </p>
                                </div>
                            </div>
                        </section>
                         <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_110">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h2 class="title">Why choose Junk Car Removal Toronto? </h2>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    
                                    <p class="text-justify">Even if your car is not working, it should still be taxed. So as to avoid paying further road tax, it is better to sell or Junk your damaged vehicle as soon as possible and enjoy top dollar cash.</p>
                                    <p class="text-justify">We make sure that your vehicle is scrapped or disposed by an Authorized Treatment Facility (ATF).</p>
                                    <p class="text-justify">It doesn’t matter what type and condition your vehicle is in, we will organize a FREE pick up of your damaged car in where in Toronto.</p>
                                    <p class="text-justify">Cars are usually scrapped because of accident, fire damage and break down. Junk car has increased in value over many years, so once your automobile will reach the end of its life, that doesn’t mean that it’s not valuable to others.</p>
                                    <p class="text-justify">You simply call us in these days, and we can aware you the whole process. Instead, you will be able to read our guide thus you already recognize what the method is all about. </p>

                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title"></h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                    <p class="text-justify">Call us today or fill the form to get an instant online quotation.</p>
                                </div>
                            </div>
                        </section>
                   
                     </div>
                </div>
                <div id="contentColumnFix"></div>
            </div>
        </div> 
        <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
    </div>
</body>

</html>