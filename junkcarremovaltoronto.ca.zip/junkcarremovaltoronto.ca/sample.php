<html lang="en">
    <title>Scrap Car Removal Toronto|Accident Car Removal Toronto</title>
    <?php include'php/head.php'?>
    <body>
        <div id="wrapper" class="page6 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code----->
        
         <!--Close Header Code----->
         <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                   <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="index.php" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="act"><a href="blog.php" title="scrap car removal services"><i class="fa fa-angle-right"></i>blog</a></li>
                        <li class="cur lastItem"><a href="" title="xx"><i class="fa fa-angle-right"></i>xxxx</a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_109">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title"> </h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                   <p class="text-justify"></p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_110">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h2 class="title"> </h2>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                   <p class="text-justify"></p>
                                </div>
                            </div>
                        </section>
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_111">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">
                                    <h1 class="title"></h1>
                                </div>
                                <div class="CMM_Contents_contentBlock_Content">
                                  <p class="text-justify"></p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
                <div id="contentColumnFix"></div>
            </div>
        </div> 
         <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
        </div>
    </body>
</html>