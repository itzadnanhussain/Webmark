<html lang="en">
<title>Junk Car Removal Toronto|..</title>
<?php include'php/head.php'?>

<body>
    <div id="wrapper" class="page6 lang2">
        <!---Open Header Code----->
        <?php include'php/header.php'?>
        <!--Close Header Code----->

        <div id="contentArea">
            <div id="contentContainer">
                <div id="naviClickpath">
                    <ul>
                        <li class="clickpathLabel">You are here:</li>
                        <li class="act firstItem"><a href="index.php" title="Website"><i class="fa fa-angle-right"></i>Website</a></li>
                        <li class="cur lastItem"><a href="contact.php" title="Contact"><i class="fa fa-angle-right"></i>Contact</a></li>
                    </ul>
                </div>
                <div id="contentColumnCenter">
                    <div id="contentTop">
                        <!-----Contact----->
                        <section class="CMM_Contents_contentBlock CMM_Contents_Size32" id="content_74">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <div class="CMM_Contents_contentBlock_Head">

                                    <h1 class="title"><span class='mark1'>Contact</span> Us:</h1>
                                    <div class="contact-list">
                                        <p>Email: <span class='mark1'>carcluker@gamil.com</span></p>
                                        <p>Phone: <span class='mark1'>(647) 484-7006</span></p>
                                        <p>Address: <span class='mark1'>Toronto, ON, Canada</span></p>
                                    </div>

                                </div>
                                <div class="CMM_Contents_contentBlock_Content">

                                </div>
                            </div>
                        </section>

                        <section class="CMM_Contents_contentBlock CMM_Contents_Size31 CMM_Contents_Type13" id="content_75">
                            <div class="CMM_Contents_contentBlock_Inner">

                                <div class="CMM_Contents_contentBlock_Content">
                                    <p>Get A Quote Now</p>

                                    <div>
                                        <div class="CMM_formContainer" id="form_content_75_form">
                                            <?php include'php/form.php'?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </section>

                        <section class="CMM_Contents_contentBlock CMM_Contents_Size0" id="content_150">
                            <div class="CMM_Contents_contentBlock_Inner">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d184551.80857816365!2d-79.51814416495607!3d43.71840381269127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4cb90d7c63ba5%3A0x323555502ab4c477!2sToronto%2C%20ON%2C%20Canada!5e0!3m2!1sen!2s!4v1572069164197!5m2!1sen!2s" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                            </div>
                        </section>
                    </div>
                </div>

                <div id="contentColumnFix"></div>
            </div>
        </div>


        <!---Open footer Code----->
        <?php include'php/footer.php'?>
        <!--Close footer Code----->
    </div>
</body>

</html>