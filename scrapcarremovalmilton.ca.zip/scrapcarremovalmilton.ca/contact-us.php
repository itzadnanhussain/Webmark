<!DOCTYPE html>
<html lang="en">

<head>
    <title>Scrap Car Removal Contact Us Here!</title>
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Our Scrap car Removal Company provide Free Towing for Your junks ,Old, Unwanted,  Wreckeds and Useless Car.Now Get An Instant Offer Just touch with us!">
<meta name="keywords" content="Scrap car removal, Get Cash For Cars, Dispose Off Car ">
<meta name="robots" content="index, follow">
    <?php include'php/head.php'?>
</head>

<body>

    <!--// Main Wrapper \\-->
    <div class="scrapcar-main-wrapper">

        <!--// Header \\-->
        <?php include'php/header.php'?>
        <!--// Header \\-->

        <!--// subheader \\-->
        <div class="scrapcar-contact-map">
            <div id="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d370386.0161962507!2d-80.17293426775579!3d43.509829380317655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xd2308d11a73172bc!2sScrap%20Car%20Removal%20Milton!5e0!3m2!1sen!2s!4v1570350070808!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </div>
        <!--// subheader \\-->

        <!--// Main Content \\-->
        <div class="scrapcar-main-content">

            <!--// Main Section \\-->
            <div class="scrapcar-main-section">
                <div class="container">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="scrapcar-fancy-titlev2 left-align">
                                <h1>Contact Us</h1>
                                <p>We can be reached at any time, so feel free to give us a call when you require immediate assistance. If you have a question, or you are simply looking for the best price possible, call us and we will make you a fair and honest offer. Our years of experience in this industry has led us to know a thing or two. We will direct you along the right path and make sure you are not being taken for a ride ( no pun intended).
                                    Alternatively, if you do not want to call us, you can also send us an inquiry via email. We can be reached at <span class="hilight">carclunker@gmail.com</span>. One of our expert team members will reply to your query/concern in a timely fashion.
                                </p>
                            </div>
                            <div class="scrapcar-contact-wrap">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="scrapcar-contact-info">
                                            <ul>
                                                <li>
                                                    <div class="scrapcar-contact-info-text">
                                                        <i class="automechanic-icon automechanic-technology-12"></i>
                                                        <h2>Call Us Now At </h2>
                                                        <span>(647) 691-2932</span>

                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="scrapcar-contact-info-text">
                                                        <i class="automechanic-icon automechanic-interface2"></i>
                                                        <h2>Mail Us At</h2>
                                                        <a href="mailto:carclunker@gmail.com">carclunker@gmail.com</a>

                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="scrapcar-contact-info-text">
                                                        <i class="automechanic-icon automechanic-location"></i>
                                                        <h2>Find Us At</h2>
                                                        <span>Milton, ON, Canada
                                                            Oakville, ON, Canada</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <div class="scrapcar-contact-form">
                                            <?php include'php/form.php'?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--// Main Section \\-->


        </div>

        <!--// Main Content \\-->

        <!--// Footer \\-->
        <?php include'php/footer.php'?>
        <div class="clearfix"></div>
    </div>
</body>

</html>