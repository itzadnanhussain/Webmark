<script>
    <?php
    /*
    include'js/jquery.js';
    include'js/jquery-ui.js';
    include'js/bootstrap.min.js';
    include'js/slick.slider.min.js';
    include'js/fancybox.pack.js';
    include'js/isotope.min.js';
    include'js/progressbar.js';
    include'js/numscroller.js';
    include'build/mediaelement-and-player.min.js';
    include'js/functions.js';
    */
    ?>
</script>
<!-- jQuery (necessary for JavaScript plugins) -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/slick.slider.min.js"></script> 
<script type="text/javascript" src="build/mediaelement-and-player.min.js"></script> 
<script type="text/javascript" src="js/custom.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>