	<h2 class="scrapcar-section-heading">Comments</h2>
								<div class="comments-area">
			                       <!--// coments \\-->
		                          <ul class="comment-list">
		                             <li>
		                                <div class="thumb-list">
		                                   <figure><img alt="" src="extra-images/comment-img1.jpg"></figure>
		                                   <div class="text-holder">
		                                      <h6>Merry Doe<small>@merry_doe</small></h6>
		                                      <time class="post-date" datetime="2008-02-14 20:00">August 21, 2017 . 11:39 pm </time>
		                                      <p>Etiam auctor dignissim bibendum. Nunc pulvinar massa nunc, quis pellentesque felis suscipit eu hase llus ut ultrici veliti Morbi non nisl condimentum.</p>
		                                      <a class="comment-reply-link" href="#"><i class="fa fa-reply"></i>Reply</a>
		                                   </div>
		                                </div>
		                             </li>
		                              <!-- #comment-## -->
		                             <li>
		                                <div class="thumb-list">
		                                   <figure><img alt="" src="extra-images/comment-img2.jpg"></figure>
		                                   <div class="text-holder">
		                                      <h6>Darren Roy</h6>
		                                      <time class="post-date" datetime="2008-02-14 20:00">August 21, 2017 at 8:55 pm</time>
		                                      <p>Sed diam risus, auctor et dui vel, rhoncus finibus lorem. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris tempor ante vitae felis bibendum gravida.</p>
		                                      <a class="comment-reply-link" href="#"><i class="fa fa-reply"></i>Reply</a>
		                                   </div>
		                                </div>
		                                <ul class="children">
		                                   <li>
		                                      <div class="thumb-list">
		                                         <figure><img alt="" src="extra-images/comment-img3.jpg"></figure>
		                                         <div class="text-holder">
		                                            <h6>Merry Luis</h6>
		                                            <time class="post-date" datetime="2008-02-14 20:00">August 21, 2017 at 8:55 pm</time>
		                                            <p>Suspendisse in euismod ante. Morbi semper lacus quis dolor lacinia fermentum. Duis eget lect us a eros pharetra posuere. Ut tincidunt ipsum nec rhoncus suscipit.</p>
		                                            <a class="comment-reply-link" href="#"><i class="fa fa-reply"></i>Reply</a>
		                                         </div>
		                                      </div>
		                                   </li>
		                                   <!-- #comment-## -->
		                                </ul>
		                                <!-- .children -->
		                             </li>
		                             <li>
		                                <div class="thumb-list">
		                                   <figure><img alt="" src="extra-images/comment-img4.jpg"></figure>
		                                   <div class="text-holder">
		                                      <h6>Mark Paul</h6>
		                                      <time class="post-date" datetime="2008-02-14 20:00">August 21, 2017 at 8:55 pm</time>
		                                      <p>Mauris id tincidunt sapien. In sodales turpis fringilla nunc tincidunt, eu malesuada nunc gravida. Pellentesque orci est, ornare et placerat nec,</p>
		                                      <a class="comment-reply-link" href="#"><i class="fa fa-reply"></i>Reply</a>
		                                   </div>
		                                </div>
		                             </li>
		                             <!-- #comment-## -->
		                          </ul>
		                          <!--// coments \\-->
		                        </div>
		                        <h2 class="scrapcar-section-heading">Leave Your Reply</h2>
								<!--// comment-respond \\-->
		                          <div class="comment-respond">
		                             <form>
		                                <p>
		                                	<label>Name:</label>
		                                   <input type="text" value="Type Your Name" onblur="if(this.value == '') { this.value ='Type Your Name'; }" onfocus="if(this.value =='Type Your Name') { this.value = ''; }">
		                                   <i class="fa fa-user"></i>
		                                </p>
		                                <p>
		                                	<label>Email:</label>
		                                   <input type="email" value="Type Your Email" onblur="if(this.value == '') { this.value ='Type Your Email'; }" onfocus="if(this.value =='Type Your Email') { this.value = ''; }">
		                                   <i class="fa fa-envelope"></i>
		                                </p>
		                                <p class="political-full-form">
		                                	<label>Comment:</label>
		                                   <textarea name="comment" placeholder="Type Your Comment" class="commenttextarea"></textarea>
		                                   <i class="fa fa-commenting"></i>
		                                </p>
		                                <p><label><i class="automechanic-icon automechanic-arrows22"></i><input type="submit" value="Send Now"></label></p>
		                             </form>
		                          </div>
		                          <!--// comment-respond \\-->
						