<link rel="shortcut icon" href="img/fav-icon.png" type="img/fav-icon.png">
<link href="https://fonts.googleapis.com/css?family=Big+Shoulders+Text|PT+Serif&display=swap" rel="stylesheet">
<link rel="shortcut icon" href="css/responsive.css" type="">
<?php include 'load_css.php'?>
<?php include'php/tags.php'?>

