<style>
    <?php 
    include'css/bootstrap.css';
    include'css/style.css';
    include'css/font-awesome.css';
    include'css/flaticon.css';
    include'css/slick-slider.css'; 
    include'build/mediaelementplayer.css';
    include'css/color.css';
    include'css/responsive.css';
    include'css/sweetalert.min.css';
    ?>
</style>
 