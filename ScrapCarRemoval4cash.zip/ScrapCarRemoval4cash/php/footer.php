
        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-12 margin30">
                        <div class="footer-col">
                            <h3>Contact</h3>
                            <ul class="list-unstyled contact">
                                <li>
                                    <p><strong><i class="fa-location2"></i> Address:</strong> 60 Grovewood Drive, Brampton, Ontario</p>
                                </li>
                                <li>
                                    <p><strong><i class="fa-location2"></i> Zip Code:</strong> L7A2K1</p>
                                </li>
                                <li>
                                    <p><strong><i class="fa-envelop"></i> Mail Us:</strong> <a href="#Quote"> Here</a></p>
                                </li>
                                <li>
                                    
                    <form class="num_form" method="post" action="php/count.php"> <p><strong><i class="fa-phone"></i> Phone: </strong><a href="tel:6479736574">647-973-6574</a></p></form>
                                </li>
                                <li>
                                    <p><strong><i class="fa-facebook"></i> Facebook Page:</strong><a href="https://web.facebook.com/ScrapCars4Cash/" rel="nofollow">.../ScrapCars4Cash/</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-12 margin30">
                        <div class="footer-col">
                            <h3>Our Location</h3>
                            <div class="parent_center">
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2885.2656198542227!2d-79.81867268450121!3d43.68424097912023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1f9b78db89270a13!2sScrap+Car+Removal+4+Cash!5e0!3m2!1sen!2s!4v1517751520123" allowfullscreen></iframe>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="footer-btm"> <span><img id="footer_img" class="footer_detail" src="img/footerpic.png" alt="car scrap 4 cash Brampton logo"/>&copy;2017. All Rights Reserved</span> </div>
                    </div>
                </div>
            </div>
        </footer>
        <script src="js/combined.js">
        </script>