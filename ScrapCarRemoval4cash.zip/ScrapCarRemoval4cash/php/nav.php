<a id="home"></a>
<div id="gap"></div>
<div id="fb-root"></div>
<script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span> </button> <a class="navbar-brand" href="http://scrapcars4cash.com/">ScrapCars<b><i>4</i></b>Cash</a></div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a class="submit_btn" href="http://scrapcars4cash.com/#Quote">Get Quote</a></li>
                <li><a href="index.php#work">How it Works?</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Services<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="car-removal-brampton.php">Car Removal Brampton</a></li>
                        <li><a href="scrap-my-car-Brampton.php">Scrap my car</a></li>
                        <li><a href="cash-for-cars-brampton.php">Cash for cars in Brampton</a></li>
                        <li><a href="old-car-removal-brampton.php">Old Car Removal</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Locations<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="scrap-car-removal-brampton.php">Scrap Car Removal Brampton</a></li>
                        <li><a href="scrap-car-removal-Etobicoke.php">Scrap Car Removal Etobicoke</a></li>
                        <li><a href="scrap-car-removal-Mississauga.php">Scrap Car Removal Mississauga</a></li>
                    </ul>
                </li>
                <li><a href="blog.php">Blogs</a></li>
                <li><a href="index.php#work">About Us</a></li>
                <li><a href="index.php#work">Why Chose us</a></li>
            </ul>
        </div>
    </div>
</nav>