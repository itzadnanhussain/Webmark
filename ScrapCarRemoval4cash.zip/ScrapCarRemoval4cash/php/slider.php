
    <div id="slider">
        <div class="tp-banner-vertical">
            <ul>
                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="img/bg2.jpeg" data-saveperformance="off" data-title="Slide"> <img src="img/bg2.jpg" alt="Cash for Scrap Car Removal Brampton" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                    <div class="tp-caption lfb ltt tp-resizeme" data-x="right" data-hoffset="0" data-y="bottom" data-voffset="20" data-speed="1400" data-start="3000" data-easing="Power4.easeOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="500" data-endeasing="Power4.easeIn"><img src="img/cash.png" class="main_img_cash" alt="Cash for Scrap Car image"> </div>
                    <div class="tp-caption vertical-title lfb ltt tp-resizeme" data-x="left" data-hoffset="0" data-y="center" data-voffset="-70" data-speed="800" data-start="800" data-easing="Power4.easeOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="500" data-endeasing="Power4.easeIn"> Have Used Vehicle? </div>
                    <div class="tp-caption vertical-caption lfb ltt tp-resizeme" data-x="left" data-hoffset="90" data-y="center" data-voffset="25" data-speed="800" data-start="2000" data-easing="Power4.easeOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="500" data-endeasing="Power4.easeIn">Get Cash for it ... </div>
                    <div class="tp-caption rev-buttons lfb ltt tp-resizeme" data-x="left" data-hoffset="150" data-y="center" data-voffset="115" data-speed="2000" data-start="4000" data-easing="Power4.easeOut" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.1" data-endspeed="500" data-endeasing="Power4.easeIn"><a href="#Quote" class="main_btn">Get Free Quote Now</a></div>
                </li>
            </ul>
        </div>
    </div>