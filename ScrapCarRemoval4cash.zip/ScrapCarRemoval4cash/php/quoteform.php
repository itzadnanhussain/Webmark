    <a id="Quote"></a>
    <div class="intro-text-1">
        <div class="container">
            <div class="row parent_center">
                <div class="col-sm-4">
                    <br />
                    <br />
                    <br />
                    <br />
                    <form class="main_num_form" method="post" action="php/count.php">
                        <p>Click <i class="fa-phone"></i> to place call</p><a class="main_num num" href="tel:6479736574"><i class="fa-phone"></i></a><label class="main_num">647-973-6574</label>
                    </form>
                    <br>
                    <br>
                    <br>
                    <div class="fb-like" data-href="https://web.facebook.com/ScrapCars4Cash/" data-layout="standard" data-action="like" data-size="small" data-width="120" data-show-faces="true" data-share="true"></div>
                    <br>
                </div>
                <div class="col-sm-2">
                    <br>
                    <br>
                    <p>OR</p>
                    <br>
                </div>
                <div class="col-sm-6">
                    <br />
                    <form name="contactform" method="post" action="php/sendmail.php" id="messageform">
                        <div class="form-group col-sm-12">
                            <input type="text" name="name" class="form-control" placeholder="Enter Your Name.." required> </div>
                        <div class="form-group col-sm-12">
                            <input type="email" name="email" class="form-control" placeholder="Enter Your Email.." required> </div>
                        <div class="form-group col-sm-12">
                            <input type="number" name="phone" class="form-control" placeholder="Enter Your Phone Number.." required> </div>
                        <div class="form-group col-sm-12">
                            <input type="Address" name="Address" class="form-control" placeholder="Enter Vehicle's Pickup Address" required> </div>
                        <div class="form-group col-sm-12">
                            <textarea class="form-control" name="message" rows="5" placeholder="Enter Vehicle information " required></textarea>
                        </div>
                        <div class="form-group parent_center">
                            <input type="submit" class="submit_btn" value="Send Message"> </div>
                        <label id="message"></label>
                    </form>
                </div>
                <div class="col-sm-12">
                    <br>
                    <p>We offer free towing for scrap car removal, vans, SUVs, buses, trucks, trailers. Sell used car or any vehicle from Brampton, Mississauga and all surrounding areas by paying top dollar cash for cars from 100$ to 9000$</p>
                </div>
            </div>
        </div>
    </div>