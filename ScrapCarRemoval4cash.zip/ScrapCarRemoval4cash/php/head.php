
    <link rel="shortcut icon" type="image/png" href="img/towtruck.png" />
    <link rel="publisher" href="https://plus.google.com/u/0/b/113678476842834041103/">
    <meta name="keywords" content="Scrap Car Removal Brampton,scrap yard Brampton, junkyard Brampton, Top Dollar Cash for scrap cars Brampton,Auto Recycling, Car Disposal,Car Recycling, wrecked cars,Ontario Junk yard,Cash for cars,Scrapyards,Junk Car Removal, Automobile wreckers, Automobile wrecking, auto repair, Automobile recyclers,Automobile recycling, tow away scrap car,scrap car towing,car scrap metal, junk car towing, car wrecking,auto wrecking">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0">
    <meta property="og:title" content="Cash for Scrap Car Removal Brampton" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://i.imgur.com/hi6rRLp.jpg" />
    <meta property="og:description" content="Scrap car removal Brampton offers free towing of scrap cars, vans, SUVs, buses, trucks, trailers or any kind of unwanted vehicle from Brampton, Mississauga, Etobicoke, Oakville, Milton, Toronto & all surrounding areas by paying top dollar Cash from 100$ to 9000$- Call or submit request online." />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:alt" content="Scrap Car Removal Brampton & Junk Car Yard" />
    <link href="https://fonts.googleapis.com/css?family=Oswald|Roboto+Slab" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Chela+One" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <?php include('load_css.php')?>
        <script type="application/ld+json">{"@context": "http://schema.org", "@type": "AutomotiveBusiness", "name": "Scrap Car Removal 4 Cash", "address":{"@type": "PostalAddress", "streetAddress": "60 Grovewood Dr", "addressLocality": "Brampton", "addressRegion": "ON", "postalCode": "L7a2k1"}, "image": "https://i.imgur.com/hi6rRLp.jpg", "email": "abubkr.akram@gmail.com", "telePhone": "647-973-6574", "url": "http://scrapcars4cash.com/", "paymentAccepted": [ "cash"], "openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 07:00-23:00", "geo":{"@type": "GeoCoordinates", "latitude": "43.684241", "longitude": "-79.816484"}, "priceRange":"$$$$"}</script>
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-103575656-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', 'UA-103575656-1');
        </script>