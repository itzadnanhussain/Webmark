<style>
			<?php 
				/*custom css*/
				include 'css/style.css';
				/*Revolution slider css*/
				include 'css/settings.css';
				/*Bootstrap*/
				include 'css/bootstrap.min.css';
				/*Revolution slider css*/
				include 'css/rev-style.css';
				/*sweet alerts*/
				include 'css/sweetalert.css';
				/*blogs css*/
				include 'css/blog.css';
                /*blogs css*/
				include 'css/post.css';
				/*font css*/
				include 'css/font.css';
				//blog css
				include 'css/custom.css';

			?> 
		</style>