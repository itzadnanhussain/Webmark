	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
			<?php 
				/*custom css*/
				include 'css/style.css';
				include 'css/custom.css';
 				/*sweet alerts*/
				include 'css/sweetalert.css';
			?> 
			
</style>
 