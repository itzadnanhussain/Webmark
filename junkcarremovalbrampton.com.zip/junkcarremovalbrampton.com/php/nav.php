<div>
    <a class="call_link_main format" href="tel:647-484-6997"><i class="icon-phone">647-484-6997</i></a>
    <br/>
    <br/>
    <a class="call_link_main format" href="scrap-car-removal-brampton.php"><i class="icon-envelope"></i> Get Quote Now!!</a>
</div>