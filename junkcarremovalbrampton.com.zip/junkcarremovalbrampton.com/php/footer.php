 <footer>
    <div class="container parent_center">
        <p>17 Knightsbridge Rd, Brampton, ON</p>
        <p><a href="tel:647-484-6997">647-484-6997</a></p>
        <p><a href="https://www.google.com/maps?cid=11891264022704550690&_ga=2.35674656.1893001385.1512044318-703207711.1503368085"><strong>Google Map</strong> </a></p>
        <p><a href="https://facebook.com/pg/Junk-Car-Removal-Brampton-140997039869437/" rel="nofollow"><strong>Facebook Page</strong></a></p>
        <p><a href="blog_list.php"><strong>Our Blogs</strong></a></p>
        <p><a href="index.php"><strong>Scrap car removal Brampton</strong></a></p>
        <iframe width="100%" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d184531.95744418897!2d-79.89962748665775!3d43.724848461431264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b15eaa5d05abf%3A0x352d31667cc38677!2sBrampton%2C+ON%2C+Canada!5e0!3m2!1sen!2s!4v1510399049567" allowfullscreen></iframe>
    </div>
</footer>