<script>
	<?php 
		include 'js/jquery.min.js';
		/*custom slider*/
		include 'js/sweetalert.min.js';
		/*brampton scrap car removal js*/
		include 'js/custom.js';
	?> 
</script>