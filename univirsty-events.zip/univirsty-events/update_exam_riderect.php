<? ob_start();?>
<?php
session_start();
error_reporting(0);
include'php/connection.php';
 $id=$_SESSION['id'];
if(isset($_GET['update']))
    {   
    $exam=$_GET['exam']; 
    $department=$_GET['department']; 
    $class=$_GET['class'];
    $subject=$_GET['subject'];
    $date=$_GET['date'];
    $time=$_GET['time'];
    $location=$_GET['location']; 
     $query="UPDATE `examevents` SET `exam`='$exam',`department`='$department',`class`='$class',`subject`= '$subject',`time`='$time',`date`='$date',`location`='$location' WHERE id='$id'";
      $result=mysqli_query($conn,$query);
      if($result)
        {
           header("Location:update_exam.php?update=success");
        }
        else
        {
              
            header("Location:update_exam.php?update=error");
        }
    } 

?>
<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 
?>
<? ob_flush(); ?>