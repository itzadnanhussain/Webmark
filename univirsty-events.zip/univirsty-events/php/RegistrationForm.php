<div class="row form_header ">
    <div class="col-md-12 btn-primary ">
        <h4 class="text-center"><p class="heading">Make Your Registraiont Here</p></h4>
    </div>
    
    
    <!--Registration form--->
    <div class="col-md-6">
        <?php include'php/singn_up.php'?>
    </div>
    
    
    <div class="col-md-2"></div>
    <!---LOgin Form--->
    <div class="col-md-4">
        <div class="form user_login">
            <form action="std_redirect.php" method="post">
                <!--email-->
                <input type="text" required="required" placeholder="Please input your Email" value="" name="email" class="txt">
                <!--password-->
                <input type="password" required="required" placeholder="Please input your password" value="" name="password" class="txt">
                <!--submit-->
                <input type="submit" onclick="submitForm()" value="Login" name="login" class="txt2">
            </form>
            <!---Error handling--->
           <?php
            $fullUrl="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(strpos($fullUrl,"signin=error")==true)
            {
                echo"<p class='red'>pleas Enter valid input</p>";
            } 
          ?>
        </div>
    </div>
</div>  
        
        
 