<?php
include'connection.php';
error_reporting(0);
$querry="select * from examEvents";
$data=mysqli_query($conn,$querry);
$total=mysqli_num_rows($data);


if($total !=0)
 {
    ?>
<table class="table table-bordered table-responsive table-margin">
    <thead class="bg-primary">
        <tr>
             
            <th scope="col">S.NO</th>
            <th scope="col">DEPATMENT</th>
            <th scope="col">EXAM</th>
            <th scope="col">CLASS</th>
            <th scope="col">SUBJECT</th>
            <th scope="col">TIME</th>
            <th scope="col">DATE</th>
            <th scope="col">LOCATION</th> 
        </tr>
    </thead>
    <tbody class="text-center">

    <?php
    while($result=mysqli_fetch_assoc($data))
    {
        echo"<tr>
                <td>".$result['id']."</td>
                <td>".$result['department']."</td>
                <td>".$result['exam']."</td>
                 <td>".$result['class']."</td>
                <td>".$result['subject']."</td>
                <td>".$result['time']."</td>
                <td>".$result['date']."</td>
                <td>".$result['location']."</td>
            </tr>";
 
    }
    
 }
else
{
    
}

?>
</tbody>
</table>