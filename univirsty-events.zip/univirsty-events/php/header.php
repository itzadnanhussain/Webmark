<header>

    <div class="row btn-primary header">
        <div class="col-sm-12 col-md-6 col-xs-12 logo">
            <a href="index.php" title="GO TO HOME">COMSATS EVENTS MANAGEMENT SYSTEM</a>
        </div>
        <div class="col-xs-12 col-md-6 col-sm-12 admin text-right">
            <a href="admin_login.php" title="Go To Admin Login">Admin Login Here</a>
        </div> 
         
    </div>
    

</header>