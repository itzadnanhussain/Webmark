<style>
    <?php
    /*Font awsome css*/
    include 'css/fonts/css/font-awesome.css';
    /*header css*/
    /*custom css*/
    include 'css/custom.css';
    include 'css/header.css';
    include'css/slider.css';
    include'css/navigation.css';
    include'css/Events.css';
    include'css/admin_Side.css';
    include'css/table.css';



    /*Registration Form css*/
    include'css/RegistraionForm.css';
    /*footer css*/
    include 'css/footer.css';


    /*Admin_Form css*/
    include 'css/admin_Form.css';
    /*sweat alert css*/
    include 'css/sweetalert.css';



    ?>
</style>