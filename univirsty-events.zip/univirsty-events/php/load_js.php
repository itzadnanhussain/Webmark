<script>
    <?php  
		/************J-Query Plugins**********************************/
		        
        /************Js Plugins**********************************/
		        
		       include 'js/custom.js';
    
        /************sweetalert js**********************************/
		      include'js/sweetalert.js';
        /************Particle Plugins**********************************/
                
               
        /************SweetAlert Plugins**********************************/ 
	?>
</script>