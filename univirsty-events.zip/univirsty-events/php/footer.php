 <div class="row">
     <div class="col-md-12">
         <footer class="footer btn-primary"> 
            <p class="text-center"><img class="img-responsive" src="img/footer.png">Copyright © 2019, All Rights Reserved</p>
             
         </footer>
     </div>
 </div>
 
 