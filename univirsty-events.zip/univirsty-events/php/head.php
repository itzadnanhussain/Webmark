<!-------------------Title of page---------------->
<title>University Event Managment System</title>

<!---------------------------favicon--------------------------->
<link rel="shortcut icon" href="img/favicon.png">



<!---------------------meta tags----------------------------->
<meta charset="UTF-8">
<meta name="description" content="our universty event management system boots your skills">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!----------------------- Css jquery and js Plugins-------------------------->
<link rel="stylesheet" href="css/bootstrap.min.css">
<?php include('php/load_css.php')?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<?php include('php/load_js.php')?> 
<!----------------------- google font Plugins-------------------------->
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">