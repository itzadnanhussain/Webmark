<div>
  <ul class="btn-primary nav">
    <li><a href="">Home</a></li>
    <li><a href="">Logout</a></li> 
  </ul>
</div>