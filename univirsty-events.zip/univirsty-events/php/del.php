<?php
include'connection.php';
$id=$_GET['id'];
$query="DELETE FROM `examevents` WHERE id='$id'";
$data=mysqli_query($conn,$query);
if($data)
{
    header("Location:../admin_Exam_update_Events.php");
}
else
{
    echo"error";
}

?>