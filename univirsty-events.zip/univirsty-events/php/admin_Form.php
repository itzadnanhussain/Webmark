  
        
 <?php
session_start();
include'connection.php';
$n=$_POST['name'];
$pass=$_POST['password'];
if(isset($_POST['submit']))
{
    if($n=="admin")
    {
        if($pass="admin123")
        {
            header('location:admin_panel.php');
        }
        else
        {
            echo"invalid inputs";
                header('location:admin_login.php');
        }
    }
    else
    {
         echo"invalid inputs";
                header('location:admin_login.php');
    }
}

?>
        
        





 