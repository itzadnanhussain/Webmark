<?php
include'connection.php';
error_reporting(0);
$querry="select * from examEvents";
$data=mysqli_query($conn,$querry);
$total=mysqli_num_rows($data);


if($total !=0)
 {
    ?>
<table class="table table-bordered table-responsive table-margin">
    <thead class="bg-primary">
        <tr>
             
            <th scope="col">S.NO</th>
            <th scope="col">EXAM</th>
            <th scope="col">DEPARTMENT</th>
            <th scope="col">CLASS</th>
            <th scope="col">SUBJECT</th>
            <th scope="col">TIME</th>
            <th scope="col">DATE</th>
            <th scope="col">LOCATION</th> 
            <th scope="col" class="bg-green">Edit</th>
            <th scope="col" class="bg-red">Delete</th>
             
        </tr>
    </thead>
    <tbody class="text-center">

    <?php
    while($result=mysqli_fetch_assoc($data))
    {
        ?>
          <tr> 
                <td><?php echo $result['id']; ?></td>
                <td><?php echo $result['exam']; ?></td>
                <td><?php echo $result['department']; ?></td>
                 <td><?php echo $result['class']; ?></td> 
                 <td><?php echo $result['subject']; ?></td>
                <td><?php echo $result['time']; ?></td>
                <td><?php echo $result['date']; ?></td>
                 <td><?php echo $result['location']; ?></td> 
                 <td><a href="update_exam.php?id=<?php echo $result['id']; ?>">Edit</a></td>
                 <td><a href="php/del.php?id=<?php echo $result['id']; ?>">Delet</a></td>
                  
            </tr>  
            <?php
 
    }
    
 }
else
{
    
}

?>
</tbody>
</table>