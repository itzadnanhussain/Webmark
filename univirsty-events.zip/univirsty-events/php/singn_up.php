<div class="form">
    <form name="contactform" method="post" action="register.php" id="messageform">
        <!--first name-->
        <input type="text" required="required" placeholder=" First Name" value="" name="first_name" class="txt">
        <!--last name--> 
        <input type="text" required="required" placeholder=" Last Name" value="" name="last_name" class="txt">
        <!--address-->
        <input type="text" required="required" placeholder=" Address" value="" name="address" class="txt"> 
        <!--email-->
        <input type="text" required="required" placeholder=" Email" value="" name="email" class="txt">
        <!--password-->
        <input type="password" required="required" placeholder=" password" value="" name="password" class="txt">
        <!-- confirm password-->
        <input type="password" required="required" placeholder="confirm password" value="" name="c_password" class="txt">
        <!--submit-->
        <input type="submit" onclick="submitForm()" value="Signup" name="signup" class="txt2">
        <!---Error handling--->
        <?php
            $fullUrl="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(strpos($fullUrl,"signup=invalid_firstname")==true)
            {
                echo"<p class='red'>Your First Name Is Invalid</p>";
            }
            if(strpos($fullUrl,"signup=invalid_lastname")==true)
            {
                echo"<p class='red'>Your First Name Is Invalid</p>";
            }
            if(strpos($fullUrl,"signup=invalid_email")==true)
            {
                echo"<p class='red'>Your Email Is Invalid</p>";
            }
            if(strpos($fullUrl,"signup=already_email")==true)
            {
                echo"<p class='red'>Your Email Is Alread Exist</p>";
            }
            if(strpos($fullUrl,"signup=password_not_match")==true)
            {
                echo"<p class='red'>Your Password is not match</p>";
            }
            if(strpos($fullUrl,"signup=success")==true)
            {
                echo"<p class='success'>Your are Successfuly Register</p>";
            }
        ?>
    </form>

</div>