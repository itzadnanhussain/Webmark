<html lang="en">

<head>
    <!--HEAD TAGS--->
    <?php include"php/head.php"?> 
</head>

<body>
    <div class="container-fluid header_bg">
        <div class="container">
            <!--   HEADER OF THE SITE--->
            <?php include"php/header.php"?>
            <!--   HEADER OF THE SITE--->
            <?php include"php/slider.php"?> 
            <!--   Events Link Buttons--->
            <div class="row form_header">
                <!--row----->
                <div class="col-md-12 btn-primary ">
                   <!--   Navigation OF THE SITE--->
                    <div>
                        <ul class="btn-primary nav">
                            <li><a href="admin_panel.php">Home</a></li>
                            <li><a href="admin_login.php">Logout</a></li>
                            <li><a href="add_sport_events.php">Add</a></li>
                            <li><a href="admin_sport_update_Events.php">Update</a></li>
                            <li><a href="admin_sport_view_Events.php" title="Go View Page">View</a></li>
                        </ul>
                    </div>  
                </div>
            </div>
                <!--- banner---->
                <div class="row text-center admin-button form_header sports">
                    <div class="col-md-12 heading">
                        <h3>WellCome to Sports Events</h3>
                    </div> 
                </div> 
            <!--FOOTER OF THE SITE--->
            <?php include"php/footer.php"?>
        </div> 
    </div>
</body>

</html>