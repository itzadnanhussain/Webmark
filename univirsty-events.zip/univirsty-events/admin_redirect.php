<? ob_start();?>
<?php
session_start();
    include'php/connection.php';
    if(isset($_POST['login']))
{
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $query="select * from login where  password='$pass'&& email='$email' ";
    $data=mysqli_query($conn,$query);
    $total=mysqli_num_rows($data);
     if($total==1)
     {  
          header("Location:admin_panel.php ");
         exit();
     }
    else
    {  
          header("Location:admin_login.php?signin=error");
        
    }
}?>
<? ob_flush(); ?>