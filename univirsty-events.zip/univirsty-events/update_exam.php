<? ob_start();?>
<?php 
    session_start();
    error_reporting(0);
    include"php/connection.php"; 
    $id=$_GET['id'];
    $_SESSION['id'] = $id;
    $query="SELECT * FROM examEvents WHERE id='$id'";
    $data=mysqli_query($conn,$query);
    $result=mysqli_fetch_array($data); 
?>  
<html lang="en">

<head>
    <!--HEAD TAGS--->
    <?php include"php/head.php"?>

</head>

<body>
    <div class="container-fluid header_bg">
        <div class="container">
            <!--   HEADER OF THE SITE--->
            <?php include"php/header.php"?>
            <!--   HEADER OF THE SITE--->
            <?php include"php/slider.php"?>

            <!--   Events Link Buttons--->
            <div class="row form_header">
                <!--row----->
                <div class="col-md-12 btn-primary ">
                    <h4 class=""><a class="back" href="admin_Exam_update_Events.php" title="Go to Home">back</a>
                        <p class="text">Update Here</p><a class="logout" href="logout.php" title="logout">logout</a>
                    </h4>
                </div>
            </div>
            <!--- Button ---->
            <div class="row text-center admin-button form_header">
                <div class="form">
                    <form name="contactform" method="Get" action="update_exam_riderect.php"> 
                         <!--id-->
                         
                         <!--exam-->
                        <input type="text" required="required" value="<?php echo  $result['exam']; ?>" name="exam" class="txt">
                        <!--Department-->
                        <input type="text" required="required" value="<?php echo  $result['department']; ?>" name="department" class="txt"> 
                        <!--class-->
                        <input type="text" required="required" value="<?php echo  $result['class']; ?>" name="class" class="txt">
                        <!--subject-->
                        <input type="text" required="required" value="<?php echo  $result['subject']; ?>" name="subject" class="txt">
                         <!--time-->
                        <input type="text" required="required" value="<?php echo  $result['time']; ?>" name="time" class="txt">
                        <!--date-->
                        <input type="text" required="required" value="<?php echo  $result['date']; ?>" name="date" class="txt">
                       
                        <!--location-->
                        <input type="text" required="required" value="<?php echo  $result['location']; ?>" name="location" class="txt">

                        <!--submit-->
                        <input type="submit" onclick="submitForm()" value="update" name="update" class="txt2">
                        <!---Error handling--->
                        <?php
            $fullUrl="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(strpos($fullUrl,"update=empty")==true)
            {
                echo"<p class='red'>All Fields are Required:</p>";
            }
             
            if(strpos($fullUrl,"update=success")==true)
            {
                echo"<p class='success'>Your are Successfuly updated Records</p>";
            }
            if(strpos($fullUrl,"update=error")==true)
            {
                echo"<p class='red'>Your are not Successfuly updated Records</p>";
            }
        ?>
                    </form> 
                </div>
            </div> 
            <!--FOOTER OF THE SITE--->
            <?php include"php/footer.php"?>
        </div>
    </div>
</body> 
</html> 
<? ob_flush(); ?>


