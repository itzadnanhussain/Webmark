 //slider js

 $('.carousel').carousel({
     interval: 5000
 })