<!--------------Conection File--------------->
<?php 
$server="localhost";
$user="root";
$password="";
$database="test";
$conn=mysqli_connect($server,$user,$password,$database);
if($conn)
{
    echo'your connection is successful';
}
else
{
    die("connection failed due to".mysqli_connect_error());
}


<!--------------Add Data File--------------->
if(isset($_POST['submit']))
{
    
}
