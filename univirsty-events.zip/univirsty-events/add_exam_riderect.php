<? ob_start();?>
<?php 
include'php/connection.php';
if(isset($_POST['add']))
{
            
    
    $exam=$_POST['exam'];
    $department=$_POST['department'];
    $class=$_POST['class'];
    $subject=$_POST['subject'];
    $date=$_POST['date'];
    $time=$_POST['time'];
    $location=$_POST['location'];
    
            if($exam=="" || $department==""|| $class==""|| $subject==""|| $date=="" || $time==""|| $location=="" )
            {
                
                header("Location:add_exam_events.php?add=empty");
            }
            else  
            {    $querry="INSERT INTO `examevents`(`exam`, `department`, `class`, `subject`, `time`, `date`, `location`) VALUES ('$exam','$department','$class',' $subject','$time','$date','$location')"; 
                    $data=mysqli_query($conn,$querry);
                    if($data)
                     {
                          header("Location:add_exam_events.php?add=success");
                     }else
                    {
                        echo"error".mysqli_error();
                    }
             
            } 
            } 
         else
{
    header("Location:add_exam_events.php?add=error");
}?>
<? ob_flush(); ?>