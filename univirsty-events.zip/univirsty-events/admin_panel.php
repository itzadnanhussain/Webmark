<html lang="en">

<head>
    <!--HEAD TAGS--->
    <?php include"php/head.php"?>

</head>

<body>
    <div class="container-fluid header_bg">
        <div class="container">
            <!--   HEADER OF THE SITE--->
            <?php include"php/header.php"?>
            <!--   HEADER OF THE SITE--->
            <?php include"php/slider.php"?> 
            <!--   Events Link Buttons-->
            <div class="row form_header">
                <!--row-->
                <div class="col-md-12 btn-primary ">
                    <!--   Navigation OF THE SITE--->
                    <div>
                        <ul class="btn-primary nav">
                            <li><a href="admin_panel.php">Home</a></li>
                           <li><a href="admin_login.php">Logout</a></li>
                        </ul>
                    </div> 
                </div>
            </div>
            <!----Row Section complete 1---->
            <div class="row portfolio-column-4-area form_header">
                <!--column 1-->
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="single-portfolio-column">
                        <div class="portfolio-column-img">
                            <a href="Admin_Exams_Events.php">
                                <div class="portfolio-column-photo ">
                                    <img src="img/exam.jpg" class="img-responsive">
                                </div>
                                <div class="portfolio-column-view">
                                    <div class="portfolio-column-text">
                                        <h3>Examps Events</h3>
                                        <p></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!--column 2-->
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="single-portfolio-column">
                        <div class="portfolio-column-img">
                            <a href="Admin_Convocation_Events.php">
                                <div class="portfolio-column-photo ">
                                    <img src="img/convocation.jpg" class="img-responsive">
                                </div>
                                <div class="portfolio-column-view">
                                    <div class="portfolio-column-text"> 
                                        <h3>Covocation Events</h3>
                                        <p></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!----Row Section complete 1---->
                <!--column 1-->
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="single-portfolio-column">
                        <div class="portfolio-column-img">
                            <a href="Admin_Sports_Events.php">
                                <div class="portfolio-column-photo ">
                                    <img src="img/sport.jpg" class="img-responsive">
                                </div>
                                <div class="portfolio-column-view">
                                    <div class="portfolio-column-text">
                                        <h3> Sports Events</h3>
                                        <p></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!--column 2-->
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <div class="single-portfolio-column">
                        <div class="portfolio-column-img">
                            <a href="Admin_siminar_Events.php">
                                <div class="portfolio-column-photo ">
                                    <img src="img/sminar.jpg" class="img-responsive">
                                </div>
                                <div class="portfolio-column-view">
                                    <div class="portfolio-column-text"> 
                                        <h3>Simenar</h3>
                                        <p></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!--FOOTER OF THE SITE--->
            <?php include"php/footer.php"?>
        </div>
    </div>
</body>

</html>