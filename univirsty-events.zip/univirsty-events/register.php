<? ob_start();?>
<?php 
include'php/connection.php';
if(isset($_POST['signup']))
{
            
    $fname=$_POST['first_name'];
    $lname=$_POST['last_name'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $c_password=$_POST['c_password'];
    
            if($fname=="" || $lname=="" || $address==""|| $email==""|| $password=="" || $c_password=="" )
            {
                
                header("Location:index.php?signup=empty");
            }
            else if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",$email))
		    {
			     header("Location:index.php?signup=invalid_email");
		    } 
            else
            {
                $query="select * from register where  email='$email'";
                $data=mysqli_query($conn,$query);
                $total=mysqli_num_rows($data);
                if($total==0)
                {
                    $querry="insert into registration values('$email','$fname','$lname','$address', '$password')"; 
                    $data=mysqli_query($conn,$querry);
                    if($data)
                     {
                          header("Location:index.php?signup=success");
                      }
                }
                else
                {
                    header("Location:index.php?signup=already_email");
                } 
            } 
        } else
{
    header("Location:index.php?signup=error");
}?>
<? ob_flush(); ?>