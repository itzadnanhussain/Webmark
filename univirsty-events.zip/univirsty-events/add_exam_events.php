<html lang="en"> 
<head>
    <!--HEAD TAGS--->
    <?php include"php/head.php"?>

</head>

<body>
    <div class="container-fluid header_bg">
        <div class="container">
            <!--   HEADER OF THE SITE--->
            <?php include"php/header.php"?>
            <!--   HEADER OF THE SITE--->
            <?php include"php/slider.php"?>
            <!--Form Section Of THE SITE--->
            <div class="row form_header ">
                <div class="col-md-12 btn-primary ">
                    <!--   Navigation OF THE SITE--->
                    <div>
                        <ul class="btn-primary nav">
                            <li><a href="admin_panel.php">Home</a></li>
                            <li><a href="admin_login.php">Logout</a></li>
                            <li><a href="add_exam_events.php">Add</a></li>
                            <li><a href="admin_Exam_update_Events.php">Update</a></li>
                            <li><a href="admin_Exam_view_Events.php" title="Go View Page">View</a></li>
                        </ul>
                    </div>  
                </div>
                <!---LOgin Form--->
                <div class="col-md-3"></div>
                <div class="col-md-6">
                   
                    <div class="form admin_login">
                        <form name="contactform" method="post" action="add_exam_riderect.php" id="messageform"> 
                             <!---Error handling--->
                            <?php
            $fullUrl="http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if(strpos($fullUrl,"add=empty")==true)
            {
                echo"<p class='red'>All Feilds are required</p>";
            }
            if(strpos($fullUrl,"signup=invalid_lastname")==true)
            {
                echo"<p class='red'>Your First Name Is Invalid</p>";
            }
            if(strpos($fullUrl,"signup=invalid_email")==true)
            {
                echo"<p class='red'>Your Email Is Invalid</p>";
            }
            if(strpos($fullUrl,"add=already_sn")==true)
            {
                echo"<p class='red'>Serial No already exist</p>";
            }
            if(strpos($fullUrl,"add=success")==true)
            {
                echo"<p class='success'>Event Successfuly added</p>";
            }
        ?>
                            <!--Exam--> 
                            <input type="text" required="required" placeholder="Add Exam Type" value="" name="exam" class="txt">
                            <!--department-->
                            <input type="text" required="required" placeholder=" Add Department" value="" name="department" class="txt">
                            <!--class-->
                            <input type="text" required="required" placeholder="Add Class" value="" name="class" class="txt">
                            <!--subject-->
                            <input type="text" required="required" placeholder="Add Subject" value="" name="subject" class="txt">
                            <!--time-->
                            <input type="time" required="required" placeholder="Add Time" value="" name="time" class="txt">
                            <!--date-->
                            <input type="date" required="required" placeholder="Add Date" value="" name="date" class="txt">
                           
                            <!--location-->
                            <input type="text" required="required" placeholder="Add location" value="" name="location" class="txt">
                            <!--submit-->
                            <input type="submit" onclick="submitForm()" value="Add" name="add" class="txt2">
                          
                        </form>
                        
                    </div>
                </div>
                <div class="col-md-3"></div>
            </div>
            <!--FOOTER OF THE SITE--->
            <?php include"php/footer.php"?>
        </div>
    </div>
</body>

</html>