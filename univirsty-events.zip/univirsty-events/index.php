<html lang="en"> 
<head>
    <!--HEAD TAGS--->
    <?php include"php/head.php"?>

</head> 
<body>
    <div class="container-fluid header_bg">
        <div class="container">
            <!--   HEADER OF THE SITE--->
            <?php include"php/header.php"?> 
            <!--   HEADER OF THE SITE--->
            <?php include"php/slider.php"?> 
            <!--Form Section Of THE SITE--->
            <?php include"php/RegistrationForm.php"?> 
            <!--FOOTER OF THE SITE--->
            <?php include"php/footer.php"?>
        </div>
    </div> 
</body> 
</html>