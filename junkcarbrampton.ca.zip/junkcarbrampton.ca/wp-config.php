<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'JunkCarRemovalBrampton' );

/** MySQL database username */
define( 'DB_USER', 'adnanhussain' );

/** MySQL database password */
define( 'DB_PASSWORD', 'ItzAyan@123' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[;kPA;*iRkz?;&~bL_yRgyQSsUshuo1WyL0Dacf0ue$&`38)gUH!ial$W+n/-tWB' );
define( 'SECURE_AUTH_KEY',  '&XbHGxE<N>} k=j|ZYLY3nM+<N@!HUc@b<-*UenQM_Ec!&t}{nhK5e]upgAmmvy8' );
define( 'LOGGED_IN_KEY',    'p[[6JS?8=a}6=V?*0&h9++;wCF:7b-K6.gi,864Rt>+|__{2n+fn,p52s.&grjx%' );
define( 'NONCE_KEY',        '66IDv@XWe#/pA+IPCW.Yi18X{mb}1,^QId*6T<2n>OD aW8$d0ZGihDeEvmNFm+s' );
define( 'AUTH_SALT',        'yB{eXsA`ozihXk6W*ljQJ|c cY5-!b9s]^L`QkI)mf{m;E$=1JHhrX|uqwnk~eFk' );
define( 'SECURE_AUTH_SALT', '#aqdGKJ|8u$soSuI<P[Q;ne,tMSNF7-8@>Im$k><V,:8GM3q~gFIlK9@M`H^5e%<' );
define( 'LOGGED_IN_SALT',   ']A*I,klIQ#D2`sIE<g4Kuv9p1r|Tt&yCO{`P^%dC7Bk#:IKpfl3~@y$jCGj#us.r' );
define( 'NONCE_SALT',       'HttP}<<Vt|o,Y0wOG;|tE5NGA6AmFD,+nn5%p6ly# q.00EhFGh=K`1k[B&aHuaG' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
