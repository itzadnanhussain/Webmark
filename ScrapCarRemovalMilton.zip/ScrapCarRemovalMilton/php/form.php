<form method="post" action="php/email.php" id="messageform">
    <ul>
        <li>
            <label class="title">Name:</label>
            <input type="text" name="name" value="Type Your Name" onblur="if(this.value == '') { this.value ='Type Your Name'; }" onfocus="if(this.value =='Type Your Name') { this.value = ''; }">
            <i class="fa fa-user"></i>
        </li>
        <li>
            <label class="title">Email:</label>
            <input type="email" name="email" value="Type Your Email" onblur="if(this.value == '') { this.value ='Type Your Email'; }" onfocus="if(this.value =='Type Your Email') { this.value = ''; }">
            <i class="fa fa-envelope"></i>
        </li>
        <li>
            <label class="title">Number</label>
            <input type="text" name="phone" value="Type Your Number" onblur="if(this.value == '') { this.value ='Type Your Name'; }" onfocus="if(this.value =='Type Your Name') { this.value = ''; }">
            <i class="fa fa-phone"></i>
        </li>  
        <li>
            <label class="title">Address:</label>
            <input type="text" name="address" value="Type Your Website" onblur="if(this.value == '') { this.value ='Type Your Website'; }" onfocus="if(this.value =='Type Your Address') { this.value = ''; }">
            <i class="fa fa-home"></i>
        </li>
        <li class="full-width">
            <label class="title">Message:</label>
            <textarea name="message" placeholder="Type Your Message" rows="2"></textarea>
            <i class="fa fa-commenting"></i>
        </li>
        <li><label class="submit-btn"><input type="submit" value="Send Now"> <i class="automechanic-icon automechanic-arrows22"></i></label></li>
    </ul>
</form>