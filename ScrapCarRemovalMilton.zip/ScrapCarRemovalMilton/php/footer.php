<!--// Footer newslatter \\-->

<div class="scrapcar-footer-newslatter">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="scrapcar-newslatter-text">
                    <h2>Find a Location near you</h2>
                    <form>
                        <input type="text" value="Type your location" onblur="if(this.value == '') { this.value ='Type your location'; }" onfocus="if(this.value =='Type your location') { this.value = ''; }">
                        <label><i class="fa fa-search"></i><input type="submit" value="Find Us"></label>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--// Footer newslatter \\-->

<!--// Footer \\-->
<footer id="scrapcar-footer" class="scrapcar-footer-one">
    <!--// Footer Widget \\-->
    <div class="scrapcar-footer-widget">
        <div class="container">
            <div class="row">

                <!--// Widget widget_links \\-->
                <aside class="col-md-2 widget widget_links">
                    <h2 class="scrapcar-footer-title">quick Links</h2>
                    <ul>
                        <li><a href="about-us.php" title="Our Scrap Car Removal Company">Company<i class="automechanic-icon automechanic-arrow"></i></a></li>
                        <li><a href="contact-us.php" title="Get top offer">Instant Quote<i class="automechanic-icon automechanic-arrow"></i></a></li>
                        <li><a href="gallery.php" title="ScrapYard">Gallery<i class="automechanic-icon automechanic-arrow"></i></a></li>
                        <li><a href="services.php" title="Our Free Towing Services">Our Services<i class="automechanic-icon automechanic-arrow"></i></a></li>
                        <li><a href="Blog.php" title="Get Top Tips">Blogs<i class="automechanic-icon automechanic-arrow"></i></a></li>

                    </ul>
                </aside>
                <!--// Widget widget_links \\-->

                <!--// Widget widget_links \\-->
                <aside class="col-md-3 widget widget_links social-links">
                    <h2 class="scrapcar-footer-title">we’re social</h2>
                    <ul>
                        <li><a href="https://web.facebook.com/Scrap-Car-Removal-Milton-1008954615965309/" title="Scrap Car Removal Milton Facebook Page">Facebook<i class="fa fa-facebook-square"></i></a></li>
                        <li><a href="#" title="coming soon">Twitter<i class="fa fa-twitter-square"></i></a></li>
                        <li><a href="https://business.google.com/dashboard/l/17597997852382722984" title="Scrap Car Removal Milton Google My Business Page">Google Plus<i class="automechanic-icon automechanic-social-1"></i></a></li>
                        <li><a href="#" title="coming soon">Youtube<i class="automechanic-icon automechanic-play"></i></a></li>
                    </ul>
                </aside>
                <!--// Widget widget_links \\-->

                <!--// Widget widget_appointment \\-->
                <aside class="col-md-3 widget widget_appointment">
                    <h2 class="scrapcar-footer-title">Get An Instant Quote</h2>
                    <form>
                        <ul>
                            <li><input type="email" value="E-mail Address" onblur="if(this.value == '') { this.value ='E-mail Address'; }" onfocus="if(this.value =='E-mail Address') { this.value = ''; }"></li>
                            <li><input type="text" value="Phone Number" onblur="if(this.value == '') { this.value ='Phone Number'; }" onfocus="if(this.value =='Phone Number') { this.value = ''; }"></li>
                            <li><input type="text" value="Postcode" onblur="if(this.value == '') { this.value ='Postcode'; }" onfocus="if(this.value =='Postcode') { this.value = ''; }"></li>
                            <li><label><i class="fa fa-pencil-square-o"></i></label>
                                <input type="submit" value="make an appointment">
                            </li>
                        </ul>
                    </form>
                </aside>
                <!--// Widget widget_appointment \\-->

                <!--// Widget widget_gallery \\--->
                <aside class="col-md-4 widget widget_gallery">
                    <h2 class="scrapcar-footer-title">Contact Us:</h2>
                    <p class="scrapcar-footer-text">We can be reached at any time, so feel free to give us a call when you require immediate assistance. If you have a question, or you are simply looking for the best price possible, call us and we will make you a fair and honest offer. Our years of experience in this industry has led us to know a thing or two. We will direct you along the right path and make sure you are not being taken for a ride ( no pun intended).</p>
                    
                </aside>
                <!--// Widget widget_gallery \\-->

            </div>
        </div>
    </div>
    <!--// Footer Widget \\-->

    <!--// CopyRight \\-->
    <div class="scrapcar-copyright-wrap">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="scrapcar-copyright">
                        <div class="copyright-social-icon">
                            <ul>
                                <li class="facebook"><a href="https://web.facebook.com/Scrap-Car-Removal-Milton-1008954615965309/" title="Scrap Car Removal Milton Facebook Page"><i class="fa fa-facebook"></i></a></li>
                                <li class="twitter"><a href="#" title="coming soon"><i class="fa fa-twitter"></i></a></li>
                                <li class="linkedin"><a href="#" title="coming soon"><i class="fa fa-linkedin"></i></a></li>
                                <li class="plus"><a href="https://business.google.com/dashboard/l/17597997852382722984" title="Scrap Car Removal Milton Google My Business Page"><i class="fa fa-google-plus"></i></a></li>
                                <li class="firbox"><a href="#" title="coming soon"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                        <span>Copyright 2017. All Rights Reserved <i class="fa fa-heart"></i> by <a href="index.php" title="scrap car removal Milton">Scrap Car Removal Milton</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// CopyRight \\-->

</footer>
<!--// Footer \\-->
<?php include'php/load_js.php'?>