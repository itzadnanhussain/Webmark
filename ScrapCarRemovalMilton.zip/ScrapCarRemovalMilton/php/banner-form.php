<form method="post" action="php/email.php" id="messageform" class="scrapcar-quote-about-us">
    <ul>
        <li>
            <label> Name:*</label>
            <input type="text" name="name" value="Name" onblur="if(this.value == '') { this.value ='First Name'; }" onfocus="if(this.value =='First Name') { this.value = ''; }">
        </li>
        <li>
            <label>Email Address:*</label>
            <input type="email" name="email" value="Email Address" onblur="if(this.value == '') { this.value ='Email Address'; }" onfocus="if(this.value =='Email Address') { this.value = ''; }">
        </li>
        <li>
            <label>Phone Number:</label>
            <input type="text" name="phone" value="Phone Number" onblur="if(this.value == '') { this.value ='Phone Number'; }" onfocus="if(this.value =='Phone Number') { this.value = ''; }">
        </li>
        <li>
            <label>Address:*</label>
            <input type="text" name="address" value="Location" onblur="if(this.value == '') { this.value ='Zip Code'; }" onfocus="if(this.value =='Zip Code') { this.value = ''; }">
        </li>
        <li>
            <label>Message:</label>
            <textarea name="message" value="Message" rows="2" onblur="if(this.value == '') { this.value ='Message'; }" onfocus="if(this.value =='Message') { this.value = ''; }"></textarea>
        </li>
        <li class="submit">
            <label> <input type="submit" value="Send"></label>
        </li> 
    </ul> 

</form>