<header id="scrapcar-header" class="scrapcar-header-one">

    <div class="scrapcar-top-strip">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="scrapcar-top-strip-info">
                        <ul>
                            <li><a href="about-us.php" title="Why Choose Us">Why Choose Us?</a></li>
                            <li><a href="contact-us.php" title="Get Top cash for your Scrap Car">Get Top cash for your Scrap Car</a></li> 
                        </ul>
                    </div>
                    <div class="scrapcar-right-section">
                        <span><i class="icon icon-telephone2"></i>Call Us Free <small>(647) 691-2932</small></span>
                        <a href="contact-us.php" title="sell vehicle" class="scrapcar-simple-btn"><i class="automechanic-icon automechanic-people"></i>sell vehicle</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="scrapcar-main-header">
        <div class="container">
            <div class="row">
                <aside class="col-md-2"> <a href="index.php" title="scrap car removal Milton" class="logo"><img src="img/logo.png" alt=""></a> </aside>
                <aside class="col-md-10">
                    <div class="scrapcar-navigation">
                        <!--// Navigation \\-->
                        <a href="#menu" class="menu-link active"><span></span></a>
                        <nav id="menu" class="menu navbar navbar-default">
                            <ul class="level-1 navbar-nav">

                                <!----Home Manu------>
                                <li class="active"><a href="index.php" title="scrap car removal Milton">Home</a></li>
                                <!----Company Manu------>
                                <li class="active"><a href="about-us.php" title="our car removal company">Company</a></li>
                                <!----Service Manu------>
                                <li><a href="services.php" title="scrap car removal services">Services</a><span class="has-subnav"><i class="fa fa-angle-down"></i></span>
                                    <ul class="sub-menu level-2">
                                        <li><a href="sell-old-car.php" title="Sell My Old Car for top cash">Sell My Old Car<i class=" fa fa-angle-right"></i> </a></li>
                                        

                                    </ul>
                                </li>
                                <!----Gallery Manu------>
                                 <li class="active"><a href="gallery.php" title="Our ScrapYard">Gallery</a></li> 
                                
                                 
                                 
                                <!----Blogs Manu------>
                                <li><a href="Blog.php" title="Get Top Tips">Blogs</a><span class="has-subnav"><i class="fa fa-angle-down"></i></span>
                                    <ul class="sub-menu level-2">
                                        <li><a href="sell-car-quickly.php" title="Sell Scrap Car for top cash">Sell Car Quickly<i class=" fa fa-angle-right"></i> </a></li>
                                        
                                        <li><a href="Get-Free-Car-Removal.php" title="Scrap car removal Milton">Get Free Car Removal <i class=" fa fa-angle-right"></i> </a></li>
                                        
                                        <li><a href="Growth-of-junk-car.php" title="Junk Car Removal Milton">Growth Of Junk Car<i class=" fa fa-angle-right"></i> </a></li>

                                    </ul>
                                </li>
                                 <!----Contact Manu------>
                                 <li class="active"><a href="contact-us.php">Contact us</a></li> 

                                 
                            </ul>
                        </nav>
                        <!--// Navigation \\-->
                        <a href="contact-us.php" title="Get An Instant Offer" class="scrap-fancy-btn"><i class="fa fa-file-text-o"></i>Instant Quote</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</header>