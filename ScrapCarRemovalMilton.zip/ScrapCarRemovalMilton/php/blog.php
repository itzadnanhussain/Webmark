            <!--// Main Section \\-->
            <div class="scrapcar-main-section scrapcar-blog-classic-full">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="scrapcar-fancy-title">
                                <h2>Latest Blogs<small></small></h2> 
                            </div>
                            <div class="scrapcar-blog scrapcar-blog-classic">
                                <ul class="row"> 
                                  
                                   <!----Blogs--1---->
                                    <li class="col-md-4">
                                        <div class="scrapcar-blog-classic-text">
                                            <figure><a href="sell-car-quickly.php" title="How Yau Can sell Your scrap car Quickly"><img src="img/Blogs/How to Sell Your Scrap Car Quickly-banner.jpg" alt="How Yau Can sell Your scrap car Quickly"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                                            <div class="scrapcar-classic-figure-text">
                                                <small class="time-btn">October 7th, 2019</small>
                                                 <!--a href="404.html"><i class="automechanic-icon automechanic-interface-1"></i>12</a-->
                                                <h2><a href="sell-car-quickly.php" title="How Yau Can sell Your scrap car Quickly">How to Sell Your Scrap Car Quickly</a></h2>
                                                <p>Occasionally, the auto owners have their vehicle sold in one day, or many times...</p>
                                            </div>
                                            <a href="sell-car-quickly.php" class="scrapcar-readmore-btn" title="How Yau Can sell Your scrap car Quickly">Read More</a>
                                        </div>
                                    </li>
                                    
                                    
                                    
                                    
                                  <!----Blogs--2---->
                                    <li class="col-md-4">
                                        <div class="scrapcar-blog-classic-text">
                                            <figure><a href="Growth-of-junk-car.php" title="Growth of junk car removal Milton"><img src="img/Blogs/Growth of Junk Car Removals Milton-banner.jpg" alt="Growth of junk car removal Milton"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                                            <div class="scrapcar-classic-figure-text">
                                                <small class="time-btn">October 7th, 2019</small>
                                                 <!--a href="404.html"><i class="automechanic-icon automechanic-interface-1"></i>12</a-->
                                                <h2><a href="Growth-of-junk-car.php" title="Growth of junk car removal Milton">Growth of Junk Car Removals Milton</a></h2>
                                                <p>The idea of selling up the scrap car can cause trouble for many people. However, Junk ...</p>
                                            </div>
                                            <a href="Growth-of-junk-car.php" class="scrapcar-readmore-btn" title="Growth of junk car removal Milton">Read More</a>
                                        </div>
                                    </li>
                                    
                                    
                                     <!----Blogs--3---->
                                    <li class="col-md-4">
                                        <div class="scrapcar-blog-classic-text">
                                            <figure><a href="Get-Free-Car-Removal.php" title="Get free towing offer in Milton"><img src="img/Blogs/How to Get a Free Car Removal In Milton-banner.jpg" alt="Get free towing offer in Milton"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                                            <div class="scrapcar-classic-figure-text">
                                                <small class="time-btn">October 7th, 2019</small>
                                                 <!--a href="404.html"><i class="automechanic-icon automechanic-interface-1"></i>12</a-->
                                                <h2>
                                                    <a  title="Get free towing offer in Milton" href="Get-Free-Car-Removal.php">How to Get a Free Car Removal In Milton</a></h2>
                                                <p>Do you know? Getting a FREE car removal in Milton is not difficult when you call ...</p>
                                            </div>
                                            <a href="Get-Free-Car-Removal.php" class="scrapcar-readmore-btn" title="Get free towing offer in Milton">Read More</a>
                                        </div>
                                    </li>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->