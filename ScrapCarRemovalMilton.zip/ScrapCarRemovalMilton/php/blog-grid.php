<h2 class="scrapcar-section-heading">Related Articles</h2>
<div class="scrapcar-blog scrapcar-blog-grid scrapcar-related-blog">
    <ul class="row">
        <!--Post 1--->
        <li class="col-md-4">
            <div class="scrapcar-blog-grid-wrap">
                <figure><a href="sell-car-quickly.php" title="How Yau Can sell Your scrap car Quickly"><img src="img/Blogs/How to Sell Your Scrap Car Quickly-banner.jpg" alt="How Yau Can sell Your scrap car Quickly"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                <div class="scrapcar-blog-grid-text">
                    <h2><a href="sell-car-quickly.php" title="How Yau Can sell Your scrap car Quickly">How to Sell Your Scrap Car Quickly</a></h2>
                    <div class="scrapcar-post">
                        <!--figure><img src="img/Blogs/How to Sell Your Scrap Car Quickly-banner.jpg" alt="How to Sell Your Scrap Car Quickly"></figure-->
                        <div class="scrapcar-post-text">
                            <span>Posted by</span>
                            <!--a href="404.html">John Smith</a--><small> October 07, 2019</small>
                        </div>
                    </div>
                </div>
            </div>
        </li>


        <!--Post 2--->
        <li class="col-md-4">
            <div class="scrapcar-blog-grid-wrap">
                <figure><a href="Growth-of-junk-car.php" title="Growth of junk car removal Milton"><img src="img/Blogs/Growth of Junk Car Removals Milton-banner.jpg" alt="Growth of junk car removal Milton"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                
                <div class="scrapcar-blog-grid-text">
                     <h2><a href="Growth-of-junk-car.php" title="Growth of junk car removal Milton">Growth of Junk Car Removals Milton</a></h2>
                    <div class="scrapcar-post">
                        <!--figure><img src="img/Blogs/How to Sell Your Scrap Car Quickly-banner.jpg" alt="How to Sell Your Scrap Car Quickly"></figure-->
                        <div class="scrapcar-post-text">
                            <span>Posted by</span>
                            <!--a href="404.html">John Smith</a--><small> October 07, 2019</small>
                        </div>
                    </div>
                </div>
            </div>
        </li>
        
        <!--Post 3--->
        <li class="col-md-4">
            <div class="scrapcar-blog-grid-wrap">
               <figure><a href="Get-Free-Car-Removal.php" title="Get free towing offer in Milton"><img src="img/Blogs/How to Get a Free Car Removal In Milton-banner.jpg" alt="Get free towing offer in Milton"><i class="automechanic-icon automechanic-technology"></i></a></figure>
                <div class="scrapcar-blog-grid-text">
                    <h2><a href="Get-Free-Car-Removal.php" title="Get free towing offer in Milton">How to Get a Free Car Removal In Milton</a></h2>
                    <div class="scrapcar-post">
                        <!--figure><img src="img/Blogs/How to Sell Your Scrap Car Quickly-banner.jpg" alt="How to Sell Your Scrap Car Quickly"></figure-->
                        <div class="scrapcar-post-text">
                            <span>Posted by</span>
                            <!--a href="404.html">John Smith</a--><small> October 07, 2019</small>
                        </div>
                    </div>
                </div>
            </div>
        </li>


    </ul>
</div>