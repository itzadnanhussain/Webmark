<!-------Schema Tags------------------->
<script type="application/ld+json">
{
	"@context": "http://schema.org",
	"@type": "AutomotiveBusiness",
	"name": "Scrap Car Removal Milton",
	"address": {
		"@type": "PostalAddress",
		"streetAddress": "10 Balmoral drive, ",
		"addressLocality": "Brampton",
		"addressRegion": "ON",
		"postalCode": " L6T1V1"
	},
	"image": "http://scrapcarremovalmilton.ca/img/banner-img2.jpg",
	"email": "carckunker@gmail.com",
	"telePhone": "(647) 691-2932",
	"url": "http://scrapcarremovalmilton.ca/",
	"paymentAccepted": [ "cash" ],
	"openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 0-0",
	"openingHoursSpecification": [ {
		"@type": "OpeningHoursSpecification",
		"dayOfWeek": [
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
			"Sunday"
		],
		"opens": "0",
		"closes": "0"
	} ],
	"geo": {
		"@type": "GeoCoordinates",
		"latitude": "43.706356",
		"longitude": "-79.715991"
	},
	"priceRange":"$$$"

}
</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-143362753-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-143362753-3');
</script>



<!---------------------Facebook Open Graph Meta Tags----------------------------->
 <meta property="og:title" content="Scrap Car Removal Milton"/>
 <meta property="og:type" content="image"/>
 <meta property="og:url" content="http://scrapcarremovalmilton.ca/"/>
 <meta property="og:image" content="http://scrapcarremovalmilton.ca/img/banner-img2.jpg"/> 
 <meta property="og:description" content="Scrap Car Removal offers high-quality service in Milton Wide removing your Used car,Unwanted, Old, scrap  and Junk cars & paying top dollar cash for cars." />
 <meta property="og:site_name" content=" Scrap Car Removal Milton"/>
