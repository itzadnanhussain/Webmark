<aside class="col-md-3">

                    	<div class="scrapcar-sidebar-colr">
							<!--// Widget Search \\-->
	                        <div class="widget widget_search">
	                            <form>
	                                <input value="Search...." onblur="if(this.value == '') { this.value ='Search....'; }" onfocus="if(this.value =='Search....') { this.value = ''; }" tabindex="0" type="text">
	                                <label><input type="submit" value=""></label>
	                            </form>
	                        </div>
	                        <!--// Widget Search \\-->

	                        <!--// Widget Search \\-->
	                        <div class="widget widget_recent_post">
	                            <h2 class="widget-heading">Recent Our Posts</h2>
	                            <ul>
	                            
	                            <!---Post---1---->
								  <li>
								  	<figure><a href="sell-car-quickly.php"><img src="img/Blogs/How to Sell Your Scrap Car Quickly-sidebar.jpg" alt="sell-car-quickly.php"></a></figure>
								  	<div class="widget-recent-text">
										<h6><a href="sell-car-quickly.php" alt="sell-car-quickly.php">How to Sell Your Scrap Car Quickly</a></h6>
										<span>October 7th, 2019</span>
								  	</div>
								  </li>
								  
								  
								  
								 <!---Post---2---->
								  <li>
								  	<figure><a href="Growth-of-junk-car.php"><img src="img/Blogs/Growth of Junk Car Removals Milton-sidebar.jpg" alt="Growth of Junk Car Removals Milton"></a></figure>
								  	<div class="widget-recent-text">
										<h6><a href="Growth-of-junk-car.php" title="Growth of Junk Car Removals Milton">Growth of Junk Car Removals Milton</a></h6>
										<span>October 7th, 2019</span>
								  	</div>
								  </li>
								  
								<!---Post---3---->
								  <li>
								  <figure><a href="Get-Free-Car-Removal.php"><img src="img/Blogs/How to Get a Free Car Removal In Milton-sidebar.jpg" alt="How to Get a Free Car Removal In Milton"></a></figure>
								  	<div class="widget-recent-text">
										<h6><a href="Get-Free-Car-Removal.php" title="How to Get a Free Car Removal In Milton">How to Get a Free Car Removal In Milton</a></h6>
										<span>October 7th, 2019</span>
								  	</div>
								  </li> 
								  
	                            </ul>
	                        </div>
	                        <!--// Widget Search \\-->
	                        
	                        <!--// Widget service \\-->
	                        <div class="widget widget_recent_post">
	                            <h2 class="widget-heading">Our Top Services</h2>
	                            <ul>
	                            
	                            <!---service---1---->
								  <li>
								  	<figure><a href="sell-old-car.php"><img src="img/Services/sell-my-old-car-sidebar.jpg" alt="where i can sell my old car in milton"></a></figure>
								  	<div class="widget-recent-text">
										<h6><a href="sell-old-car.php" title="Where Can I Sell My Old Car In Milton?">Where Can I Sell My Old Car In Milton?</a></h6>
										 
								  	</div>
								  </li> 
								  
								  
								  
	                            </ul>
	                        </div>
	                        
	                        <!--// Widget sportscar \\-->

	                        <!--// Widget Popular Tags \\-->
	                        <div class="widget widget_Popular_Tags">
	                            <h2 class="widget-heading">Popular Tags</h2>
	                            <ul>
									<li><a href="index.php" title="Scrap car removal Milton">Scrap car removal Milton</a></li>
									<li><a href="index.php" title="Junk car removal Milton">Junk car removal Milton</a></li>
									<li><a href="contact-us.php" title="Get An instant Quote">Get top cash for scrap cars</a></li>
									<li><a href="about-us.php" title="Scrap Car removal near me">Scrap yard near me</a></li>
									<li><a href="services.php" title="Auto Disposal service in Milton">Auto Disposal service in Milton</a></li>
									
									
									 
	                            </ul>
	                        </div>
	                        <!--// Widget Popular Tags \\-->

	                        <!--// Widget Flicker post \\-->
	                        <div class="widget Widget_Flicker_post">
	                            <h2 class="widget-heading">Scrap Cars Gallery</h2>
	                            <ul>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-1.jpg" title="auto wreckers
											" class="fancybox"><img src="img/gallery/gallery-1.jpg" alt="scrap car removal"></a></figure>
									</li>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-2.jpg" title="junk car removal milton" class="fancybox"><img src="img/gallery/gallery-2.jpg" alt="junk car removal"></a></figure>
									</li>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-3.jpg" title="get an instant offer" class="fancybox"><img src="img/gallery/gallery-3.jpg" alt="car for top cash"></a></figure>
									</li>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-4.jpg" title="scrap car removal milton" class="fancybox"><img src="img/gallery/gallery-4.jpg" alt="scrap car for cash"></a></figure>
									</li>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-5.jpg" title="sell my junk car" class="fancybox"><img src="img/gallery/gallery-5.jpg" alt="sell my car"></a></figure>
									</li>
									<li>
										<figure><a data-fancybox-group="group" href="img/gallery/gallery-6.jpg" class="fancybox" title="free car removal"><img src="img/gallery/gallery-6.jpg" alt="free car removal"></a></figure>
									</li>
								</ul>
	                        </div>
	                        <div><a target="_blank" id="clx_rev_url" href="https://www.cylex-canada.ca/company/scrap-car-removal-milton-24223591.html?utm_campaign=review+widget&utm_source=admin.cylex-canada.ca&utm_medium=widget&utm_content=more+review+link#reviews" title="All reviews of Scrap Car Removal Milton on Cylex">All reviews</a>
<script src="https://admin.cylex-canada.ca/js/widget/widget.js"></script>
<script>
	var x = new clxReviewWidget({
		headline: 'Customer Reviews',
		showAvatar: false,
		showUsername: false,
		showNegativs: false,
		fir_nr: 24223591,
		borderColor: '#2d7681',
		backgroundColor: '#FFF',
		textColor: '#000',
		lkz: 'CDN',
		domain: 'https://admin.cylex-canada.ca',
		language: 'en-CA'
	});
</script></div>
	                       
	                        <!--// Widget calender >
	                        <div class="widget widget_calendar">
	                            <table>
	                                <caption> October 2019 </caption>
	                                <thead>
	                                    <tr>
	                                        <th title="Monday">M</th>
	                                        <th title="Tuesday">T</th>
	                                        <th title="Wednesday">W</th>
	                                        <th title="Thursday">T</th>
	                                        <th title="Friday">F</th>
	                                        <th title="Saturday">S</th>
	                                        <th title="Sunday">S</th>
	                                    </tr>
	                                </thead>
	                                <tbody>
	                                    <tr>
	                                        <td>31</td><td id="today">1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td>
	                                    </tr>
	                                    <tr>
	                                        <td class="active">7</td><td>8</td><td>9</td><td>10</td><td>11</td><td>12</td><td>13</td>
	                                    </tr>
	                                    <tr>
	                                        <td>14</td><td>15</td><td>16</td><td>17</td><td>18</td><td >19</td><td>20</td>
	                                    </tr>
	                                    <tr>
	                                        <td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td>
	                                    </tr>
	                                    <tr>
	                                        <td>28</td><td>29</td><td>30</td> <td>31</td><td>1</td><td>2</td><td>3</td>
	                                    </tr>
	                                </tbody>
	                            </table>
	                        </div>
	                        <!--// Widget calender \\-->


                    	</div>

                    </aside>
                    