<!DOCTYPE html>
<html lang="en"> 

<head>
    <title> Scrap Car Removal Milton| About Us</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Our Scrap car Removal Company provide Free Pick UP for Your Unwanted, junks ,Old, Wreckeds and Useless Car.Now Get An Instant Offer Just touch with us!">
    <meta name="keywords" content="Scrap car removal, Get Cash For Cars, Dispose Off Car ">
    <meta name="robots" content="index, follow">
    <?php include'php/head.php'?>
</head>

<body>
    <!--// Main Wrapper \\-->
    <div class="scrapcar-main-wrapper">

        <!--// Header \\-->
         <?php include'php/header.php'?>
         <!--// Header \\-->

        <!--// subheader \\-->
        <div class="scrapcar-subheader">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="scrapcar-subheader-wrap">
                            <h1>About Us</h1>
                            <ul class="scrapcar-breadcrumb">
                                <li><a href="index.php" title="scrap car removal Milton">Home</a></li>
                                <li>Pages</li>
                                <li class="active">About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--// subheader \\-->

        <!--// Main Content \\-->
        <div class="scrapcar-main-content scrapcar-content-space">

            <!--// Main Section \\-->
            <div class="scrapcar-main-section scrapcar-about-gallery-wrap">
                <div class="container">
                    <div class="row">

                        <div class="col-md-5">
                            <div class="scrapcar-about-gallery">
                                <ul>
                                    <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-1.jpg" title="scrap car" class="fancybox"><img src="img/about/company-1.jpg" alt="scrap car"></a></figure>
                                    </li>
                                    <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-2.jpg" title="junk car" class="fancybox"><img src="img/about/company-2.jpg" alt="junk car"></a></figure>
                                    </li>
                                    <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-3.jpg" title="car for cash" class="fancybox"><img src="img/about/company-3.jpg" alt="car for cash"></a></figure>
                                    </li>
                                   <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-4.jpg" title="sell my car" class="fancybox"><img src="img/about/company-4.jpg" alt="sell my car"></a></figure>
                                    </li>
                                    <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-5.jpg" title="old car removal" class="fancybox"><img src="img/about/company-5.jpg" alt="old car removal"></a></figure>
                                    </li>
                                    <li>
                                        <figure><a data-fancybox-group="group" href="img/about/company-6.jpg" title="used car removal" class="fancybox"><img src="img/about/company-6.jpg" alt="used car removal"></a></figure>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="scrapcar-aboutus">
                                <h2>WHY WE ARE DIFFERENT:</h2>
                                <h3>Who We Are</h3>
                                <span class="text-justify">WE DO NOT BARGAIN WITH YOU IN PERSON. THE QUOTE WE PROMISE YOU FOR YOUR JUNK CAR ON THE PHONE IS OUR WORD. WE STAND BY OUR WORD. NO EXCEPTIONS.</span>
                                <p class="text-justify">WE COME TO YOU, ANYWHERE, ANYTIME, ANY VEHICLE, ANY MAKE, ANY CONDITION.
                                WE ARE A VERY WELL KNOWN GROUP OF JUNK CAR AUTO RECYCLERS AND ARE HIGHLY RECOMMENDED IN OUR COMMUNITY. WE PRIDE OURSELVES ON OUR HONESTY AND INTEGRITY 
                                
                                
                                WE COLLECT, DISPOSE AND RECYCLE YOUR SCRAP AND/OR JUNK CARS IN A TIME EFFECTIVE AND ECO-FRIENDLY MANNER. THE VEHICLES ARE TAKEN APART IN THE JUNK YARD AND EVERY RESPECTIVE PART IS REMOVED AND DISPOSED OF.  THE EXTRA PARTS ARE THEN TAKEN TO ANOTHER LOCATION, WHERE THE VEHICLE IS PRESSED AND COMPACTED AND/OR SHREDDED. WE TAKE PRIDE IN KNOWING OUR METHOD OF DISPOSAL LEAVES A POSITIVE FOOTPRINT ON OUR PLANET.YOUR SATISFACTION IS OUR PRIORITY.</p>
                                <a href="contact-us.php" title="Get an instant Offer" class="scrapcar-simple-btn"><i class="automechanic-icon automechanic-people-1"></i>Contact Us</a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--// Main Section \\-->

            <!--// Main Section \\-->
            <div class="scrapcar-main-section scrapcar-about-worksfull">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="scrapcar-fancy-titlev2">
                                <h2>How It Works</h2>
                                <p>We're offering top dollar cash servicess in Milton.</p>
                            </div>
                            <div class="scrapcar-about-works">
                                <ul>
                                    <li>
                                        <div class="scrapcar-works-text">
                                            <small>01</small>
                                            <i class="automechanic-icon automechanic-arrows"></i>
                                            <h5><a href="services.php" title="Make a Call">Make a Call</a></h5>
                                            <p>GIVE US A CALL WITH THE MAKE AND MODEL OF YOUR SCRAP AND/OR JUNK  VEHICLE</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="scrapcar-works-text">
                                            <small>02</small>
                                            <i class="automechanic-icon automechanic-arrows"></i>
                                            <h5><a href="services.php" title="Trusted Offer">Trusted Top Offer</a></h5>
                                            <p>ONE OF OUR PROFESSIONAL REPRESENTATIVES WILL PROVIDE YOU WITH A FAIR QUOTE FOR YOUR JUNK CAR</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="scrapcar-works-text">
                                            <small>03</small>
                                            <i class="automechanic-icon automechanic-transport"></i>
                                            <h5><a href="services.php" title="Auto Towing">Free Towing</a></h5>
                                            <p>ONCE YOU ARE SATISFIED WITH THE OFFER FOR YOUR SCRAP VEHICLE WE WILL COME TO YOU, REGARDLESS OF YOUR LOCATION</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="scrapcar-works-text">
                                            <small>04</small>
                                            <i class="automechanic-icon  automechanic-arrows"></i>
                                            <h5><a href="services.php" title="get top cash">Get Cash </a></h5>
                                            <p>WE IMMEDIATELY TOW YOUR VEHICLE AWAY FOR NO COST WHATSOEVER.YOU GET PAID TOP DOLLAR IN CASH ON THE SPOT!</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->
 
		 <!--// Main Section \\-->
            <div class="scrapcar-main-section scrapcar-modernfull">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="scrapcar-fancy-title">
                                <h2>Why choose us<small></small></h2>
                                <span>Our Advantages</span>
                            </div>
                            <div class="scrapcar-services scrapcar-services-modern">
                                <ul class="row">
                                    <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-coins"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php" title="Get Top Cash For Scrap Cars">Cash For Scrap Cars</a></h2>
                                            <p class="text-justify">We pay you top dollar for your used,old,unwanted, demaged,end of life vehicle, junk and scrap cars.If you thinking, how can i sell my junk car? We are the trusted and professional scrap car buyers in milton, who buy cars without title near me.</p>
                                        </div>
                                    </li>
                                    <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-transport"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php">Sell Scrap Car</a></h2>
                                            <p class="text-justify">ScrapCarRemovalMilton's free, Our Company top dollar quote service saves their client's time and a lot of hesitation during dealings, trying to get the best money for junk cars. We'll instantly offer you the top cash for your scrap car in your Milton Area.</p>
                                        </div>
                                    </li>
                                     <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-transport"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php">Junk Car Collection</a></h2>
                                            <p class="text-justify">Not only will Our dedicated team notify you what your Junk car is worthy, when you choose scrapcarremovalmilton you can sort to have your junk car Picked up at a time when you are free. Your junk car can be Picked up from anyplace, your work, home, a garage.</p>
                                        </div>
                                    </li>
                                    <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-tool4"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php" title="Trusted PaperWork">Trusted PaperWork</a></h2>
                                            <p class="text-justify">If you want to sell your scrap car for an official and trusted company. Then You have come to the right place! scrap car removal Milton's dedicated team providing trained and experienced car buyers. Just Go to Our <a href="contact-us.php" title="Scrap Car Buyers" class="internal-link">contact page</a>  and fill the form and stay with us!</p>
                                        </div>
                                    </li>
                                    
                                   
                                    <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-arrows"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php">scrap car recycling</a></h2>
                                            <p class="text-justify">With a local Scrap car recycling company in Milton. our clients never for away from us.SO if you have an old car and you want to recycle it in Milton. You can make an instant deal with scrapcarremovalmilton you can feel relax that your junk car will be removed to the top-rated car recycling company.</p>
                                        </div>
                                    </li>
                                    <li class="col-md-4">
                                        <i class="automechanic-icon automechanic-multimedia"></i>
                                        <div class="scrapcar-services-text">
                                            <h2><a href="services.php">Customer Satisfaction </a></h2>
                                            <p class="text-justify">Last 10 years, we have helped thousands of scrap car removal  owners in Milton.Our customer services workforce is on one platform during the entire process of car towing to help you without any hasitation.And Offering the top dollar cash for your scrap car.Customer satisfection is our first priority.
</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--// Main Section \\-->
		
		<!--// Main Section \\-->

		<!--// Main Section \\-->
		<div class="scrapcar-main-section scrapcar-involved-full">
			<span class="transpant-call-layer"></span>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="scrapcar-get-involved">
							<h2>OUR <small>COMPANY</small> ALWAYS!</h2>
							<p>PROVIDES UP FRONT CASH PAID IN PERSON UPON RECEIPT OF THE SCRAP CAR AND/OR JUNK VEHICLE.NO PAPERWORK OR IN PERSON ESTIMATES, WE TAKE CARE OF ALL OF THE ESTIMATES OVER THE PHONE.THE OFFER WE GIVE YOU IS AGREED UPON BY BOTH PARTIES, NO HIDDEN CHARGES OR SURPRISES.FREE SAME DAY PICK UP AND TOW IN MILTON.</p>
							<div class="involved-social-icone">
								<ul>
                                    <li><a href="ttps://web.facebook.com/Scrap-Car-Removal-Milton-1008954615965309/" title="scrap car removal milton facebook page" class="facebook"><i class="fa fa-facebook"></i>facebook</a></li>
                                    <li><a href="#" title="coming soon" class="twitter"><i class="fa fa-twitter"></i>Twitter</a></li>
                                    <li><a href="#" title="coming soon" class="linkedin"><i class="fa fa-linkedin"></i>linkedin</a></li>
                                </ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--// Main Section \\-->


        </div>
        <!--// Main Content \\-->

        <!--// Footer \\--> 
        <?php include'php/footer.php'?> 
        <div class="clearfix"></div> 
    </div> 
</body> 
</html>