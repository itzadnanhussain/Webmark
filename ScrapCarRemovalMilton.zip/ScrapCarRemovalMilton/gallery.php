<!DOCTYPE html>
<html lang="en"> 

<head>
  <title>Gallery|Scrap Car Rmoval Miloton </title>
  <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Our Scrap car Removal Company provide Free Towing for Your Unwanted, junks ,Old, Wreckeds and Useless Car.Now Get An Instant Offer Just touch with us!">
<meta name="keywords" content="Scrap car removal, Get Cash For Scrap Cars, Dispose Off Car ">
<meta name="robots" content="index, follow">
   <?php include'php/head.php'?>
</head>

<body>

    <!--// Main Wrapper \\-->
    <div class="scrapcar-main-wrapper">

        <!--// Header \\-->
         <?php include'php/header.php'?>
         <!--// Header \\-->

	<!--// subheader \\-->
	<div class="scrapcar-subheader">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="scrapcar-subheader-wrap">
						<h1>Gallery</h1>
						<ul class="scrapcar-breadcrumb">
							<li><a href="index.php" title="scrap car removal Miloton">Home</a></li>
							<li>Pages</li>
							<li class="active">Gallery</li>
						</ul>
					</div>
				</div>
			</div>
		</div>			 
	</div>
	<!--// subheader \\-->

	<!--// Main Content \\-->
	<div class="scrapcar-main-content">

		<!--// Main Section \\-->
		<div class="scrapcar-main-section">
			<div class="container">
				<div class="row">

					<div class="col-md-12">
						<div class="scrapcar-gallery scrapcar-modern-gallery">
							<ul class="row">
								<li class="col-md-6">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-1.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-1.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-6">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-2.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-2.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-3">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-3.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-3.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-3">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-4.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-4.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-3">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-5.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-5.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-3">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-6.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-6.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-4">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-7.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-7.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-4">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-8.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-8.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
								<li class="col-md-4">
									<figure><span></span><a data-fancybox-group="group" href="img/gallery/classic-gallery-9.jpg" title="junk car removal" class="fancybox"><img src="img/gallery/classic-gallery-9.jpg" alt="scrap car removal"><i class="automechanic-icon automechanic-null-1"></i></a></figure>
								</li>
							</ul>
						</div>
						<!--// Pagination \\>
                        <div class="scrapcar-pagination">
                          <ul class="page-numbers">
                             <li><a class="previous page-numbers" href="404.html"><span aria-label="Next"><i class="fa fa-angle-left"></i></span></a></li>
                             <li><span class="page-numbers current">01</span></li>
                             <li><a class="page-numbers" href="404.html">02</a></li>
                             <li><a class="page-numbers" href="404.html">03</a></li>
                             <li><a class="page-numbers" href="404.html">04</a></li>
                             <li><a class="next page-numbers" href="404.html"><span aria-label="Next"><i class="fa fa-angle-right"></i></span></a></li>
                          </ul>
                        </div>
                        <!--// Pagination \\-->
					</div>

				</div>
			</div>
		</div>
		<!--// Main Section \\-->


	</div>
	<!--// Main Content \\-->

	
        <!--// Footer \\--> 
        <?php include'php/footer.php'?> 
        <div class="clearfix"></div> 
    </div> 
</body> 
</html>