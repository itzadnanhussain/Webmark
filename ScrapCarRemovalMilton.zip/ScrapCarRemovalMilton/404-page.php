DOCTYPE html>
<html lang="en"> 
 <head>
	 
	 <title>404 Page| Content Not Found</title> 
	 <?php include'php/head.php'?>
	</head>
	<body>
	 
	 <!--// Main Wrapper \\-->
	 <div class="scrapcar-main-wrapper">

	<!--// Header \\-->
	<?php include'php/header.php'?>
	<!--// Header \\-->

	<!--// subheader \\-->
	<div class="scrapcar-subheader">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="scrapcar-subheader-wrap">
						<h1>Error 404</h1>
						<ul class="scrapcar-breadcrumb">
							<li><a href="index.php">Home</a></li>
							<li>Pages</li>
							<li class="active scrapcar-color">Error 404</li>
						</ul>
					</div>
				</div>
			</div>
		</div>			 
	</div>
	<!--// subheader \\-->

	<!--// Main Content \\-->
	<div class="scrapcar-main-content">

		<!--// Main Section \\-->
		<div class="scrapcar-main-section">
			<div class="container">
				<div class="row">

					<div class="col-md-12">
						<div class="scrapcar-error-page">
							<img src="images/eror-icon.png" alt="">
							<h2>404 <span>Error</span></h2>
							<h3>Oops! Here Is Nothing Found</h3>
							<p>Looks like the page you're trying to visit does not exist. plz check the URL and try your luck again.</p>
							<form class="scrapcar-error-form">
								<input type="text" value="Type Here" onblur="if(this.value == '') { this.value ='Type Here'; }" onfocus="if(this.value =='Type Here') { this.value = ''; }">
								<label><input type="submit" value="Search now"><i class="automechanic-icon automechanic-arrows-1"></i></label>
								<a href="index.php" class="scrapcar-error-btn scrapcar-bgcolor">Back to Homepage</a>
							</form>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!--// Main Section \\-->


	</div>
	<!--// Main Content \\-->


        <!--// Footer \\-->
        <?php include'php/footer.php'?>
        <div class="clearfix"></div>
    </div>
</body>

</html>