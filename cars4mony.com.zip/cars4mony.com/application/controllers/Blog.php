<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Blog extends CI_Controller
{
    ///****************Index ************* */
    public function index()
    {
        $view = 'blogs/index';
        $data = array();
        $this->loadView($view, $data);
    }

    ///****************Post 1 ************* */
    public function post_1() 
    {
        $view = 'blogs/sell-your-scrap-car-in-mississauga';
        $data = array();
        $this->loadView($view, $data);
    }
    ///****************Post 2 ************* */
    public function post_2() 
    {
        $view = 'blogs/scrap-car-removal-in-mississauga';
        $data = array();
        $this->loadView($view, $data);
    }
    ///****************Post 3 ************* */
    public function post_3() 
    {
        $view = 'blogs/cash-for-scrap-cars-in-mississauga';
        $data = array();
        $this->loadView($view, $data);
    }


    ///****************view function********* */
    public function loadView($view, $data)
    {
        $this->load->view('template/head', $data);
        $this->load->view($view);
        $this->load->view('template/footer');
    }
}
