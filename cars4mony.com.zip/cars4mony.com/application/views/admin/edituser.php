<div class="row">
    
    <div class="col-md-2 quickmenu">
    <h5>Quick Menu</h5>
        <a href="<?php echo base_url()?>admin/dashboard">Dashboard</a>
        <a href="<?php echo base_url()?>admin/createuser" >Create User</a>
        <a href="<?php echo base_url();?>admin/logout" >Logout</a>
    </div>
    <div class="col-md-1">
    </div>
    <div class="col-md-6" id="formContent" style="text-align:center">
        <br>
    <h3>Edit User</h3> 
        <form method="post" action="<?php echo base_url()?>admin/edituseraction/<?php echo $userdatas->pkuserid?>" id="myForm" autocomplete="off">
              <input type="text" class="second frmctrl" name="username" placeholder="User Name"  autocomplete="nope" value="<?php echo $userdatas->username?>">
              <input type="email" class="second frmctrl" name="email" placeholder="Email"  autocomplete="nope" value="<?php echo $userdatas->email?>">
              <input type="password" id="password" class="third frmctrl" name="password" placeholder="Password"  autocomplete="nope">
              <input type="text" class="second frmctrl" name="accountname" placeholder="Account Name"  autocomplete="nope" value="<?php echo $userdatas->accountname?>">
              <input type="text" class="second frmctrl" name="accountid" placeholder="Account Id" value="<?php echo $userdatas->accountid?>"><br>
            <div style="color:green">* Leave the fields, which you don't want to change.</div>
                <div class="formstatus"></div>
              <input type="submit" class="btn btn-success" value="Edit User">
            
        </form>
        <br>
    </div>
</div>
<br>
<br>
<br>
<br>