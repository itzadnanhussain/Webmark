<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
    <div class="col-md-2 quickmenu">
    <h5>Quick Menu</h5>
        <a href="<?php echo base_url()?>admin/dashboard" class="a-active">Dashboard</a>
        <a href="<?php echo base_url()?>admin/createuser">Create User</a>
        <a href="<?php echo base_url();?>admin/logout" >Logout</a>
    </div>
    
    <div class="col-md-10">
        <table>
            <tr>
                <th>
                    No.
                </th>
                <th>
                    Username
                </th>
                <th>
                    Account Name
                </th>
                <th>
                    Account ID
                </th>
                <th>
                    Action
                </th>
            </tr>
            <?php 
                    if(is_array($usersdata) || is_object($usersdata)){
                        $i=1;
                    foreach ($usersdata as $value){ ?>
                        
                        <tr>
                            <td>
                                <?php echo $i;?>
                            </td>
                            <td>
                                <?php echo $value->username;?>
                            </td>
                            <td>
                                <?php echo $value->accountname;?>
                            </td>
                            <td>
                                <?php echo $value->accountid;?>
                            </td>
                            <td>
                                <form action="<?php echo base_url()?>admin/deleteuseraction" id="myForm" method="post" >
                                <a href="<?php echo base_url()?>admin/edituser/<?php echo $value->pkuserid; ?>" class="btn btn-info" title="Edit User"><i class="fa fa-bars"></i></a>
                                <a class="btn btn-danger" onclick="deleteUser()" title="Delete User"><i class="fa fa-remove"></i></a>
                                <div class="formstatus"></div>
                                <input type="hidden" name ="userid" value="<?php echo $value->pkuserid; ?>">
                                </form>
                            </td>
                        </tr>
                    <?php
                          $i++;
                           }
                      } 
                    ?>
            
        </table>
        <br>
    </div>
</div>
<script>
function deleteUser() {
    var ask = window.confirm("Are you sure you want to delete this User?");
    if (ask) {
        $("#myForm").submit();

    }
}
</script>

