<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <!-- Icon -->
    <div class="fadeIn first">
      <h4>Admin Login</h4>
    </div>
    <!-- Login Form -->
    <form method="post" action="<?php echo base_url()?>admin/loginaction" id="myForm">
      <input type="text" id="login" class="fadeIn second frmctrl" name="email" placeholder="Email">
      <input type="password" id="password" class="fadeIn third frmctrl" name="password" placeholder="Password">
      
    <div class="formstatus"></div>
      <input type="submit" class="fadeIn fourth btn-success" value="Log In">
    </form>
    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#"  data-toggle="modal" data-target="#myModal">Forgot Password?</a>
    </div>
  </div>
</div>
<?php $this->view('template/forgotpass');?>