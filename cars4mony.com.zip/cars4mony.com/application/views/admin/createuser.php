<div class="row">
    
    <div class="col-md-2 quickmenu">
    <h5>Quick Menu</h5>
        <a href="<?php echo base_url()?>admin/dashboard">Dashboard</a>
        <a href="<?php echo base_url()?>admin/createuser" class="a-active">Create User</a>
        <a href="<?php echo base_url();?>admin/logout" >Logout</a>
    </div>
    <div class="col-md-1">
    </div>
    <div class="col-md-6" id="formContent" style="text-align:center">
        <br>
    <h3>Create User</h3>
        <form method="post" action="<?php echo base_url()?>admin/createuseraction" id="myForm" autocomplete="off">
              <input type="text" class="second frmctrl" name="username" placeholder="User Name"  autocomplete="nope">
              <input type="email" class="second frmctrl" name="email" placeholder="Email"  autocomplete="nope">
              <input type="password" id="password" class="third frmctrl" name="password" placeholder="Password"  autocomplete="nope">
              <input type="text" class="second frmctrl" name="accountname" placeholder="Account Name"  autocomplete="nope">
              <input type="text" class="second frmctrl" name="accountid" placeholder="Account Id"><br>
                <div class="formstatus"></div>
              <input type="submit" class="btn btn-success" value="Create User">
        </form>
        <br>
    </div>
</div>