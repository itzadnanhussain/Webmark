<?php
	global $conn;
	$conn = mysqli_connect('50.62.177.19', 'akramusman', 'Maani@1721', 'click_count_db') 
		or die('ERROR: Cannot Connect to Database');
	$query = 'insert into c4m_clicks_tb values(current_date());';
	$result = mysqli_query($conn, $query);
	mysqli_close($conn);
?>