<!----- Banner------->
   <div class="container-fluid banr1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 bannInn1">
                <div class="bannStrip1">
                    <h1>Easy Scrap Car Removal Mississauga</h1> 
                    <h3>Scarp Car Removal & Sell Scrap Car Service</h3>
                    <div class="quote_btn">
                         <a href="scrap-car-removal-Mississauga.php" data-animation="animated fadeInLeft" class="Message">Send Message</a> 
						<a href="scrap-car-removal-Mississauga.php" data-animation="animated fadeInRight" class="">Call Now</a>
                     </div> 
                </div> 
            </div>
        </div>
    </div>
</div>