
    <div class="form">
        <div class="container">
            <div class="shadowbox_res">
                <div class="row">
                    <div class="col-sm-6 call">
                        <p id="con_text">Get Quote Now</p>
						<form id="click_frm"method="post" action="php/click_counter.php">
							<p id="con_no">
								<a href="tel:647-484-6996">647-484-6996</a>
							</p>
						</form>
                    </div>
                    <div class="col-sm-6">
                        <form name="contactform" id="messageform" method="post" action="php/sendmail.php">
                            <label>Fill Online Form:</label><br/>
                            <div class="form-group col-sm-12">
                                <input type="text" name="name" class="form-control" placeholder="Enter Your Name.." required> </div>
                            <div class="form-group col-sm-12">
                                <input type="required" name="email" class="form-control" placeholder="Enter Your Email.." required> </div>
                            <div class="form-group col-sm-12">
                                <input type="number" name="phone" class="form-control" placeholder="Enter Your Phone Number.." required> </div>
                                <div class="form-group col-sm-12">
                                <input type="text" name="Address" class="form-control" placeholder="Enter Vehicle's Pickup Address" required> </div>
                            <div class="form-group col-sm-12">
                                <textarea class="form-control" name="message" rows="5" placeholder="Enter Vehicle's Information: here.." required></textarea>
                            </div>
                            <div class="form-group" style="text-align:center;">
                                <input id="submitbtn" class="submit_btn" type="submit" value="Send Message"> </div>
                        </form>
                        <label id="message"></label>
                    </div>
                </div>
            </div>
        </div>
    </div>