<script>
	<?php 
    
        include getcwd()."/assets/js/jquery.min.js";
		/*custom slider*/
        include getcwd()."/assets/js/sweetalert.min.js";
		/*Bootsrtap*/
        include getcwd()."/assets/js/bootstrap.min.js";
		/*custom slider*/
        include getcwd()."/assets/js/slider.js";
		/*cars4money js*/
        include getcwd()."/assets/js/custom.js";
	?> 
</script>