<div class="form_main well">
    <h4>Get A Quote</h4>
    <div class="form">
        <form name="contactform" method="post" action="php/sendmail.php" id="messageform">
            <input type="text" required="required" placeholder="Please input your Name" value="" name="name" class="txt">
            
            <input type="text" required="required" placeholder="Please input your Email" value="" name="email" class="txt">

            <input type="text" required="required" placeholder="Please input your mobile No" value="" name="phone" class="txt">

            

            <input type="text" required="required" placeholder="Please input your Address" value="" name="Address" class="txt">

            <textarea placeholder="Describe Vehicle Model Make etc" name="message" type="text" class="txt_3" spellcheck="false"></textarea>

            <input type="submit" onclick="submitForm()" value="send message" name="submit" class="txt2" title="Send mail to Instant Scrapper">
        </form>
    </div>
</div>