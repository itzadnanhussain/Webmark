<style>
    <?php
     
    /*custom css*/
    include getcwd()."/assets/css/style.css";
    /*Bootstrap*/
    include getcwd().'/assets/css/bootstrap.min.css';
    /*nav css*/
    include getcwd().'/assets/css/nav.css';
    /*slider*/ 
    include getcwd().'/assets/css/slider.css';
    /*slider*/ 
    include getcwd().'/assets/css/home-banner.css';
    /*Form*/
    include getcwd().'/assets/css/form.css';
     /*slider*/
    include getcwd().'/assets/css/footer.css'; 
     
      /*Home*/
    include getcwd().'/assets/css/Home.css';
    
      
    /*sweet alerts*/ 
    include getcwd().'/assets/css/sweetalert.css';  
    /*animate slider css*/
    include getcwd().'/assets/css/animate.css';
    include getcwd().'/assets/css/custom.css';
    
    
    ?>
</style>