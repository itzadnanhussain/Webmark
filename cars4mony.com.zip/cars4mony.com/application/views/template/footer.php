
     <footer class="footer">
     <div class="container">
         <!--Row 1--->
         <div class="row">
             <div class="col-sm-12 footer-text">
                <p>©2017.Easy Scrap Car Removal. All Rights Reserved.</p>
                 
             </div>
         </div>
          <!--Row 2--->
         <div class="row">
             <div class="col-sm-12 footer-text">
                <a href="https://web.facebook.com/easyscrapremoval/" title="facebook"><i class="fa fa-facebook-square"></i></a> 
             </div>
         </div>
     </div>
 </footer>
    <?php $this->view('template/load_js')?>
</body>

</html>