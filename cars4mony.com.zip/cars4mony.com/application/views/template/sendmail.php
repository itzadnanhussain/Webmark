<?php
	$errors = '';
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	    $to = 'carclunker@gmail.com'; //<-----Put Your email address here.
	    if (empty($_POST['name']) || empty($_POST['phone'])|| empty($_POST['Address']) || empty($_POST['email']) || empty($_POST['message'])) {
	        $errors = "Error: all fields are required";
	    }
	    $name          = $_POST['name'];
	    $email_address = $_POST['email'];
	    $phone         = $_POST['phone'];
	     $Address     = $_POST['Address'];
	    $message       = $_POST['message'];
	    $country       = $_POST['country'];
	    if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i", $email_address)) {
	        $errors = "Error: Invalid email address";
	    }
	    
	    if (empty($errors)) {
	        if (strpos($message, 'Mani') !== false) {
	            $pieces = explode(" ", $message);
	            $conn = mysqli_connect('50.62.177.19', 'akramusman', 'Maani@1721', 'click_count_db') or die('ERROR: Cannot Connect to Database');
	            $query = "select count(click_date) as click_count from c4m_clicks_tb where datediff(CURRENT_DATE(), click_date) <= $pieces[1];";
	            if ($result = mysqli_query($conn, $query)) {
	                /* fetch associative array */
	                while ($row = mysqli_fetch_assoc($result)) {
	                    $email_subject = "C4M Clicks Count";
	                    $email_body= $row['click_count']." calls have been made from C4M during last $pieces[1] days";
	                    if (mail($to, $email_subject, $email_body)) {
	                        $errors = "yes";
	                    } else {
	                        $errors = "Sorry, there has been an error!!";
	                    }
	                }
	                /* free result set */
	                mysqli_free_result($result);
	            }
	            mysqli_close($conn);
	        } else {
	            $email_subject = "$name";
	            $email_body    = "Message From C4M:\n" . "Location: $country\n" . "Name: $name\nPhone: $phone\nAddress: $Address\n" . "Email: $email_address\nMessage: \n$message";
	            $headers = "From: $email_address";
	            if (mail($to, $email_subject, $email_body,$headers)) {
	                $errors = "yes";
	            } else {
	                $errors = "Sorry, there has been an error!!";
	            }
	        }
	        
	    }
	    echo $errors;
	} else {
	    echo "<h2>Access Denied</h2>";
	}
?>