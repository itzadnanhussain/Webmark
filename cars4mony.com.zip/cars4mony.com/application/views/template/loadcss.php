<style>
    <?php
        
    echo "\n\n /*Bootstrap css*/ \n\n";
    include getcwd()."/assets/css/bootstrap.min.css";
        
    echo "\n\n /*style css*/ \n\n";
    include getcwd()."/assets/css/style.css";
    ?>
</style>