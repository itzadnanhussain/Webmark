<div class="container-fluid banr1">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 bannInn">
                <div class="bannStrip1">
                    <h1>Easy Scrap Car Removal Mississauga</h1> 
                    <h3>Scarp Car Removal & Sell Scrap Car Service</h3>
                     <div class="banner_btn">
                         <a href="scrap-car-removal-Mississauga.php" data-animation="animated fadeInLeft">Send Message</a> 
						<a href="scrap-car-removal-Mississauga.php" data-animation="animated fadeInRight">Call Now</a>
                     </div>
                
                </div>
            </div>
            <div class="col-md-4 banner-form">
                <?php include 'form.php'?>

            </div>
        </div>
    </div>
</div>