  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Forgot Password??</h4>
        </div>
          <form action="<?php echo base_url()?>admin/forgotpass" method="post" id="myForm2">
            <div class="modal-body">
              <p>Please enter the registered email id.</p>
                <input type="email" name="email">
                <div class="formstatus"></div>
            </div>
              
            <div class="modal-footer">
                <button type="submit" class="btn btn-success">Send Email</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
            </form>
      </div>
      
    </div>
  </div>
