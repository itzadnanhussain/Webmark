<header class="">
	<nav class="navbar navbar-inverse navbar-fixed-top nav-bg">
	  <div class="container-fluid">
		<div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
		  <a class="navbar-brand" href="http://cars4money.com/">Easy<i><b>Scrap</b></i>CarRemoval</a>
		</div>
		<div class="collapse navbar-collapse" id="myNavbar">
			<ul class="nav navbar-nav navbar-right "> 
				 <!--Drop Down List--->
                <li class="nav-item dropdown"><a href="services.php" title=" ">Services</a> 
                    <div class="dropdown-menu"> 
                        <a href="cash-for-scrap-cars-Mississauga.php" >Cash for scrap cars in Mississauga</a>
                       <a href="junk-car-removal-Mississauga.php" >Junk car removal Mississauga</a>
                       <a href="Sell my car in Mississauga.php" >Sell Scrap Car In Mississauga</a>
                       <a href="sell-scrap-car.php" >Sell Used Cars In Mississauga</a>
                       <a href="old-car-removal-Mississauga.php" >Old car removal in Mississauga</a>
                    </div>
                </li>
			  <li><a href="cars-for-cash.php">Cars For Cash</a></li> 
			  <li><a href="company.php">Company</a></li>
			  <li><a href="scrap-car-removal-Mississauga.php">Contact Us</a></li>
			  <li><a href="#">Blog</a></li>
			</ul>
		</div>
	  </div>
	</nav>
</header>
