<?php $this->view('template/banner'); ?>
<div class="container" id="index-content">
    <div class="row">
        <!--Post 3 ---->
        <div class="col-sm-12 col-md-12">
            <h1>Find A Cash for scrap cars In Mississauga</h1>
            <span>Posted on 19th:November:2020</span>
            <p>At EASY SCRAP CAR REMOVAL Mississauga, we’ve been in the scrap car buying business for many years. Being an SUV expert, we can provide a great offers and services to our customers because we are established with an experienced staff and great information of car buyers that give us the means to convert your car into cash immediately.</p>
             <a href="<?php echo base_url('blogs/cash-for-scrap-cars-in-mississauga') ?>">Read More</a>

        </div>

        <!--Post 2 ---->
        <div class="col-sm-12 col-md-12">
            <h1>Scrap Car Removals In Mississauga</h1>
            <span>Posted on 16th:October:2020</span>
            <p>What if you discover an ideal car, however it happens to be halfway throughout the country? It seems like an achievable task? Start by watching several pictures online, trust somebody on the other end with the essential facts, deals with the required paperwork and obtain the brand new car home or you can also become a Easy Scrap Car Removal in Mississauga. Here is how it is possible in details</p>
            <a href="<?php echo base_url('blogs/scrap-car-removal-in-mississauga') ?>">Read More</a>

        </div>
        <!--Post 1 ---->
        <div class="col-sm-12 col-md-12">
            <h1>Sell Your Scrap Car In Mississauga</h1>
            <span>Posted on 4th:September:2020</span>
            <p>Have you tried to sell the scrap car? Or have you ever wondered how to dispose of junk cars. Easy Scrap Car Removal offers the junk car disposal service in city of Mississauga and neighboring cities like Georgetown, Brampton, Milton and Etobicoke. If you have old cars there are few other ways you can sell your scrap car.</p>
            <a href="<?php echo base_url('blogs/sell-you-scrap-car-in-mississauga') ?>">Read More</a>

        </div>

    </div>

</div>