
    <?php $this->view('template/home-banner'); ?>
    <!---Content Section 1---------->
    <div class="container-fluid Section-1-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-justify">
                    <h2 class="text-center">Are you still looking to get rid of your old vintage car or is there an unwanted, wrecked, dead or damaged junk car in your driveway irritating you?</h2>
                    <p>Easy Scrap Car Removal Mississauga is the one of the popular and widely renowned scrap car buying company dealing with instant scrap car removal in Mississauga area while offering cash for junk cars in return. More than one and a half million unwanted cars get recycled every year in Canada. Easy Scrap Car Removal Mississauga ensures that your unwanted junk cars get disposed off according to MINISTRY OF ENVIRONMENT rules and regulations and take care of any oil spills or mess ups during hooking up of damaged scrap cars. Easy Scrap Car Removal Auto recyclers Mississauga are always available to help you to get rid of your junk car with our 100% Eco-friendly Auto disposal service in Mississauga and surrounding areas.</p>
                </div>
            </div>
        </div>
    </div>

    <!---Content Section 2 Services---------->
    <div class="container-fluid Section-2-bg">
        <div class="container">
            <div class="row">
                <h2>Services</h2>
                <div class="col-sm-7 text-justify">
                    <p>Easy Scrap Car Removal Mississauga are professional auto wreckers providing </p>
                    <ul>
                        <li>auto recycling</li>
                        <li>Junk vehicle disposal</li>
                        <li>Junk car removal Mississauga</li>
                        <li>Free Pick up for Junk Cars</li>
                        <li>Junk vehicle pickup </li>
                        <li>Scrap Car Removal Service</li>
                    </ul>
                    <p>Easy Scrap Car Removal Mississauga picks up all type of </p>
                    <ul>
                        <li>Any Condition Junk Cars</li>
                        <li>Major or minor damaged vehicles</li>
                        <li>Unwanted Scrap Cars occupying your driveway</li>
                        <li>Accidental damage, Mechanically broken</li>
                        <li>Dead or alive scrap Cars without keys</li>
                        <li>Underground basement removal</li>
                        <li>Flat or ceased tires junk vehicles</li>
                        <li>Trucks, Vans, Mini Vans, SUVs, Trailers, Road Rollers, Buses, Fork-lifters in any condition.</li>
                    </ul>

                </div>
                <div class="col-sm-5 co-xs-12 service-img">
                    <img src="<?php echo base_url()?>/assets/images/services.png">
                </div>
                <div class="col-sm-12 p2">
                    <p>Easy Scrap Car Removal Mississauga not only pay Cash for scrap cars Mississauga but also ensure to recycle them or dispose off <span>END OF LIFE VEHICLES (ELVs)</span> responsibly.
                        We Pick up scrap cars from any location within our service area within 1 hour or according to your schedule 7 days a week.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!---Content Section 3---------->
    <div class="container-fluid Section-1-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-justify">
                    <h2 class="text-center">Top Cash for your Scrap/Junk Cars – NO BARGAIN ON THE SPOT</h2>
                    <p>Cash for junk cars Mississauga generates great value for your scrap cars and offers free towing service. We bring you the convergence of all you need to junk your car and generate value out of scrap vehicles. Easy Scrap Car Removal Mississauga provides free estimate/quote for your junk car. All you need to contact Easy Scrap Car Removal Mississauga and we will offer you the best price for your Junk Cars/Vehicles right away. On the other hand, Easy Scrap Removal Mississauga ensures to pay you the quoted price while picking up the car from your driveway by following our Firm Policy of No Bargain on your spot. Easy Scrap Car Removal Mississauga ensures your peace of mind and saves you from indulging in any kind of worry, we make sure to provide a Bill of Sale as a proof of transaction for your future reference and insurance cancellation.</p>
                </div>
            </div>
        </div>
    </div>


    <!---Content Section 4 Services---------->
    <div class="container-fluid Section-2-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 p2">
                    <h2>How we do?</h2>
                    <p>Scrap car removal process is very simple and easy. Contact us and Get an instant quote at the numbers provided on our website. Depending upon Make, Model and Year of the car we will offer you a price. If you accept the quote and provide us with your complete address, our driver will show up within one hour or scheduled time. Also, please make sure your vehicle is accessible and you took all your belongings out of your vehicle before it gets towed. </p>
                    <p>After a little inspection, Our tow truck driver will pay you cash on spot and pick up your scrap vehicle for free without any hidden cost or charges. We recycle every single part of your wrecked damage scrap cars, unwanted trucks trailers and junk vans effectively with fully Eco-friendly recycling process as per Ministry of Environment compliance. Please make sure you got a bill of sale as a proof of transaction. We believe that good and long-term relationship with customers is key to success thats why we make sure to deliver friendly and on-time services.</p>
                    <ul>
                        <li>Top cash prices for your Scrap Car GUARANTEED</li>
                        <li>Free Towing on every scrap car removal </li>
                        <li>No Hidden Charges</li>
                        <li>Fully Customer Satisfaction</li>
                        <li>Licensed and Eco-friendly organization.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>


    <!---Content Section 5---------->
    <div class="container-fluid Section-1-bg">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-justify">
                    <h2 class="text-center">Features</h2>
                    <p>Looking for Scrap Car Removal in Mississauga? Easy Scrap Car Removal Mississauga has answer of all your questions regarding Junk car removal, car scrapping services in Mississauga and surrounding areas all over GTA.</p>
                    <p> If you have a Scrap car or any type of unwanted vehicle sitting in your driveway occupying space and that needs to be removed from your property, we are just a phone call away. Easy Scrap Car Removal will ask you some basic brief questions about your scrap car and will quote you the best value for your junk vehicle.</p>
                    <p>Easy scrap car removal pick any junk on wheels whether the scrap is</p>
                    <ul>
                        <li>Damaged beyond repair</li>
                        <li>Not running or completely written off</li>
                        <li>Junk vehicles without keys</li>
                        <li>Scrap vehicles fire or water damaged</li>
                        <li>Scrap cars from collision centers</li>
                        <li>Scrap cars from impound lots</li>
                        <li>Scrap cars from police stations</li>
                    </ul>
                    <p>Easy scrap car removal is fully licensed Scrap Car Buyer Company in Mississauga and have very professional tow truck drivers team, fully trained to deal different situations and are fully equipped to remove the junk cars in safe manner. Call or text us at 647 484 6996 and Let us handle the stress of your junk car removal.</p>
                    <p> Easy Scrap Car Removal Mississauga accepts all kind of Sedan cars, Coupe cars, Hatchbacks, Minivans, Cargo van, Extended vans, SUVs, Passenger and Commercial Trucks, Trailers, Cube vans, RVs, Boats or any other kind of junk vehicles for top cash.We are the one of the best Scrap Car Removal Services in Mississauga dealing with very well reputed, Junk yard/Scrap yard/ Scrap metal recycling yard in Mississauga, Ontario. Where all of our vehicles are being disposed off in an ECO-Friendly way.</p>
                    <p>We offer the value of Scrap cars, Unwanted cars, Junk cars, Irreparable vehicles, Major or minor damaged, Unwanted vehicles depending on Make, Model, year and Curb Weight of vehicle.No one makes the process hassle-free better than us. Our approach is very simple. When it comes to value of your Junk Car WE PAY WHAT WE SAY.</p>
                    <p>EASY SCRAP CAR REMOVAL provides one hour pick up service OF Junk cars in Mississauga area. We pay you cash on spot and free towing for Junk Cars which makes us quick, resourceful, well-organized and competent in the Mississauga.We are serving city of Mississauga and its Neighborhoods like Apple wood, Central Erin Mills, Churchill Meadows/Erin Mills, Credit Valley, Clarkson/Lorne Park, Cooksville, East Credit, Erin dale, Fairview, Hurontario area, Lakeview area, Lisgar community, Malton and airport area, Meadowvale, Meadowvale Village, Mineola, Mississauga Valleys, Port Credit, Rathwood, Sheridan, Streetsville etc</p>
                    <p>We buy all kind of Scrap Cars, Scrap Trucks, Scrap Vans (cargo or cube) light Suvs or Full size SUvs of all Makes and Models. Acura, Audi, Bentley, BMW, Buick, Cadillac, Chevrolet, Chrysler, Citroen, Dodge, Fiat, Ford, GMC, Honda, Hyundai, Infiniti, Jaguar, Jeep, Kia, Land Rover, Lexus, Mazda, Mercedes-Benz, Mini, Mitsubishi, Nissan, Porsche, Ram, Saab, Subaru, Suzuki, Tesla, Toyota, Volkswagen, Volvo and any other make and models you may want to get rid of.</p>
                </div>
            </div>
        </div>
    </div>