<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class UserModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->Table = 'usertable';
        $this->Primary_Key = "$this->Table.pkuserid";
    }
	public function userlogin($email,$password,$role)
	{
		$this->db->where("$this->Table.email",$email);
		$this->db->where("$this->Table.password",$password);
		$this->db->where("$this->Table.role",$role);
		return $this->db->get($this->Table)->row();
	}
	public function isPassword($email,$password)
	{
		$this->db->where("$this->Table.email",$email);
		$this->db->where("$this->Table.password",$password);
		return $this->db->get($this->Table)->row();
	}
    function delete($id)
    {
       $this->db->where('pkuserid', $id);
       $this->db->delete("$this->Table"); 
        return true;
    }
	public function update($data,$pkid)
    {
        $this->db->where("$this->Table.pkuserid",$pkid);
        $this->db->update("$this->Table", $data);
        return true;
    }
    
	public function updatepass($data,$email)
    {
        $this->db->where("$this->Table.email",$email);
        $this->db->update("$this->Table", $data);
        return true;
    }
    public function checkemail($email){
        
        $this->db->where("$this->Table.email", $email);
		return $this->db->get($this->Table)->row();
    }
	public function getwhere($id)
	{
        $this->db->where("$this->Table.pkuserid", $id);
		return $this->db->get($this->Table)->row();
	}
    
	public function getAllData()
	{
		$this->db->select("*");
        $this->db->where('role !=', 'admin');
		$this->db->from($this->Table);
        return $this->db->get()->result();
	}
    
   public function insert($data){
        return $this->db->insert("$this->Table", $data);
	}
}