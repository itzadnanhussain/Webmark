<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class DataModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
        $this->Table = 'datatable';
        $this->Primary_Key = "$this->Table.pkdataid";
    }
    
    function delete($id)
    {
       $this->db->where('pkuserid', $id);
       $this->db->delete("$this->Table"); 
        return true;
    }
    
    public  function search($accountid,$searchstring,$rowno,$rowperpage){
		$this->db->select("*, DATE_FORMAT(date, '%d-%m-%Y') as f_date");
        $searcharray=explode("&", $searchstring);
        $this->db->where('accountid', $accountid);
        $this->db->from($this->Table);
        
        foreach($searcharray as $key){
            $searchvalue=explode('=',$key);
            if($searchvalue[1]!=""){
                $this->db->where("$searchvalue[0]", $searchvalue[1]);
            }
            
        }
        $this->db->order_by("date desc,time desc");
        $this->db->limit($rowperpage, $rowno);
        return $this->db->get()->result();
    }
    
    
    public  function searchRows($accountid,$searchstring){
        $this->db->select('count(*) as allcount'); 
        $this->db->where('accountid', $accountid);
        $searcharray=explode("&", $searchstring);
        $this->db->from($this->Table);
        
        foreach($searcharray as $key){
            $searchvalue=explode('=',$key);
            if($searchvalue[1]!=""){
                $this->db->where("$searchvalue[0]", $searchvalue[1]);
            }
        }
       $query = $this->db->get();      
       $result = $query->result_array();            
       return $result[0]['allcount']; 
    }
    
	public function update($data,$pkid)
    {
        $this->db->where("$this->Table.pkuserid",$pkid);
        $this->db->update("$this->Table", $data);
        return true;
    }
    
	public function getwhere($id)
	{
        $this->db->where("$this->Table.pkdataid", $id);
		return $this->db->get($this->Table)->row();
	}
    
	public function getAllData($accountid,$rowno,$rowperpage)
	{
		$this->db->select("*, DATE_FORMAT(date, '%d-%m-%Y') as f_date");
        $this->db->where('accountid', $accountid);
		$this->db->from($this->Table);
        $this->db->order_by("date desc,time desc");
        $this->db->limit($rowperpage, $rowno);
        return $this->db->get()->result();
	}
    
    //for bulk download
	public function getBulkData($accountid,$querystring)
	{
		$this->db->select("*, DATE_FORMAT(date, '%d-%m-%Y') as f_date");
        $queryarray=explode("_",$querystring);
        $this->db->where('accountid', $accountid);
        if(strlen($queryarray[0])>0){
            $this->db->where('date', $queryarray[0]);
        }
        if(strlen($queryarray[1])>0){
        $this->db->where('Destination', $queryarray[1]);
        }
        if(strlen($queryarray[2])>0){
        $this->db->where('deviceid', $queryarray[2]);
        }
		$this->db->from($this->Table);
        return $this->db->get()->result();
	}
    
    //for selected bundle downloads
    public function getData($pkdataidstr)
	{
        $pkdataids = explode(',', $pkdataidstr);
		$this->db->select("*, DATE_FORMAT(date, '%d-%m-%Y') as f_date,TIME_FORMAT(time, '%H:%i') as f_time");
        $this->db->where_in("$this->Table.pkdataid", $pkdataids);
		$this->db->from($this->Table);
        return $this->db->get()->result();
	}
    
   public function insert($data){
        return $this->db->insert("$this->Table", $data);
	}
    
    public function getrecordCount($accountid) {
       $this->db->select('count(*) as allcount');      
       $this->db->from("$this->Table"); 
       $this->db->where('accountid', $accountid);
       $query = $this->db->get();      
       $result = $query->result_array();            
       return $result[0]['allcount'];    
     }
}