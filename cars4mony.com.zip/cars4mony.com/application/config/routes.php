<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'User';
$route["user/page/(:any)"]='user/index/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

///******************Blogs Routes************** */
$route['blogs/main_page']='Blog';
$route['blogs/sell-you-scrap-car-in-mississauga']='Blog/post_1';
$route['blogs/scrap-car-removal-in-mississauga']='Blog/post_2';
$route['blogs/cash-for-scrap-cars-in-mississauga']='Blog/post_3';

