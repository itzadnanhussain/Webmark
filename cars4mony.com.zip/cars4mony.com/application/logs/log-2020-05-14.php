<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-14 00:53:55 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-14 00:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
