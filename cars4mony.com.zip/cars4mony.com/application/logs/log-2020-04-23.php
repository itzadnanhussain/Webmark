<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-23 13:28:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-23 13:40:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-23 13:40:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-23 13:40:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-23 13:40:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-23 13:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-23 13:40:48 --> 404 Page Not Found: Assets/js
