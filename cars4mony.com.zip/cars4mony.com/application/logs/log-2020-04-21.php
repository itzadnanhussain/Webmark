<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-21 04:27:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-21 04:38:01 --> Severity: Warning --> mkdir(): Permission denied /home/moitwjsn/cdr.moitele.com/application/controllers/User.php 82
ERROR - 2020-04-21 04:38:01 --> Severity: Warning --> file_put_contents(/cdr.moitele.com/downloads1587458281/Muhammad_1776_2147483647_21-04-2020_12-03 AM_1.mp3): failed to open stream: No such file or directory /home/moitwjsn/cdr.moitele.com/application/controllers/User.php 109
ERROR - 2020-04-21 04:38:02 --> Severity: Warning --> file_put_contents(/cdr.moitele.com/downloads1587458281/Muhammad_1951_2147483647_21-04-2020_12-10 AM_2.mp3): failed to open stream: No such file or directory /home/moitwjsn/cdr.moitele.com/application/controllers/User.php 109




ERROR - 2020-04-21 04:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 04:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 04:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 04:44:07 --> 404 Page Not Found: Assets/js




ERROR - 2020-04-21 11:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 11:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 11:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 11:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:25:55 --> Severity: error --> Exception: Call to undefined function randomPassword() /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 86
ERROR - 2020-04-21 12:26:03 --> Severity: error --> Exception: Call to undefined function randomPassword() /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 86
ERROR - 2020-04-21 12:29:15 --> Severity: error --> Exception: Call to undefined function randomPassword() /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 86
ERROR - 2020-04-21 12:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:29:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:29:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-21 12:30:32 --> Severity: error --> Exception: Call to undefined function randomPassword() /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 86
ERROR - 2020-04-21 12:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:30:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:40:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:40:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-21 12:40:51 --> 404 Page Not Found: Assets/js







