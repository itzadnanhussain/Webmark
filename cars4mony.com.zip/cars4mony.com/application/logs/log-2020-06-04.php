<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 16:27:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 16:27:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 16:27:14 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 16:27:15 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 16:27:15 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 16:27:18 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-04 17:42:28 --> Severity: error --> Exception: Call to undefined method User::generatePages() C:\xampp\htdocs\c4m\application\controllers\User.php 22
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:48 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:49 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:50 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:51 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:52 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:53 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:54 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:55 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:56 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:57 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 174
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 175
ERROR - 2020-06-04 17:42:58 --> Severity: Warning --> preg_replace(): Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\c4m\application\controllers\User.php 176
ERROR - 2020-06-04 17:44:44 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:44:44 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:44:45 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:44:45 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:44:45 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:44:45 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:44:59 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:45:52 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:47:12 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:47:12 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:47:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:47:13 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:47:13 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:47:13 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:47:15 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-04 17:47:15 --> 404 Page Not Found: Scrap-car-removal%20-Bramptonphp/index
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:24 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:48:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:30 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:48:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:48:31 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:48:31 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:48:31 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:48:33 --> 404 Page Not Found: Scrap-car-removal-Bramptonphp/index
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:48:47 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:52:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:52:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:52:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:52:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:52:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:52:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:52:29 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:52:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:52:29 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:52:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:52:29 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:52:29 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:52:29 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:52:31 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:52:39 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:52:41 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:53:26 --> 404 Page Not Found: Pages/index.php
ERROR - 2020-06-04 17:53:34 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:54:42 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:55:06 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:55:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:55:13 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:56:20 --> 404 Page Not Found: User/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:56:51 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:51 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:56:51 --> 404 Page Not Found: User/img
ERROR - 2020-06-04 17:56:51 --> 404 Page Not Found: User/img
ERROR - 2020-06-04 17:56:52 --> 404 Page Not Found: User/img
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:57:09 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:57:09 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:57:09 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:57:09 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 17:57:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:57:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 17:57:56 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 17:57:56 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 17:57:56 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 17:57:59 --> 404 Page Not Found: Pages/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:00:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:00:57 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-04 18:00:57 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-04 18:00:57 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-04 18:00:59 --> 404 Page Not Found: User/scrap-car-removal-Brampton.php
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:11 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:13 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:14 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:14 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:14 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:15 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:16 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:17 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:17 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:17 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:17 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:20 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:20 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:23 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:24 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:24 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:24 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:25 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:25 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:25 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:01:26 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:01:27 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:01:27 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:19 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:05:20 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-04 18:07:09 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:07:09 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:07:49 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:07:49 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:07:53 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:09:29 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:09:29 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:09:29 --> 404 Page Not Found: User/images
ERROR - 2020-06-04 18:09:29 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:10:16 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:10:17 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:10:17 --> 404 Page Not Found: User/images
ERROR - 2020-06-04 18:10:26 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:14:21 --> 404 Page Not Found: User/images
ERROR - 2020-06-04 18:14:21 --> 404 Page Not Found: User/page
ERROR - 2020-06-04 18:14:29 --> 404 Page Not Found: User/page
