<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-20 06:05:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:07:08 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS), expecting ')' C:\xampp\htdocs\Api\application\controllers\User.php 57
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:24 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:25 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:07:38 --> Severity: Notice --> Undefined property: stdClass::$pkuserid C:\xampp\htdocs\Api\application\controllers\User.php 58
ERROR - 2020-04-20 06:12:56 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_61132461_2020-04-14_02:14:22.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:12:59 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_61132461_2020-04-14_02:14:39.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:01 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:15:16.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:02 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_61132939_2020-04-14_02:15:53.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:03 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:16:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:04 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_61136937_2020-04-14_02:16:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:05 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:17:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:05 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_61131314_2020-04-14_02:18:24.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:06 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:19:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:07 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:21:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:08 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:22:30.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:09 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:23:17.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:10 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:24:07.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:10 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:32:37.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:11 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:34:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:12 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:36:15.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:14 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:36:43.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:15 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:36:59.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:15 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:38:57.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:16 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:39:49.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:17 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:40:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:18 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:41:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:19 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:42:27.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:19 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_02:43:02.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:20 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:46:19.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:21 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:47:44.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:23 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:49:47.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:24 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:51:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:25 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:52:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:26 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587355975\/447418350492_2147483647_2020-04-14_03:54:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:46 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_61132461_2020-04-14_02:14:22.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:47 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_61132461_2020-04-14_02:14:39.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:47 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:15:16.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_61132939_2020-04-14_02:15:53.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:16:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_61136937_2020-04-14_02:16:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:17:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_61131314_2020-04-14_02:18:24.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:19:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:50 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:21:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:50 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:22:30.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:50 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:23:17.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:51 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:24:07.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:51 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:32:37.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:52 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:34:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:52 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:36:15.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:52 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:36:43.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:53 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:36:59.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:54 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:38:57.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:54 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:39:49.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:55 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:40:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:55 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:41:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:56 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:42:27.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:56 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_02:43:02.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:57 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:46:19.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:57 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:47:44.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:58 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:49:47.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:59 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:51:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:59 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:52:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:13:59 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356026\447418350492_2147483647_2020-04-14_03:54:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81











ERROR - 2020-04-20 06:14:41 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_61132461_2020-04-14_02:14:22.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:42 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_61132461_2020-04-14_02:14:39.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:42 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:15:16.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:42 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_61132939_2020-04-14_02:15:53.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:43 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:16:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:43 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_61136937_2020-04-14_02:16:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:44 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:17:10.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:44 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_61131314_2020-04-14_02:18:24.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:44 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:19:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:44 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:21:33.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:45 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:22:30.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:45 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:23:17.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:45 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:24:07.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:46 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:32:37.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:46 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:34:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:47 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:36:15.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:47 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:36:43.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:47 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:36:59.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:38:57.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:39:49.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:48 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:40:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:41:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:42:27.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:49 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_02:43:02.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:50 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:46:19.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:50 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:47:44.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:51 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:49:47.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:51 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:51:06.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:51 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:52:45.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:14:52 --> Severity: Warning --> file_put_contents(C:\xampp\htdocs\Api\downloads1587356081\447418350492_2147483647_2020-04-14_03:54:20.mp3): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 81
ERROR - 2020-04-20 06:23:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:42:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:53:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:53:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:54:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 06:57:19 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\Api\application\controllers\User.php 104
ERROR - 2020-04-20 06:57:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:03:46 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:03:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:109) C:\xampp\htdocs\Api\application\controllers\User.php 111
ERROR - 2020-04-20 07:03:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:96) C:\xampp\htdocs\Api\application\controllers\User.php 111
ERROR - 2020-04-20 07:08:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:16:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:17:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:17:11 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:17:35 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:18:26 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:18:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:20:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:20:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:21:05 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:21:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:21:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:21:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:21:21 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:21:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:21:31 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:28:09 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:28:17 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:28:37 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:31:37 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:31:39 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:31:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:32:23 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:32:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:32:59 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:33:00 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:33:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:33:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 07:38:54 --> Severity: error --> Exception: syntax error, unexpected 'array' (T_ARRAY) C:\xampp\htdocs\Api\application\controllers\User.php 54
ERROR - 2020-04-20 07:39:24 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:39:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:46:58 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:46:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:47:44 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:47:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:48:00 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:48:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:50:54 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\Api\application\models\DataModel.php 69
ERROR - 2020-04-20 07:51:24 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:51:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 07:52:44 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:52:46 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:52:46 --> 404 Page Not Found: Assets/images








ERROR - 2020-04-20 07:54:25 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:54:28 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 07:54:28 --> 404 Page Not Found: Assets/images


ERROR - 2020-04-20 07:54:55 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 111
ERROR - 2020-04-20 08:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 08:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 08:06:04 --> Severity: Notice --> Undefined variable: rowno C:\xampp\htdocs\Api\application\controllers\User.php 190
ERROR - 2020-04-20 08:06:04 --> Severity: Notice --> Undefined variable: rowno C:\xampp\htdocs\Api\application\controllers\User.php 194







ERROR - 2020-04-20 08:15:32 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-20 08:15:38 --> 404 Page Not Found: Assets/images




ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Api\application\controllers\User.php 113
ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Trying to get property 'time' of non-object C:\xampp\htdocs\Api\application\controllers\User.php 113
ERROR - 2020-04-20 08:20:30 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\Api\application\controllers\User.php 113
ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Undefined property: stdClass::$source C:\xampp\htdocs\Api\application\controllers\User.php 114
ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Undefined property: stdClass::$destination C:\xampp\htdocs\Api\application\controllers\User.php 114
ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\Api\application\controllers\User.php 114
ERROR - 2020-04-20 08:20:30 --> Severity: Notice --> Undefined property: stdClass::$url C:\xampp\htdocs\Api\application\controllers\User.php 115





ERROR - 2020-04-20 08:32:17 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_driver as array C:\xampp\htdocs\Api\application\models\DataModel.php 109
ERROR - 2020-04-20 08:35:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:65) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-20 08:35:10 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 91
ERROR - 2020-04-20 08:38:23 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 91
ERROR - 2020-04-20 08:44:47 --> Severity: Error --> Maximum execution time of 300 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 94
ERROR - 2020-04-20 09:30:41 --> Severity: Notice --> Undefined variable: bulktime C:\xampp\htdocs\Api\application\views\dashboard.php 25
ERROR - 2020-04-20 09:35:16 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\Api\application\controllers\User.php 60
ERROR - 2020-04-20 10:16:21 --> Severity: error --> Exception: syntax error, unexpected '$xml_url' (T_VARIABLE), expecting ';' or ',' C:\xampp\htdocs\Api\application\controllers\admin.php 164
ERROR - 2020-04-20 10:30:58 --> Severity: Notice --> Undefined variable: my_variable C:\xampp\htdocs\Api\application\controllers\admin.php 156
ERROR - 2020-04-20 10:30:58 --> Severity: Warning --> file_put_contents(/tmp/file): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 157
ERROR - 2020-04-20 10:30:58 --> Severity: Warning --> file_get_contents(/tmp/file): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 158
ERROR - 2020-04-20 10:32:04 --> Severity: Warning --> file_put_contents(/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 161
ERROR - 2020-04-20 10:32:04 --> Severity: Warning --> file_get_contents(/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 162
ERROR - 2020-04-20 10:32:54 --> Severity: Warning --> file_put_contents(/assets/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 161
ERROR - 2020-04-20 10:32:54 --> Severity: Warning --> file_get_contents(/assets/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 162
ERROR - 2020-04-20 10:33:12 --> Severity: Warning --> file_put_contents(/assets/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 161
ERROR - 2020-04-20 10:33:12 --> Severity: Warning --> file_get_contents(/assets/tmp/file.txt): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\admin.php 162
ERROR - 2020-04-20 10:42:53 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\admin.php 175
ERROR - 2020-04-20 11:36:51 --> Query error: MySQL server has gone away - Invalid query: INSERT INTO `datatable` (`pkdataid`, `accountid`, `extension`, `date`, `time`, `duration`, `source`, `destination`, `size`, `url`) VALUES ('4241381', '1201', '2681', '2020/04/16', '23:54:08', '01:03', '16624302837', '13184461817', '256608.0', 'http://165.227.128.58/recordings/1587074048.195627.mp3')
ERROR - 2020-04-20 11:47:23 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Api\application\controllers\User.php 120
ERROR - 2020-04-20 11:47:23 --> Severity: Notice --> Trying to get property 'username' of non-object C:\xampp\htdocs\Api\application\controllers\User.php 120
ERROR - 2020-04-20 12:01:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 12:01:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Api\application\controllers\User.php 120
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Trying to get property 'time' of non-object C:\xampp\htdocs\Api\application\controllers\User.php 120
ERROR - 2020-04-20 12:01:37 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\Api\application\controllers\User.php 120
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Undefined property: stdClass::$extension C:\xampp\htdocs\Api\application\controllers\User.php 121
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Undefined property: stdClass::$destination C:\xampp\htdocs\Api\application\controllers\User.php 121
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\Api\application\controllers\User.php 121
ERROR - 2020-04-20 12:01:37 --> Severity: Notice --> Undefined property: stdClass::$url C:\xampp\htdocs\Api\application\controllers\User.php 122
ERROR - 2020-04-20 12:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 12:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 12:28:45 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\Api\application\models\DataModel.php 98
ERROR - 2020-04-20 12:28:45 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Api\application\models\DataModel.php 101
ERROR - 2020-04-20 12:28:45 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\Api\application\models\DataModel.php 104
ERROR - 2020-04-20 13:46:22 --> Severity: error --> Exception: syntax error, unexpected '%' C:\xampp\htdocs\Api\application\models\DataModel.php 81
ERROR - 2020-04-20 13:50:43 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\Api\application\models\DataModel.php 99
ERROR - 2020-04-20 13:50:43 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Api\application\models\DataModel.php 102
ERROR - 2020-04-20 13:50:43 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\Api\application\models\DataModel.php 105
ERROR - 2020-04-20 13:51:21 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\Api\application\models\DataModel.php 99
ERROR - 2020-04-20 13:51:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Api\application\models\DataModel.php 102
ERROR - 2020-04-20 13:51:21 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\Api\application\models\DataModel.php 105
ERROR - 2020-04-20 17:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 17:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 17:13:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 17:13:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:08:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:08:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:10:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:10:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:50:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:50:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:50:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 18:50:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:04:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:04:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:05:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:09:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:09:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:18:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:18:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:20:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:20:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:23:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:23:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:37:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:39:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:39:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-20 19:39:59 --> 404 Page Not Found: Assets/js
