<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-24 02:50:20 --> 404 Page Not Found: Api/autocall
ERROR - 2020-04-24 02:50:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-24 11:30:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-24 11:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-24 11:30:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-24 12:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-24 12:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-24 12:23:55 --> 404 Page Not Found: Assets/js
