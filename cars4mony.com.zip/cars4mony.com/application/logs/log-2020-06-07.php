<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-07 19:12:39 --> Severity: Warning --> Use of undefined constant base_url - assumed 'base_url' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\c4m\application\views\main.php 44
ERROR - 2020-06-07 19:12:47 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-07 19:19:20 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-07 19:20:23 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-07 19:22:14 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-07 20:05:33 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-07 20:05:49 --> 404 Page Not Found: Img/towtruck.png
