<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-17 08:05:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 08:33:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:04:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:12:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:12:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:12:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:12:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:13:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:14:14 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:14:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:14:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:22:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:22:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:23:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:26:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:34:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:35:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:35:52 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:35:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:36:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:37:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:37:53 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 09:38:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:39:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:40:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 09:50:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 10:04:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 10:10:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 10:44:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 10:45:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 10:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 10:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 10:58:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 10:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 10:59:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:00:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:00:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:02:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:03:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:03:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:03:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:04:10 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:04:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:05:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:05:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:05:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:06:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:11:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:11:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:12:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 11:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 11:12:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:09:16 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:09:23 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:10:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:10:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:10:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:19:08 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:19:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 50
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 50
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 50
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 50
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_exec() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 52
ERROR - 2020-04-17 12:22:22 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\Api\application\controllers\User.php 52
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_close() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 52
ERROR - 2020-04-17 12:22:22 --> Severity: Warning --> curl_close() expects parameter 1 to be resource, null given C:\xampp\htdocs\Api\application\controllers\User.php 52
ERROR - 2020-04-17 12:22:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:28:08 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\Api\application\controllers\User.php 48
ERROR - 2020-04-17 12:28:08 --> Severity: Warning --> file_get_contents(https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\Api\application\controllers\User.php 48
ERROR - 2020-04-17 12:30:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:40:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:54:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:54:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:54:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:54:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:55:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:55:18 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:55:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:55:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 12:56:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 12:56:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:00:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:01:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:01:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:01:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:01:31 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:01:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:01:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:01:50 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:02:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:02:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:02:36 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:04:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:05:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:05:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:07:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:08:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:08:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:08:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 13:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 13:11:01 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:29:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:30:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 16:30:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 16:32:08 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:33:42 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:34:11 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:40:02 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 16:42:22 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 18:44:12 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 19:14:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-17 19:22:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 19:22:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-17 19:22:39 --> 404 Page Not Found: Assets/images
