<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-05 05:13:20 --> 404 Page Not Found: User/images
ERROR - 2020-06-05 05:13:20 --> 404 Page Not Found: User/page
ERROR - 2020-06-05 05:13:22 --> 404 Page Not Found: User/page
ERROR - 2020-06-05 05:19:40 --> 404 Page Not Found: User/images
ERROR - 2020-06-05 05:19:40 --> 404 Page Not Found: User/page
ERROR - 2020-06-05 05:19:40 --> 404 Page Not Found: User/images
ERROR - 2020-06-05 18:10:06 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-05 18:10:17 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-05 18:11:21 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-05 18:11:55 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-05 18:12:32 --> Severity: Warning --> Use of undefined constant base_url - assumed 'base_url' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\c4m\application\views\main.php 44
ERROR - 2020-06-05 18:12:35 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-05 18:22:08 --> 404 Page Not Found: User/images
ERROR - 2020-06-05 18:22:08 --> 404 Page Not Found: User/images
ERROR - 2020-06-05 18:22:08 --> 404 Page Not Found: User/images
