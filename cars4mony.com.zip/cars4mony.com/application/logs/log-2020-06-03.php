<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:10:02 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:10:03 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-03 17:10:03 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-03 17:10:03 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-03 17:10:04 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-03 17:32:38 --> 404 Page Not Found: Servicesphp/index
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:32:41 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:38:50 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:38:50 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-03 17:38:50 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-03 17:38:50 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-03 17:38:54 --> 404 Page Not Found: Servicesphp/index
ERROR - 2020-06-03 17:38:55 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:38:55 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:38:56 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:54:33 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-03 17:54:36 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-03 17:54:37 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-03 17:54:37 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-03 17:54:38 --> 404 Page Not Found: Img/towtruck.png
