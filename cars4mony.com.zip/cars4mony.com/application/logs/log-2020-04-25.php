<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-25 22:50:32 --> Severity: Warning --> DOMDocument::loadXML(): Empty string supplied as input /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 202
