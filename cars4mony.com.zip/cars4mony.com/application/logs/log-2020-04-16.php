<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-16 05:48:05 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 06:13:36 --> 404 Page Not Found: /index
ERROR - 2020-04-16 06:13:40 --> 404 Page Not Found: /index
ERROR - 2020-04-16 06:14:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 06:15:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 06:19:58 --> 404 Page Not Found: Users/dashboard
ERROR - 2020-04-16 06:20:27 --> Severity: error --> Exception: Call to undefined method User::checkUser() C:\xampp\htdocs\Api\application\controllers\User.php 45
ERROR - 2020-04-16 06:21:19 --> Severity: error --> Exception: Unable to locate the model you have specified: DataModel C:\xampp\htdocs\Api\system\core\Loader.php 348
ERROR - 2020-04-16 06:24:07 --> Severity: Notice --> Undefined property: User::$UserModel C:\xampp\htdocs\Api\application\controllers\User.php 47
ERROR - 2020-04-16 06:24:07 --> Severity: error --> Exception: Call to a member function getAllData() on null C:\xampp\htdocs\Api\application\controllers\User.php 47
ERROR - 2020-04-16 06:24:25 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT *
FROM `datatable`
WHERE `role` != 'admin'
ERROR - 2020-04-16 06:46:16 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT *
FROM `datatable`
WHERE `role` != 'admin'
ERROR - 2020-04-16 06:46:17 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT *
FROM `datatable`
WHERE `role` != 'admin'
ERROR - 2020-04-16 06:48:40 --> Severity: error --> Exception: Too few arguments to function DataModel::getAllData(), 0 passed in C:\xampp\htdocs\Api\application\controllers\User.php on line 47 and exactly 1 expected C:\xampp\htdocs\Api\application\models\DataModel.php 30
ERROR - 2020-04-16 06:56:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-16 06:57:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-16 06:57:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-16 06:57:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Api\application\controllers\User.php 49
ERROR - 2020-04-16 07:03:26 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:03:26 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:03:26 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:12:14 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:12:14 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:12:14 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:13:17 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:13:17 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:13:17 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:14:03 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:14:03 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:14:03 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:17:59 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:17:59 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:17:59 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:00 --> 404 Page Not Found: Users/login
ERROR - 2020-04-16 07:18:18 --> 404 Page Not Found: Users/login
ERROR - 2020-04-16 07:18:30 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:30 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:30 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:45 --> 404 Page Not Found: Users/view
ERROR - 2020-04-16 07:18:50 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:50 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:18:50 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:08 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:08 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:08 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:38 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:38 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:27:38 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:30:49 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:30:49 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:30:49 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:37:39 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:38:21 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:41:06 --> 404 Page Not Found: User/horse.mp3
ERROR - 2020-04-16 07:47:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 08:08:12 --> 404 Page Not Found: User/editprofile
ERROR - 2020-04-16 08:10:12 --> 404 Page Not Found: User/userprofile
ERROR - 2020-04-16 08:10:24 --> 404 Page Not Found: Userprofile/14
ERROR - 2020-04-16 08:11:48 --> 404 Page Not Found: Userprofile/14
ERROR - 2020-04-16 08:11:51 --> 404 Page Not Found: Userprofile/14
ERROR - 2020-04-16 08:19:16 --> Severity: error --> Exception: Too few arguments to function Admin::edituser(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\admin.php 152
ERROR - 2020-04-16 08:19:31 --> 404 Page Not Found: Admin/editprofile
ERROR - 2020-04-16 08:26:56 --> Severity: error --> Exception: Too few arguments to function Admin::edituseraction(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\admin.php 159
ERROR - 2020-04-16 08:26:58 --> Severity: error --> Exception: Too few arguments to function Admin::edituseraction(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\admin.php 159
ERROR - 2020-04-16 08:27:17 --> Severity: error --> Exception: Too few arguments to function Admin::edituseraction(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\admin.php 159
ERROR - 2020-04-16 08:27:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:27:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:27:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:27:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:50:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 08:54:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:55:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 08:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 09:00:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 10:48:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 10:48:55 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 10:49:51 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 10:51:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 10:59:43 --> Severity: error --> Exception: Too few arguments to function User::search(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\User.php 63
ERROR - 2020-04-16 11:00:43 --> Severity: error --> Exception: Too few arguments to function User::search(), 0 passed in C:\xampp\htdocs\Api\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\Api\application\controllers\User.php 63
ERROR - 2020-04-16 11:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 11:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 11:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:13:59 --> 404 Page Not Found: User/admin
ERROR - 2020-04-16 12:25:50 --> Severity: Warning --> Use of undefined constant searchvalue - assumed 'searchvalue' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\Api\application\views\dashboard.php 126
ERROR - 2020-04-16 12:25:55 --> Severity: Warning --> Use of undefined constant searchvalue - assumed 'searchvalue' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\Api\application\views\dashboard.php 126
ERROR - 2020-04-16 12:26:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:26:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:27:08 --> Severity: Warning --> Use of undefined constant searchvalue - assumed 'searchvalue' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\Api\application\views\dashboard.php 126
ERROR - 2020-04-16 12:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:37:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:38:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\Api\application\views\dashboard.php 127
ERROR - 2020-04-16 12:38:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\Api\application\views\dashboard.php 127
ERROR - 2020-04-16 12:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:49:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 12:51:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 17:49:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:23:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:33:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:33:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:34:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:36:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:37:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:38:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:39:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:40:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:46:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:52:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:52:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:52:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:52:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:53:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:53:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:54:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:54:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:56:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:56:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:56:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 18:57:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:59:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:59:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 18:59:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 19:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 19:03:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 19:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 19:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-16 19:04:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-16 19:04:37 --> 404 Page Not Found: Assets/js
