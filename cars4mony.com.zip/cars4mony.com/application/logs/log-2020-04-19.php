<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-19 05:17:40 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 05:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:24:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:24:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 05:25:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:05:43 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:44:29 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:44:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:44:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:45:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:45:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:48:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:48:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:48:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:48:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:48:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:48:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:50:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:50:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:50:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 06:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 06:57:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:27:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:27:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:28:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:29:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:29:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 07:29:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:48:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:49:27 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:51:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:54:20 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:55:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:56:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:57:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:57:30 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:59:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 07:59:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 08:00:06 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 08:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:00:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:00:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:00:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 08:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 08:04:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 08:06:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 08:24:31 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\Api\application\views\dashboard.php 109
ERROR - 2020-04-19 09:13:03 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 09:16:39 --> Severity: error --> Exception: Class 'EvTimer' not found C:\xampp\htdocs\Api\application\controllers\admin.php 14
ERROR - 2020-04-19 09:43:09 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 09:51:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 09:52:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 09:52:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 10:43:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 10:43:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 10:51:09 --> Severity: Notice --> curl_setopt(): CURLOPT_SSL_VERIFYHOST no longer accepts the value 1, value 2 will be used instead C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-19 10:52:10 --> Severity: Notice --> curl_setopt(): CURLOPT_SSL_VERIFYHOST no longer accepts the value 1, value 2 will be used instead C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-19 10:52:10 --> Severity: Notice --> curl_setopt(): CURLOPT_SSL_VERIFYHOST no longer accepts the value 1, value 2 will be used instead C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-19 10:52:45 --> Severity: Notice --> curl_setopt(): CURLOPT_SSL_VERIFYHOST no longer accepts the value 1, value 2 will be used instead C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-19 10:52:45 --> Severity: Notice --> curl_setopt(): CURLOPT_SSL_VERIFYHOST no longer accepts the value 1, value 2 will be used instead C:\xampp\htdocs\Api\application\controllers\User.php 51
ERROR - 2020-04-19 11:20:29 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 11:20:29 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:20:29 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:21:13 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 11:21:13 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:21:13 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:22:55 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 11:22:55 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:22:55 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:25:49 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:25:49 --> 404 Page Not Found: User/adcs.zip
ERROR - 2020-04-19 11:26:20 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:26:20 --> 404 Page Not Found: Assets/downloads1587288380
ERROR - 2020-04-19 11:26:20 --> 404 Page Not Found: Assets/downloads1587288380
ERROR - 2020-04-19 11:28:19 --> Severity: Warning --> opendir(C:\xampp\htdocs\Apiassets/downloads1587288498/adcs.zip,C:\xampp\htdocs\Apiassets/downloads1587288498/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:28:19 --> Severity: Warning --> opendir(C:\xampp\htdocs\Apiassets/downloads1587288498/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:28:19 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\Apiassets/downloads1587288498/adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:28:19 --> 404 Page Not Found: Assets/downloads1587288498
ERROR - 2020-04-19 11:28:19 --> 404 Page Not Found: Assets/downloads1587288498
ERROR - 2020-04-19 11:29:11 --> Severity: Warning --> opendir(C:\xampp\htdocs\Apiassets/downloads1587288551/adcs.zip,C:\xampp\htdocs\Apiassets/downloads1587288551/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:29:11 --> Severity: Warning --> opendir(C:\xampp\htdocs\Apiassets/downloads1587288551/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:29:41 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api/assets/downloads1587288580/adcs.zip,C:\xampp\htdocs\Api/assets/downloads1587288580/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:29:41 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api/assets/downloads1587288580/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:29:57 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288596/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288596/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:29:57 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288596/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:30:27 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288627/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288627/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:30:27 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288627/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:44 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288884/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288884/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:44 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288884/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:46 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288885/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288885/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:46 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288885/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:48 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288887/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288887/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:34:48 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288887/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 71
ERROR - 2020-04-19 11:36:23 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288983/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587288983/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 73
ERROR - 2020-04-19 11:36:23 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587288983/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 73
ERROR - 2020-04-19 11:41:59 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587289319/adcs.zip,C:\xampp\htdocs\Api\assets\downloads1587289319/adcs.zip): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\Api\application\controllers\User.php 72
ERROR - 2020-04-19 11:41:59 --> Severity: Warning --> opendir(C:\xampp\htdocs\Api\assets\downloads1587289319/adcs.zip): failed to open dir: No error C:\xampp\htdocs\Api\application\controllers\User.php 72
ERROR - 2020-04-19 11:48:06 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\Api\assets\downloads1587289685/adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:48:06 --> 404 Page Not Found: Assets/downloads1587289685
ERROR - 2020-04-19 11:48:06 --> 404 Page Not Found: Assets/downloads1587289685
ERROR - 2020-04-19 11:48:23 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\Api\assets\downloads1587289703/adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:48:23 --> 404 Page Not Found: Assets/downloads1587289703
ERROR - 2020-04-19 11:48:23 --> 404 Page Not Found: Assets/downloads1587289703
ERROR - 2020-04-19 11:51:14 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\Api\assets\downloads1587289874/adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:51:15 --> 404 Page Not Found: Assets/downloads1587289874
ERROR - 2020-04-19 11:51:15 --> 404 Page Not Found: Assets/downloads1587289874
ERROR - 2020-04-19 11:51:54 --> Severity: Warning --> filesize(): stat failed for C:\xampp\htdocs\Api\assets\downloads1587289913/adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 11:51:54 --> 404 Page Not Found: Assets/downloads1587289913
ERROR - 2020-04-19 11:51:54 --> 404 Page Not Found: Assets/downloads1587289913
ERROR - 2020-04-19 11:51:54 --> 404 Page Not Found: Assets/downloads1587289913









ERROR - 2020-04-19 11:59:55 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 11:59:56 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 12:02:55 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:02:55 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 12:02:59 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:02:59 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 12:03:18 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:03:18 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 12:03:22 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:03:22 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 88
ERROR - 2020-04-19 12:04:50 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:04:50 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 12:04:50 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 89
ERROR - 2020-04-19 12:05:00 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:05:00 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 12:05:00 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 89
ERROR - 2020-04-19 12:05:02 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 82
ERROR - 2020-04-19 12:05:02 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 12:05:02 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 89
ERROR - 2020-04-19 12:08:44 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 12:08:44 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 84
ERROR - 2020-04-19 12:08:44 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 12:08:51 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 12:08:51 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 84
ERROR - 2020-04-19 12:08:51 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 12:09:38 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 12:09:38 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 76
ERROR - 2020-04-19 12:09:38 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 12:09:38 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 12:09:40 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 12:09:40 --> Severity: Warning --> ZipArchive::close(): Read error: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 76
ERROR - 2020-04-19 12:09:40 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 12:09:40 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 12:10:38 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 12:10:41 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 12:10:42 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:43:09 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:43:11 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:46:54 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:47:00 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:47:01 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:49:47 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:49:47 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 16:49:47 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 16:50:49 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:50:49 --> Severity: Warning --> filesize(): stat failed for adcs.zip C:\xampp\htdocs\Api\application\controllers\User.php 80
ERROR - 2020-04-19 16:50:49 --> Severity: Warning --> readfile(adcs.zip): failed to open stream: No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 83
ERROR - 2020-04-19 16:57:53 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:57:56 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 16:57:57 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 17:12:13 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 17:12:18 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 17:13:07 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 17:13:10 --> Severity: Notice --> Undefined variable: entry C:\xampp\htdocs\Api\application\controllers\User.php 74
ERROR - 2020-04-19 17:31:21 --> Severity: Warning --> unlink(downloads1587310280): Is a directory C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 17:32:18 --> Severity: Warning --> rmdir(downloads1587310337): Directory not empty C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 17:32:19 --> Severity: Warning --> rmdir(downloads1587310338): Directory not empty C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 17:33:25 --> Severity: Warning --> rmdir(downloads1587310404): Directory not empty C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 17:33:26 --> Severity: Warning --> rmdir(downloads1587310405): Directory not empty C:\xampp\htdocs\Api\application\controllers\User.php 87
ERROR - 2020-04-19 17:39:07 --> Severity: error --> Exception: syntax error, unexpected 'publich' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\Api\application\controllers\User.php 90











ERROR - 2020-04-19 17:40:50 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:40:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:40:51 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:40:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:41:21 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:41:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:42:30 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:42:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:45:28 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:45:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:46:42 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:46:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570









ERROR - 2020-04-19 17:48:25 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:48:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570








ERROR - 2020-04-19 17:49:34 --> Severity: error --> Exception: Call to undefined function removeDir() C:\xampp\htdocs\Api\application\controllers\User.php 86
ERROR - 2020-04-19 17:49:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\Api\application\controllers\User.php:83) C:\xampp\htdocs\Api\system\core\Common.php 570
ERROR - 2020-04-19 17:50:30 --> Severity: Notice --> Undefined variable: foldername C:\xampp\htdocs\Api\application\controllers\User.php 95
ERROR - 2020-04-19 17:50:30 --> Severity: Warning --> rmdir(/): Permission denied C:\xampp\htdocs\Api\application\controllers\User.php 95




ERROR - 2020-04-19 17:52:19 --> Severity: Warning --> rmdir(/downloads1587311538): No such file or directory C:\xampp\htdocs\Api\application\controllers\User.php 95







ERROR - 2020-04-19 18:14:47 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:17:13 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:17:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:17:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:19 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:18:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:18:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:19:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:27:37 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:35 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:30:49 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:33:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:33:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:34:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:34:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:34:48 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:35:21 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:35:33 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:35:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:36:04 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:36:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:37:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:37:24 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:37:38 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:37:59 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 18:38:41 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:39:07 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:40:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:40:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 18:43:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:08:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:08:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:08:16 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:08:39 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:23:56 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:24:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:24:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:24:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:25:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:25:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:25:25 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:26:28 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:26:44 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:32:45 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:32:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:32:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:33:54 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:34:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:36:34 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:38:26 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:56:23 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 19:56:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:56:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-19 19:57:17 --> 404 Page Not Found: Assets/images
ERROR - 2020-04-19 20:00:03 --> 404 Page Not Found: Assets/images
