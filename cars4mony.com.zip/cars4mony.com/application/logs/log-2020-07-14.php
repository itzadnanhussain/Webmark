<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 03:47:18 --> 404 Page Not Found: Admin/index
ERROR - 2020-07-14 11:18:37 --> 404 Page Not Found: Admin/index
