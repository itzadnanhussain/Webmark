<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-22 04:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-22 04:59:38 --> 404 Page Not Found: Robotstxt/index
