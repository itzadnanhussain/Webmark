<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 09:49:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'moitwjsn_datafetcher'@'localhost' (using password: YES) C:\xampp\htdocs\se\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-05-13 09:49:39 --> Unable to connect to the database
ERROR - 2020-05-13 09:50:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'moitwjsn_datafetcher'@'localhost' (using password: YES) C:\xampp\htdocs\se\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-05-13 09:50:09 --> Unable to connect to the database
ERROR - 2020-05-13 09:50:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'carrier_db'@'localhost' (using password: YES) C:\xampp\htdocs\se\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-05-13 09:50:28 --> Unable to connect to the database
ERROR - 2020-05-13 09:54:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-13 09:54:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-13 09:56:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\se\application\controllers\User.php 245
ERROR - 2020-05-13 09:56:15 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 09:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100



ERROR - 2020-05-13 09:57:05 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\se\application\controllers\User.php 245
ERROR - 2020-05-13 09:57:05 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 09:57:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 09:58:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\se\application\controllers\User.php 245
ERROR - 2020-05-13 09:58:19 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 09:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 09:58:24 --> Severity: error --> Exception: Object of class User could not be converted to string C:\xampp\htdocs\se\application\controllers\User.php 246
ERROR - 2020-05-13 10:00:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\se\application\controllers\User.php 245
ERROR - 2020-05-13 10:00:22 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:00:39 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\se\application\controllers\User.php 245
ERROR - 2020-05-13 10:00:39 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\se\application\views\dashboard.php 58
ERROR - 2020-05-13 10:00:39 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:00:55 --> Severity: error --> Exception: Object of class User could not be converted to string C:\xampp\htdocs\se\application\controllers\User.php 246
ERROR - 2020-05-13 10:01:10 --> Severity: error --> Exception: Object of class User could not be converted to string C:\xampp\htdocs\se\application\controllers\User.php 246
ERROR - 2020-05-13 10:04:14 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\se\application\models\CarrierModel.php 29
ERROR - 2020-05-13 10:04:25 --> Severity: error --> Exception: Object of class User could not be converted to string C:\xampp\htdocs\se\application\controllers\User.php 246
ERROR - 2020-05-13 10:10:08 --> Severity: error --> Exception: syntax error, unexpected '}', expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\se\application\controllers\User.php 249
ERROR - 2020-05-13 10:10:41 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:10:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:06 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:08 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:08 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:09 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:10 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:11 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:12 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:47 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:11:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:12:01 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:12:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:12:08 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:12:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:13:24 --> Severity: Warning --> Use of undefined constant both - assumed 'both' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\se\application\models\CarrierModel.php 25
ERROR - 2020-05-13 10:13:24 --> Severity: Warning --> Use of undefined constant both - assumed 'both' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\se\application\models\CarrierModel.php 25
ERROR - 2020-05-13 10:13:24 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:13:36 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:13:59 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:14:23 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:14:44 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:00 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:02 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:31 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 100
ERROR - 2020-05-13 10:26:52 --> Severity: Warning --> Use of undefined constant distance - assumed 'distance' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\se\application\views\dashboard.php 23
ERROR - 2020-05-13 10:26:52 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 10:26:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 10:27:09 --> Severity: Warning --> Use of undefined constant distance - assumed 'distance' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\se\application\views\dashboard.php 23
ERROR - 2020-05-13 10:27:09 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 10:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:03:38 --> Severity: Warning --> Use of undefined constant distance - assumed 'distance' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\se\application\views\dashboard.php 23
ERROR - 2020-05-13 11:03:38 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:29:54 --> Severity: Notice --> Undefined variable: distance C:\xampp\htdocs\se\application\views\dashboard.php 23
ERROR - 2020-05-13 11:29:54 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:29:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:30:11 --> Severity: error --> Exception: Call to undefined function getDistance() C:\xampp\htdocs\se\application\controllers\User.php 237
ERROR - 2020-05-13 11:30:26 --> Severity: error --> Exception: Call to undefined function getLnt() C:\xampp\htdocs\se\application\controllers\User.php 268
ERROR - 2020-05-13 11:30:46 --> Severity: Warning --> file_get_contents(https://maps.googleapis.com/maps/api/geocode/json?address=
            146-2356&amp;sensor=false&amp;key=AIzaSyCbd55sMkPt6cl70bJ5fb3_6TejuYceHH0): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\se\application\controllers\User.php 259
ERROR - 2020-05-13 11:30:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:30:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:30:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:30:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:30:46 --> Severity: Warning --> file_get_contents(https://maps.googleapis.com/maps/api/geocode/json?address=
            120-2456&amp;sensor=false&amp;key=AIzaSyCbd55sMkPt6cl70bJ5fb3_6TejuYceHH0): failed to open stream: HTTP request failed! HTTP/1.0 400 Bad Request
 C:\xampp\htdocs\se\application\controllers\User.php 259
ERROR - 2020-05-13 11:30:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:30:47 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:31:28 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:31:33 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:31:35 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:31:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:31:37 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:31:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:32:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:32:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:32:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:32:22 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:32:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:32:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:32:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 260
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 269
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:32:47 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:33:34 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:34:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:34:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:34:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:34:39 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:36:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:36:39 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:36:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:39:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:39:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:39:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:39:52 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:41:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:41:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:41:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:41:32 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:41:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:43:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:43:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:43:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:43:11 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:43:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:43:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:43:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:43:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:43:16 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:46:46 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:47:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:47:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:47:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:47:20 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:47:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:51:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:51:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:51:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 270
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 271
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 11:51:02 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:51:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:57:59 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:57:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:58:19 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:58:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:58:54 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:58:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:59:16 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:59:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:59:59 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 11:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:00:14 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:00:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 12:01:56 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:47 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:50 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:53 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:02:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:03:04 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:03:51 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:05:55 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\se\application\controllers\User.php 261
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 262
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 263
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 272
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\se\application\controllers\User.php 273
ERROR - 2020-05-13 12:07:23 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:08:21 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:08:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:09:53 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:09:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:12:53 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:14:43 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\se\application\views\dashboard.php 101
ERROR - 2020-05-13 12:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\se\application\views\dashboard.php 101
