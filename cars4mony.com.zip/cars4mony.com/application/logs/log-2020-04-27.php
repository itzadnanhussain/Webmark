<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-27 05:48:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-27 12:20:28 --> Severity: Warning --> DOMDocument::loadXML(): Empty string supplied as input /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 202
