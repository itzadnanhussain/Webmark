<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-29 00:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-29 00:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2020-04-29 02:23:06 --> Severity: Notice --> Undefined offset: 3 /home/moitwjsn/cdr.moitele.com/application/models/DataModel.php 90
ERROR - 2020-04-29 02:23:06 --> Query error: Unknown column 'extension' in 'where clause' - Invalid query: SELECT *, DATE_FORMAT(date, '%d-%m-%Y') as f_date
FROM `datatable`
WHERE `accountid` = '1201'
AND `extension` IS NULL
ERROR - 2020-04-29 02:24:53 --> Severity: Notice --> Undefined offset: 3 /home/moitwjsn/cdr.moitele.com/application/models/DataModel.php 90
ERROR - 2020-04-29 02:26:51 --> Severity: Notice --> Undefined offset: 3 /home/moitwjsn/cdr.moitele.com/application/models/DataModel.php 90
ERROR - 2020-04-29 04:14:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 04:14:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 04:15:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 04:15:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 04:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-04-29 04:16:45 --> 404 Page Not Found: Assets/js
