<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 17:28:28 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 17:28:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 17:28:29 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 17:28:29 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 17:28:29 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-02 17:28:29 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-02 17:28:29 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-02 17:28:30 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-02 18:03:34 --> Severity: error --> Exception: syntax error, unexpected ')', expecting '[' C:\xampp\htdocs\c4m\application\controllers\User.php 53
ERROR - 2020-06-02 18:05:11 --> Severity: error --> Exception: syntax error, unexpected '$dashquery' (T_VARIABLE), expecting ')' C:\xampp\htdocs\c4m\application\controllers\User.php 56
ERROR - 2020-06-02 18:05:24 --> Severity: error --> Exception: syntax error, unexpected '$dashquery' (T_VARIABLE), expecting ')' C:\xampp\htdocs\c4m\application\controllers\User.php 56
ERROR - 2020-06-02 18:05:52 --> Severity: error --> Exception: syntax error, unexpected '$place' (T_VARIABLE), expecting ')' C:\xampp\htdocs\c4m\application\controllers\User.php 56
ERROR - 2020-06-02 18:06:05 --> Severity: error --> Exception: syntax error, unexpected 'fclose' (T_STRING) C:\xampp\htdocs\c4m\application\controllers\User.php 73
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:06:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:06:27 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-02 18:06:28 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-02 18:06:28 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-02 18:06:29 --> 404 Page Not Found: Servicesphp/index
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:06:31 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:13:00 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-02 18:13:00 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-02 18:13:00 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-02 18:13:00 --> 404 Page Not Found: Img/banner.jpg
