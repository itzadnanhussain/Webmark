<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-26 11:50:23 --> Severity: Warning --> DOMDocument::loadXML(): Empty string supplied as input /home/moitwjsn/cdr.moitele.com/application/controllers/Admin.php 202
