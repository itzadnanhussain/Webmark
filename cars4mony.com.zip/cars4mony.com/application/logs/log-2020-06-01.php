<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-01 17:38:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'carrier_db' C:\xampp\htdocs\c4m\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-06-01 17:38:31 --> Unable to connect to the database
ERROR - 2020-06-01 17:39:00 --> Severity: Notice --> Undefined variable: distance C:\xampp\htdocs\c4m\application\views\main.php 31
ERROR - 2020-06-01 17:39:00 --> Severity: Notice --> Undefined variable: carrierdata C:\xampp\htdocs\c4m\application\views\main.php 47
ERROR - 2020-06-01 17:39:00 --> Severity: Notice --> Undefined variable: carrierdata C:\xampp\htdocs\c4m\application\views\main.php 47
ERROR - 2020-06-01 17:39:00 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\c4m\application\views\main.php 101
ERROR - 2020-06-01 17:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\c4m\application\views\main.php 101
ERROR - 2020-06-01 18:22:25 --> Severity: Notice --> Undefined variable: distance C:\xampp\htdocs\c4m\application\views\main.php 31
ERROR - 2020-06-01 18:22:25 --> Severity: Notice --> Undefined variable: carrierdata C:\xampp\htdocs\c4m\application\views\main.php 47
ERROR - 2020-06-01 18:22:25 --> Severity: Notice --> Undefined variable: carrierdata C:\xampp\htdocs\c4m\application\views\main.php 47
ERROR - 2020-06-01 18:22:25 --> Severity: Notice --> Undefined variable: usersdata C:\xampp\htdocs\c4m\application\views\main.php 101
ERROR - 2020-06-01 18:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\c4m\application\views\main.php 101
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/analytics.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/analytics.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/load_css.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/load_css.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/home-banner.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\main.php 2
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/home-banner.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\main.php 2
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\footer.php 2
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\footer.php 2
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(php/load_js.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\footer.php 3
ERROR - 2020-06-01 18:28:06 --> Severity: Warning --> include(): Failed opening 'php/load_js.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\footer.php 3
ERROR - 2020-06-01 18:28:06 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:39:48 --> Severity: Warning --> include(php/analytics.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:39:49 --> Severity: Warning --> include(): Failed opening 'php/analytics.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:39:49 --> Severity: Warning --> include(php/load_css.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:39:49 --> Severity: Warning --> include(): Failed opening 'php/load_css.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:39:49 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:39:49 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(template/analytics.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(): Failed opening 'template/analytics.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(template/load_css.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(): Failed opening 'template/load_css.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(template/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:40:44 --> Severity: Warning --> include(): Failed opening 'template/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:40:58 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 32768 bytes) C:\xampp\htdocs\c4m\application\views\template\footer.php 1
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(template/analytics.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(): Failed opening 'template/analytics.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 13
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(template/load_css.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(): Failed opening 'template/load_css.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 14
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(template/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(): Failed opening 'template/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:43:21 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(): Failed opening 'js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:43:22 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:43:22 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/style.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/style.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/nav.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/nav.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/home-banner.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/home-banner.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/form.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/form.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/footer.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/footer.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/Home.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/Home.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:44:50 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(css/animate.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'css/animate.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(template/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'template/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\head.php 18
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:44:51 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:44:52 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:44:53 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/style.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/style.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/nav.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/nav.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/home-banner.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/home-banner.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/form.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/form.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/footer.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/footer.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/Home.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/Home.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(css/animate.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(): Failed opening 'css/animate.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:45:14 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(): Failed opening 'js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:45:15 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:45:15 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:45:18 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/style.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(): Failed opening 'css/style.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 5
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 7
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/nav.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(): Failed opening 'css/nav.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 9
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 11
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/home-banner.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(): Failed opening 'css/home-banner.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 13
ERROR - 2020-06-01 18:50:52 --> Severity: Warning --> include(css/form.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'css/form.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 15
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(css/footer.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'css/footer.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 17
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(css/Home.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'css/Home.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 20
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 24
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(css/animate.css): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'css/animate.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_css.php 26
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:50:53 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:50:54 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 3
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 5
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 7
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(): Failed opening 'js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 9
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:55:27 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 11
ERROR - 2020-06-01 18:55:28 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:55:28 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-01 18:55:28 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-01 18:55:29 --> 404 Page Not Found: Img/towtruck.png
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 4
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 6
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/bootstrap.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/bootstrap.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 8
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/slider.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/slider.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 10
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(C:\xampp\htdocs\c4massets/js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-01 18:57:49 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\c4massets/js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\c4m\application\views\template\load_js.php 12
ERROR - 2020-06-01 18:57:50 --> 404 Page Not Found: Img/services.png
ERROR - 2020-06-01 18:57:50 --> 404 Page Not Found: Img/footer.jpg
ERROR - 2020-06-01 18:57:50 --> 404 Page Not Found: Img/banner.jpg
ERROR - 2020-06-01 18:57:54 --> 404 Page Not Found: Img/towtruck.png
