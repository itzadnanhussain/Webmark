<nav>
                    <div class="menu-area">
                        <a class="toggleMenu" href="#/">
                            <span class="menu"></span>
                            <span class="slicknav_icon">
                                <span class="slicknav_icon-bar"></span>
                                <span class="slicknav_icon-bar"></span>
                                <span class="slicknav_icon-bar"></span>
                            </span>
                        </a>
                        <ul class="nav">
                            <li>
                                <a itemprop="url" href="index.php">HOME</a>
                            </li>
                            <li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-67">
                                <a title="Scrap Car Removal Mississauga Company" href="#/">COMPANY</a>
                                <span></span>
                            </li>
                            <li id="menu-item-79" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-79">
                                <a title="Car Removal Mississauga Service" href="#/">SERVICES <i class="icon-down-dir"></i></a>
                                <span></span>
                                <ul class="sub-menu">
                                    <li id="menu-item-326" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-326">
                                        <a title="Old Car Removal Mississauga" href="#/">Old Car Removal Mississauga</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-229" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-229">
                                        <a title="Wrecked Car Removal Mississauga" href="#/">Wrecked Car Removal Mississauga</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-230" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-230">
                                        <a title="Accident Car Removal Mississauga" href="#/">Accident Car Removal Mississauga</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-327" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-327">
                                        <a title="Unwanted Cars Mississauga" href="#/">Unwanted Cars Mississauga</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-231" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-231">
                                        <a title="Scrap Car Removal Mississauga" href="#/">Scrap Car Removal Mississauga</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-356" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-356">
                                        <a title="Damaged Car Removals" href="#/">Damaged Car Removals</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-593" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-593">
                                        <a title="Cash For Written Off Cars" href="#/">Cash For Written Off Cars Removal</a>
                                        <span></span>
                                    </li>
                                    <li id="menu-item-738" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-738">
                                        <a href="#/">Car Breakers</a>
                                        <span></span>
                                    </li>
                                </ul>
                            </li>
                            <li id="menu-item-93" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-93">
                                <a title="Cash For Cars Mississauga" href="#/">CASH FOR CAR REMOVAL</a>
                                <span></span>
                            </li>
                            <li id="menu-item-92" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-92">
                                <a title="Locations Ontario Wide" href="#/">Towing</a>
                                <span></span>
                            </li>
                            <li id="menu-item-433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-433">
                                <a href="#">FAQs</a>
                                <span></span>
                            </li>
                            <li id="menu-item-621" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-621">
                                <a href="blog_list.php">BLOG</a>
                                <span></span>
                            </li>
                            <li id="menu-item-91" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-91">
                                <a title="Scrap Car Removal Mississauga Contact" href="#/">CONTACT Us</a>
                                <span></span>
                            </li>
                        </ul>
                    </div>
                </nav>