<style>
    <?php
    /*custom css*/
    include 'css/style.css';
    /*animate slider css*/
    include 'css/main.css';
    /*animate slider css*/
    include 'css/reveal.css';
    /*Bootstrap*/
    include 'css/bootstrap-grid.min.css';
    include 'css/custom.css';
    ?>
</style>