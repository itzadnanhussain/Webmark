<script>
    <?php 
		include 'js/jquery.js';
		include 'js/jquery.reveal.js';
		include 'js/menu_script.js';
		include 'js/custom.js';
	?>
</script>