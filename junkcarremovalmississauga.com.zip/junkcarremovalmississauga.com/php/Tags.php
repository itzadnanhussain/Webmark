 <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-109001573-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());
        gtag('config', 'UA-109001573-1');
    </script>
<!----sCHEMA tAGS--->
     <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "AutomotiveBusiness",
            "name": "Junk Car Removal Mississauga",
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "suite 804,135 Hillcrest ave",
                "addressLocality": "Mississauga",
                "addressRegion": "ON",
                "postalCode": "L5B4B1"
            },
            "image": "https://i.imgur.com/hi6rRLp.jpg",
            "email": "carclunker@gmail.com",
            "telePhone": "(647) 484-6998",
            "url": "http://junkcarremovalmississauga.com",
            "paymentAccepted": ["cash"],
            "openingHours": "Mo,Tu,We,Th,Fr,Sa,Su 07:00-23:00",
            "geo": {
                "@type": "GeoCoordinates",
                "latitude": "43.580497",
                "longitude": "-79.625421"
            },
            "priceRange": "$$$$"
        }
    </script>