<?php
$errors = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$myemail = 'carclunker@gmail.com';//<-----Put Your email address here.
	if(empty($_POST['name'])  || empty($_POST['phone']) ||	empty($_POST['email']) ||empty($_POST['Address'])||	empty($_POST['message']))
		{
			$errors = "Error: all fields are required";
		}
		$name = $_POST['name'];
		$email_address = $_POST['email'];
		$phone = $_POST['phone'];
		$Address = $_POST['Address'];
		$message = $_POST['message'];
		if(isset($_POST['country']))
		$country=$_POST['country'];
		else
		$country="Not Working";

		if( empty($errors))
		{
		$to = $myemail;
		$email_subject = "$name";
		$email_body = "Message From JCRM:\n".
		"Location: $country\n".
		"Name: $name\nPhone: $phone\nAddress: $Address\n".
		"Email: $email_address\nMessage: \n$message";
		$headers = "From: $myemail\n";
		$headers .= "Reply-To: $email_address";
		if( mail($to,$email_subject,$email_body,$headers) )
		{
			$errors = "yes";
		}
		else
		{
			$errors = "Sorry, there has been an error!!";
		}
	}
	echo $errors;
}
else{
echo "<h2>Access Denied</h2>";
}
?>