<!DOCTYPE html>
<html lang="en">
<meta content="text/html;charset=UTF-8" />

<head>
    <?php include 'php/head.php' ?>
</head>

<body>
    <div id="logo">
        <header>
            <div class="row">
                <div class="col-sm-5">
                    <a href="index.php" class="contact_header opacity" title="Scrap Car Removal Mississauga">
                        <img class="logo-img" src="images/Scrap-car-removal-mississauga-logo.png" alt="Scrap Car Removal Mississauga">
                    </a>
                </div>
                <div class="col-sm-2">

                </div>
                <div class="col-sm-5">
                    <div class="col center">
                        <div class="contact_header">
                            <a href="mailto:carclunkers@gmail.com" class="mail_btn">CarClunker@gmail.com</a>
                        </div>
                        <div class="contact_header">
                            <a href="tel:6474846998" class="call_btn" title="Click to Call">
                                <i class="icon-phone"></i> (647) 484-6998</a>
                        </div>
                        <a title="Get Instant Quote" href="#/" class="big-link" data-reveal-id="myModal" data-animation="fade">Get Online Quote</a>
                    </div>
                </div>
            </div>
        </header>
    </div>
    <div class="margin"></div>
    <div class="container">
        <div id="header">
            <div id="menu">
                <?php include_once('php/nav.php') ?>
            </div>

            <div id="myModal" class="reveal-modal">
                <div role="form" class="wpcf7" id="wpcf7-f121-o1" dir="ltr">
                    <div class="screen-reader-response"></div>
                    <form name="contactform" id="messageform" method="post" action="php/sendmail.php" class="wpcf7-form">
                        <div style="display: none;">
                            <input type="hidden" name="_wpcf7" value="121" />
                            <input type="hidden" name="_wpcf7_version" value="4.6" />
                            <input type="hidden" name="_wpcf7_locale" value="" />
                            <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f121-o1" />
                            <input type="hidden" name="_wpnonce" value="c92fbcb3f1" />
                        </div>
                        <div>
                            <ul>
                                <li>Your Name*
                                    <span class="form-control your-name">
                                        <input type="text" name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" required />
                                    </span>
                                </li>
                                <li>Your Email*
                                    <span class="form-control your-email">
                                        <input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email required" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Phone*
                                    <span class="form-control your-subject">
                                        <input type="number" name="phone" value="" size="40" class="form-control" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Address*
                                    <span class="form-control your-subject">
                                        <input type="text" name="Address" value="" size="200" class="wpcf7-form-control" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Message*
                                    <span class="form-control your-message">
                                        <textarea name="message" cols="40" rows="10" class="wpcf7-form-control " aria-invalid="false" required></textarea>
                                    </span>
                                </li>
                                <li>
                                    <input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" />
                                    <div class="wpcf7-response-output wpcf7-display-none"></div>
                                </li>
                            </ul>
                        </div>
                    </form>
                </div>
                <a class="close-reveal-modal">x</a>
            </div>
        </div>
    </div>
    <div class="container  center">
        <img class="main_img" src="images/main.jpg" alt="Junk Car Removal Mississauga Offers Top Dollar Cash for Cars" title="Junk Car Removal Mississauga Offers Top Dollar Cash for Cars" />
    </div>
    <div id="page">
        <div class="container">
            <h1>
                <span>Junk Car Removal Mississauga</span>
                <span class="green"> Offers </span>
                <span class="red"> Top </span>
                <span class="cyan">Dollar </span>
                <span class="blue">Cash for Cars</span>
            </h1>
            <div class="row">
                <div class="col-sm-9">
                    <p>Welcome to
                        <span style="color: #/00ccff;">
                            <strong>‘Junk car removal Mississauga’</strong>
                        </span>
                        . We are the safest and reputable scrap yard. We remove scrap, damaged, old and non-running cars. We tend to take the trouble and make your life peaceful. We accept your junk car in any condition and model even if the car doesn’t run. Our service is fast
                        simple and economical. Customer satisfaction is our first priority. We have friendly employees. we tend to make sure that we do our best to make the customer happy. Junk car removal Mississauga offers great facilities to our customers,
                        like free towing.
                    </p>
                    <p>
                        <em>•simple to avail our service for
                            <span style="color: #/00ccff;"></span>
                            <span style="color: #/00ccff;">
                                <strong>free</strong>
                            </span> car collection in Mississauga</em>
                        <br />
                        <em> • Non-runner? MOT failure? Or any unwanted car. No worries! Instant to dollar cash for your scrap car</em>
                        <br />
                        <em> • Specialist in the field, committed to giving you a fast and friendly service, leading largest scrap car removal network in Mississauga</em>
                        <br />
                        <em>• vehicle recyclers.</em>
                        <br /> • We do all the hard work, so you don’t have to!
                        <span style="color: #/00ccff;">
                            <strong>
                                <em>Quick, Easy and Hassle Free</em>
                            </strong>
                        </span>
                    </p>
                    <p>
                        Have scrap cars to sell? Don’t worry about anything. The condition of doesn’t matter you just contact us, we will buy your car and pick up your junk car at your current location and give you top dollar cash for scrap car removal on the spot in Mississauga.
                        Recycling your junk car at our auto wrecking yard is not only good for the environment as well as good for human health.</p>
                </div>
                <div class="col-sm-3">
                    <img src="images/men.png" class="center" alt="Cash for scrap car removal" sizes="(max-width: 211px) 100vw, 211px" />
                </div>
            </div>
            <h2>We do junk car removal all around
                <span style="color: #/ff0000;">
                    <strong>Mississauga, Brampton</strong> &amp; Etobicoke, Ontario</span>
            </h2>
            <p>If you need to scrap your car, get yourself on-line, and just pop “scrap my cars” on your computer, and you will see that dozens of companies want to buy your car with offering best prices in your region. There are many dodgy dealers within
                the automobile scrapping sector, you just avoid them and staying away from issues.
                <span style="color: #/00ccff;">
                    <strong>‘Junk car removal Mississauga’</strong>
                </span> is the best place where you sell your old and unwanted vehicle. They collect your wrecked car within day and pays you good cash as well.
            </p>
            <p>Luckily, now with
                <span style="color: #/00ccff;">
                    <strong> ‘Junk Car Removal’</strong>
                </span> network of collectors, one phone call will do it. Or better still; just fill in our online form for an instant quote. You can even accept the quote and book it in online.</p>
            <p>
                <strong>So, why wait? This is how simple it works!</strong>
            </p>
            <p></p>
            <p>
                <em>• Get a free and instant online quote for your scrap car</em>
                <br />
                <em> • Fill in the basic details about your vehicle.</em>
                <br />
                <em> • We will contact you in 2 working hours to setup collection time according to your choice.</em>
                <br />
                <em> • Our friendly and fully certified recycling centre team member will come to collect your vehicle.</em>
                <br />
                <em> • Top dollar cash paid on collection.</em>
                <br />
                <em> • You will get a great price for your scrap car with payment made on day of collection that simple!</em>
            </p>
            <p>Our Services</p>
            <ul>
                <li>
                    <a title="UNWANTED CARS Mississauga" href="#/">Cash For Unwanted Cars</a>
                </li>
                <li>Unwanted Car Removal</li>
                <li>
                    <a title="Cash For Cars Mississauga" href="#/" target="_blank" rel="noopener">Cash For Cars Mississauga</a>
                </li>
                <li>
                    <a title="Cash For Wrecked Cars" href="#/">Cash For Wrecked Cars</a>
                </li>
                <li>Cash For Accident Cars</li>
                <li>
                    <a title="Cash For Old Cars Mississauga" href="#/" target="_blank" rel="noopener">Cash For Old Cars Mississauga</a>
                </li>
                <li>
                    <a title="Old Car Removal Mississauga" href="#/" target="_blank" rel="noopener">Old Car Removal</a>
                </li>
                <li>Used Car Removals</li>
                <li>
                    <a title="Scrap Car Removal Mississauga" href="scrap-car-removal-Mississauga/index.html" target="_blank" rel="noopener">Scrap Car Removals Mississauga</a>
                </li>
                <li>
                    <a title="Cash For Junk Cars" href="#/" target="_blank" rel="noopener">Cash For Junk Cars</a>
                </li>
                <li>Cash For Damged Cars</li>
                <li>
                    <a title="Damged Car Removals" href="#/">Damged Car Removals</a>
                </li>
                <li>Cash For Scrap Cars</li>
                <li>
                    <a title="Wrecked Car Removal Mississauga" href="#/" target="_blank" rel="noopener">Wrecked Car Removal</a>
                </li>
                <li>
                    <a title="Accident Car Removal Mississauga" href="#/" target="_blank" rel="noopener">Accident Car Removal In Mississauga</a>
                </li>
                <li>Car Collection</li>
            </ul>
            <p></p>
            <p>At junk car removal Mississauga, we will send you your CoD thus all of your paperwork stays so as. It’s legal to accept cash for your car unregistered vehicles are such a large drawback, it is very important that everything to try and do with
                cars and different four-wheel friends is completely clear. You need to know it is legal to just accept money for your scrap or old car. Whereas several dodgy dealers can in Mississauga attempt to take your scrap car off your hands without
                any disturbance and less paperwork, reciprocally for a wad of bank notes, they are breaking the law. Be careful before scrap your car and make sure your car dealer is honest.
            </p>
            <p>Junk car removal is one of the best services in Mississauga. We have a tendency to pay our customers the very best potential worth for his or her unwanted car with absolute transparency within the entire group action. No hidden charges or
                extra charges are included, and your old or scrap vehicle is towed away from your location without any charges. You can earn more money for your old car that was lying idle in your garage or driveway. Get a nice price for your unwanted
                car. Don’t delay!
            </p>
            <h3> We Specialise in Cash For Car For All Makes And Models: Scrap Car Removal For Cash</h3>
            <p>Ask Questions? Scrap car removal services are going to be happy to answer any of your queries – keep in mind if an organization is reputable, it’s got nothing to cover. We always work with Authorized Treatment Facilities (ATF) that providing
                you excellent car removal service with all the high standards. Visit our website regularly for additional information on the way to get money for scrap cars. You can request an instant quote for your junk automotive by leaving details
                of your vehicle and contact information. Our experienced employees can provide a prompt response or go back to you soon!</p>
            <p>
                <p></p>
                <p>
                    <em>
                        <strong>Call us</strong>
                        <strong>Today</strong>
                    </em>:
                    <strong>
                        <a title="CONTACT" href="contact/index.html">
                            <span style="color: #/00ccff;">(647) 484-6998</span>
                        </a>,</strong> or fill in a enquiry form for a
                    <span style="color: #/00ccff;">
                        <strong>‘free Online quotation’</strong>
                    </span>
                </p>
                <p></p>
                <p>
                    <span style="color: #/00ccff;"> Scrap Car Removal Mississauga has collection centers on other major cities and provide Services all over Mississauga, Specifically:</p>
                <p></p>
                <p>Port Credit</p>
                <p>Malton</p>
                <p>Dixie</p>
                <p>Cooksville</p>
                <p>Erin Mills</p>
                <p>Streetsville</p>
                <p>East Credit</p>
                <p>Meadowvale</p>
        </div>
    </div>
    <footer>
        <div class="container white center">
            <div class="row">
                <div class="col-sm-3">
                    <strong>OUR LOCATION</strong>
                    <iframe width="100%" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d369973.65558336105!2d-79.77453057823067!3d43.576984339610874!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b469fe76b05b7%3A0x3146cbed75966db!2sMississauga%2C+ON%2C+Canada!5e0!3m2!1sen!2s!4v1517287970623"></iframe>
                </div>
                <div class="col-sm-3">
                    <strong>TOP REVIEW</strong>
                    <p>I phoned and emailed a few companies prior, they could not pick up in time and offered far less money. Scrap Car Removal Mississauga phoned back promptly with a price and arranged pickup for the next day.
                        <br />
                        <i>john Miller</i>
                    </p>
                </div>
                <div class="col-sm-3">
                    <strong>CONTACT</strong>
                    <p>(647) 484-6998
                        <br /> carclunker@gmail.com
                        <br /> Monday to Saturday:
                        <br /> 7:00 am - 11:00 pm</p>

                </div>
                <div class="col-sm-3">
                    <strong>ADDRESS</strong>
                    <p>Suite 804, 135 Hillcrest ave
                        <br /> Mississauga, Ontario
                        <br /> L5B 4B1</p><br />
                    <div class="soc">
                        <a href="#/" rel="nofollow" class="socials" title="our facebook link" target="_blank">
                            <i class="icon-facebook"></i>
                        </a>
                        <a href="#/" rel="nofollow" class="socials" title="our google plus link" target="_blank">
                            <i class="icon-gplus"></i>
                        </a>
                        <a href="#/" rel="nofollow" class="socials" title="our You Tube link" target="_blank">
                            <i class="icon-youtube"></i>
                        </a>
                    </div>
                </div>
            </div>
            <br />
            <div class="margin"></div>
            <strong>Cities We Serve</strong>
            <div class="row">
                <div class="col-sm-4">
                    <a href="#/">Brampton</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Mississauga</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Etobicoke</a>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <a href="#/">Milton</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Oakville</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Georgetown</a>
                </div>
            </div>
        </div>
    </footer>
    <div id="footer" class="container copyright center">
        <span>&copy; Copyright 2013 Scrap Car Removal Mississauga. All Rights Reserved.</span>
    </div>
    <?php include('php/load_js.php') ?>
</body>

</html>