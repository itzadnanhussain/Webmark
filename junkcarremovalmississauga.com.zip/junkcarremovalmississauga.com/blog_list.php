<!DOCTYPE html>
<html lang="en">
<meta content="text/html;charset=UTF-8" />

<head>
    <?php include 'php/head.php' ?>
</head>

<body>
    <div id="logo">
        <header>
            <div class="row">
                <div class="col-sm-5">
                    <a href="index.php" class="contact_header opacity" title="Scrap Car Removal Mississauga">
                        <img class="logo-img" src="images/Scrap-car-removal-mississauga-logo.png" alt="Scrap Car Removal Mississauga">
                    </a>
                </div>
                <div class="col-sm-2">

                </div>
                <div class="col-sm-5">
                    <div class="col center">
                        <div class="contact_header">
                            <a href="mailto:carclunkers@gmail.com" class="mail_btn">CarClunker@gmail.com</a>
                        </div>
                        <div class="contact_header">
                            <a href="tel:6474846998" class="call_btn" title="Click to Call">
                                <i class="icon-phone"></i> (647) 484-6998</a>
                        </div>
                        <a title="Get Instant Quote" href="#/" class="big-link" data-reveal-id="myModal" data-animation="fade">Get Online Quote</a>
                    </div>
                </div>
            </div>
        </header>
    </div>
    <div class="margin"></div>
    <div class="container">
        <div id="header">
            <div id="menu">
                <?php include_once('php/nav.php') ?>
            </div>

            <div id="myModal" class="reveal-modal">
                <div role="form" class="wpcf7" id="wpcf7-f121-o1" dir="ltr">
                    <div class="screen-reader-response"></div>
                    <form name="contactform" id="messageform" method="post" action="php/sendmail.php" class="wpcf7-form">
                        <div style="display: none;">
                            <input type="hidden" name="_wpcf7" value="121" />
                            <input type="hidden" name="_wpcf7_version" value="4.6" />
                            <input type="hidden" name="_wpcf7_locale" value="" />
                            <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f121-o1" />
                            <input type="hidden" name="_wpnonce" value="c92fbcb3f1" />
                        </div>
                        <div>
                            <ul>
                                <li>Your Name*
                                    <span class="form-control your-name">
                                        <input type="text" name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" required />
                                    </span>
                                </li>
                                <li>Your Email*
                                    <span class="form-control your-email">
                                        <input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email required" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Phone*
                                    <span class="form-control your-subject">
                                        <input type="number" name="phone" value="" size="40" class="form-control" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Address*
                                    <span class="form-control your-subject">
                                        <input type="text" name="Address" value="" size="200" class="wpcf7-form-control" aria-required="true" aria-invalid="false" required />
                                    </span>
                                </li>
                                <li>Your Message*
                                    <span class="form-control your-message">
                                        <textarea name="message" cols="40" rows="10" class="wpcf7-form-control " aria-invalid="false" required></textarea>
                                    </span>
                                </li>
                                <li>
                                    <input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" />
                                    <div class="wpcf7-response-output wpcf7-display-none"></div>
                                </li>
                            </ul>
                        </div>
                    </form>
                </div>
                <a class="close-reveal-modal">x</a>
            </div>
        </div>
    </div>
    <div class="container  center">
        <img class="main_img" src="images/main.jpg" alt="Junk Car Removal Mississauga Offers Top Dollar Cash for Cars" title="Junk Car Removal Mississauga Offers Top Dollar Cash for Cars" />
    </div>
    <div id="page">
        <div class="container">
            <div class="row">
            <div class="col-sm-12 col-lg-12">
                    <h1>Junk Car Removal Mississauga Is A Scrap Car Buyers Near Me Company</h1>
                    <p style="color:blueviolet">Posted On 4-12-2020</p>
                     <p>Junk Car Removal Mississauga is your Scrap Car Buyers Near Me. No matter what type or condition of your car. We can accept any make, model and age of your car, you will be able to expect best offers for flood damaged cars in Mississauga from us. We simply create a quick buying service through our website and phone.</p>

                     <a href="scrap_car_buyers_near_me_company.php" class="link">Read More</a>
                </div>
                <div class="col-sm-12 col-lg-12">
                    <h1>Junk Car Removal, Cash For Scrap Cars Company In Mississauga</h1>
                    <p style="color:blueviolet">Posted On 17th November 2020</p>
                    <p>At Junk Car Removal, finding Cash For Scrap Cars for selling car is simple, less time consuming, efficient and totally free of cost.We are the best car removal service company in Mississauga and we have more than 10 years of outstanding experience. Our staff members including our trained drivers and agent. </p>
                    <a href="cash_for_scrap_cars_company_in_mississauga.php" class="link">Read More</a>
                </div>
                <div class="col-sm-12 col-lg-12">
                    <h1>How You Can Scrap Car Removal in Mississauga</h1>
                    <p style="color:blueviolet">Posted On 14th October 2020</p>
                    <p> You may be trying to Scrap car removal and you was able to hear about scrap car removal companies in Mississauga. If you are planning to check areas or cities for unwanted car removal services, you can really find more spread all over the place. </p>
                    <a href="how-you-can-scrap-car-removal-in-mississauga.php" class="link">Read More</a>
                </div>
                <div class="col-sm-12 col-lg-12">
                    <h1>Sell Scrap Car To Our Company In Mississauga</h1>
                    <p style="color:blueviolet">Posted On 30th August 2020</p>
                    <p> Finally the winter is over and spring is around the corner, Despite the COVID-19 pandemic which is unprecedented phenomenon and affecting our social and financial behaviors, the spring comes with yearly clean and purge protocols for Canadian</p>
                    <a href="sell-scrap-car-to-our-company-in-mississauga.php" class="link">Read More</a>
                </div>


            </div>
        </div>
    </div>
    <footer>
        <div class="container white center">
            <div class="row">
                <div class="col-sm-3">
                    <strong>OUR LOCATION</strong>
                    <iframe width="100%" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d369973.65558336105!2d-79.77453057823067!3d43.576984339610874!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b469fe76b05b7%3A0x3146cbed75966db!2sMississauga%2C+ON%2C+Canada!5e0!3m2!1sen!2s!4v1517287970623"></iframe>
                </div>
                <div class="col-sm-3">
                    <strong>TOP REVIEW</strong>
                    <p>I phoned and emailed a few companies prior, they could not pick up in time and offered far less money. Scrap Car Removal Mississauga phoned back promptly with a price and arranged pickup for the next day.
                        <br />
                        <i>john Miller</i>
                    </p>
                </div>
                <div class="col-sm-3">
                    <strong>CONTACT</strong>
                    <p>(647) 484-6998
                        <br /> carclunker@gmail.com
                        <br /> Monday to Saturday:
                        <br /> 7:00 am - 11:00 pm</p>

                </div>
                <div class="col-sm-3">
                    <strong>ADDRESS</strong>
                    <p>Suite 804, 135 Hillcrest ave
                        <br /> Mississauga, Ontario
                        <br /> L5B 4B1</p><br />
                    <div class="soc">
                        <a href="#/" rel="nofollow" class="socials" title="our facebook link" target="_blank">
                            <i class="icon-facebook"></i>
                        </a>
                        <a href="#/" rel="nofollow" class="socials" title="our google plus link" target="_blank">
                            <i class="icon-gplus"></i>
                        </a>
                        <a href="#/" rel="nofollow" class="socials" title="our You Tube link" target="_blank">
                            <i class="icon-youtube"></i>
                        </a>
                    </div>
                </div>
            </div>
            <br />
            <div class="margin"></div>
            <strong>Cities We Serve</strong>
            <div class="row">
                <div class="col-sm-4">
                    <a href="#/">Brampton</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Mississauga</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Etobicoke</a>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-4">
                    <a href="#/">Milton</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Oakville</a>
                </div>
                <div class="col-sm-4">
                    <a href="#/">Georgetown</a>
                </div>
            </div>
        </div>
    </footer>
    <div id="footer" class="container copyright center">
        <span>&copy; Copyright 2013 Scrap Car Removal Mississauga. All Rights Reserved.</span>
    </div>
    <?php include('php/load_js.php') ?>
</body>

</html>