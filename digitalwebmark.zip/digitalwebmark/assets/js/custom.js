$('#myForm,#myForm2,#mform').submit(function(e) {
    e.preventDefault();
    var url = $(this).attr( 'action' );
    var formid='#'+this.id;
    
    var inputcontrols = $(formid+' :input');
    var data = {};
    inputcontrols.each(function() {
        var c_name=this.name;
        data[c_name] = $(this).val().trim();
    });
      var posting = $.post( url, data );
      posting.done(function( data ) {
          var datavalues=data.split('-');
          var status=formid+" .formstatus";
          $(status).empty();
          $(status).append('<p>'+datavalues[0]+'</p>');
          $(status).children().css( "color", datavalues[1] );
          $(status).show().delay(4000).fadeOut();
          if(datavalues[2]!="")
            window.location.href = datavalues[2];
      });
}) 

$('.skilllevel input[type="checkbox"]').on('change', function() {
    $('.skilllevel input[name="' + this.name + '"]').not(this).prop('checked', false);
});

function checkskill(el) {
         var e=$(el).attr('id');
        if($('#' + e).is(":checked")){
              $("#"+ e+"_level").prop("checked", true);
         }
         else{
             $("#"+ e+"_level").prop("checked", false);
         }
     }

 window.onscroll = function () {
     myFunction()
 };

 function myFunction() {
     var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
     var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
     var scrolled = (winScroll / height) * 100;
     document.getElementById("myBar").style.width = scrolled + "%";
 }
 /*popup form------Page---*/

 /*********** popup form***********/

 function openForm() {
     document.getElementById("popupForm").style.display = "block";
 }

 function closeForm() {
     document.getElementById("popupForm").style.display = "none";
 }
 /*********** Navigation file***********/
 $(document).ready(function () {
     $(".menu").click(function () {
         $("nav").slideToggle(500);
     })
 })


 /*********** Scroll button***********/

 $(document).ready(function () {

     //Check to see if the window is top if not then display button
     $(window).scroll(function () {
         if ($(this).scrollTop() > 130) {
             $('.scrollToTop').fadeIn();
         } else {
             $('.scrollToTop').fadeOut();
         }
     });

     //Click event to scroll to top
     $('.scrollToTop').click(function () {
         $('html, body').animate({
             scrollTop: 0
         }, 1200);
         return false;
     });

 });


$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});