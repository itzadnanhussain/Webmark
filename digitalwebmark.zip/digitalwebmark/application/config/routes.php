<?php
defined('BASEPATH') OR exit('No direct script access allowed');
///Admin
$route['sendMail']='Admin/SendUserEmail';
$route['admin']='Admin/AdminLogin';
$route['applicants']='Admin/LoadTableApplicants';
$route['resume/(:any)']='Admin/ViewResume';
$route['download/(:any)']='Admin/file_download';
$route['admin/delete']='Admin/Delete';
////career route
$route['careers']='Career/AddNewCareer';
$route['career/clients/(:num)']='Career/ViewClientRecords';


$route['default_controller'] = 'Pages';
$route["blogs/(:any)"]='Pages/blogView/$1';
$route["(:any)"]='Pages/view/$1';



$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
