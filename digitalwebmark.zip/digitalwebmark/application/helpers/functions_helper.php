<?php
defined('BASEPATH') or exit('No direct script access allowed');
///*****************************Json Function****************************///
if (!function_exists('send_json')) {
    function send_json($array, $code = 200)
    {
        $thiz = &get_instance();
        $thiz->output
            ->set_status_header($code)
            ->set_content_type('application/json')
            ->set_output(json_encode($array))
            ->display();
        exit;
    }
}


///******************************Print Data********************************/// 
if (!function_exists('print_data')) {
    function print_data($data = array())
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}


///*******************************Date Format******************************///
if(!function_exists('dateformat'))
{
    function dateformat($date)
    {
        $result=date("Y-m-d",$date);
        return $result;
    }
}

///***********************Print Fname***************************************///
if(!function_exists('fname'))
{
    function fname($string)
  {
    $fullname=explode(' ',$string);
    $fname=array_shift($fullname); 
    if($fname)
    {
        return $fname;
    }
    else
    {
        return false;
    } 
  }
}


///***********************Print lname***************************************///
if(!function_exists('lname'))
{
    function lname($string)
    {
      $fullname=explode(' ',$string);
      $lname=array_pop($fullname); 
      if($lname)
      {
          return $lname;
      }
      else
      {
          return false;
      } 
    }
}


////Teacher Upload images
if (!function_exists('file_upload')) {
    function file_upload($userfile)
    {

        $thiz = &get_instance();
        $config['upload_path'] = './assets/image/teacher';
        $config['allowed_types'] = 'gif|png|jpeg|jpg';
        $thiz->load->library('upload', $config);
        if ($thiz->upload->do_upload($userfile)) {
            $data_upload_path = $thiz->upload->data();
            print_r($data_upload_path);
            die;
            $image = $data_upload_path[$config['upload_path']];
        } else {
            echo 'an error';
            die;
        }
    }
}
