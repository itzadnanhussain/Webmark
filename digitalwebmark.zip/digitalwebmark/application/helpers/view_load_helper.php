<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* /////Helper Function For Login Views//////
if(!function_exists('login_view'))
{
    function login_view($page, $data=array())
    {
        $thiz=&get_instance();
        $thiz->load->view('login/templates/header');
        $thiz->load->view($page,$data);
        $thiz->load->view('login/templates/footer'); 
        //$thiz->load->view('login/templates/footer',array('login_script_filename'=>basename($page))); 
    }
} */

///admin view helper
if(!function_exists('Pageview'))
{
    function Pageview($page, $data=array(), $title)
    {
        $data_title['title']=$title;
        $thiz=&get_instance();
        $thiz->load->view('template/head',$data_title);
        $thiz->load->view($page,$data);
        $thiz->load->view('template/footer'); 
        //$thiz->load->view('login/templates/footer',array('login_script_filename'=>basename($page))); 
    }
}



/* ////Teacher View Helper
 if (!function_exists('teacher_view')) {
     function teacher_view($page, $data=array())
     {
        $data_title['title']=$page;
        $thiz=&get_instance();
        $thiz->load->view('teacher/templates/header',$data_title);
        $thiz->load->view($page,$data);
        $thiz->load->view('teacher/templates/footer'); 
        //$thiz->load->view('login/templates/footer',array('login_script_filename'=>basename($page))); 
   

     }
      
 } */