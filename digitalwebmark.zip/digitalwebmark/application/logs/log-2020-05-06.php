<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-06 21:58:23 --> 404 Page Not Found: Php/sendEmail.php
