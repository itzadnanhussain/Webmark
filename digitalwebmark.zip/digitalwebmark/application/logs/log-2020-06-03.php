<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 00:27:36 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-03 00:51:58 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-03 00:52:01 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-03 00:52:03 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-03 00:52:09 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-03 00:52:11 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-03 00:52:13 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-03 00:52:14 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-03 00:52:14 --> 404 Page Not Found: System/.env
ERROR - 2020-06-03 00:52:15 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-03 00:52:16 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-03 10:00:34 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-03 10:09:53 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-03 10:10:18 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-03 10:10:35 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-03 18:02:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-03 22:59:46 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-03 23:58:34 --> 404 Page Not Found: Php/sendEmail.php
