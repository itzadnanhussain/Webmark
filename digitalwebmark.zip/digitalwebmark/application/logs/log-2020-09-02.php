<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-02 04:41:24 --> 404 Page Not Found: Wordpress/xmlrpc.php
ERROR - 2020-09-02 12:15:31 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-02 13:00:05 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-02 14:57:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-09-02 15:18:43 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-02 17:13:38 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-02 18:13:10 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-02 20:06:16 --> 404 Page Not Found: Admin/index.php
ERROR - 2020-09-02 21:07:42 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-02 22:47:06 --> 404 Page Not Found: Test/vendor
ERROR - 2020-09-02 22:47:06 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-02 22:48:48 --> 404 Page Not Found: Blogs/blogs
