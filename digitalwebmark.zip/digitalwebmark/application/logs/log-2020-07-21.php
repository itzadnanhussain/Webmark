<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-21 03:52:44 --> 404 Page Not Found: Blogs/img
ERROR - 2020-07-21 04:55:14 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-21 10:25:19 --> 404 Page Not Found: Img/small-img
ERROR - 2020-07-21 19:35:42 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-21 19:36:07 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-21 19:36:13 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-21 19:36:22 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-21 19:36:29 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-21 19:36:35 --> 404 Page Not Found: Blog/.env
