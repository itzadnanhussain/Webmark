<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-08 05:44:29 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:44:29 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:46:56 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:46:56 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:47:42 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:47:42 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:48:56 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:48:57 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:49:25 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:49:25 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:49:39 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:49:39 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:50:39 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-08 05:50:39 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-08 05:50:44 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:50:44 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:50:54 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:50:54 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:53:15 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:53:15 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:54:12 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:54:12 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:55:13 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:55:13 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:56:03 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 05:56:03 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-08 07:21:23 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-08 07:21:23 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-08 07:54:05 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-11-08 07:54:47 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\User.php 28
ERROR - 2020-11-08 09:04:11 --> Severity: Notice --> Undefined variable: emailUser E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 146
ERROR - 2020-11-08 09:04:11 --> Severity: Notice --> Undefined variable: emailUser E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 147
ERROR - 2020-11-08 09:04:11 --> Severity: Notice --> Undefined variable: emailUser E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 148
ERROR - 2020-11-08 09:04:13 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 150
ERROR - 2020-11-08 09:04:48 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 150
ERROR - 2020-11-08 09:06:50 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 149
ERROR - 2020-11-08 09:07:01 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 149
ERROR - 2020-11-08 09:09:14 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 149
ERROR - 2020-11-08 11:06:33 --> Severity: Notice --> Undefined index: subject E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 194
ERROR - 2020-11-08 11:06:35 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xampp\htdocs\digitalwebmark\system\libraries\Email.php 1902
