<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-20 19:05:35 --> Severity: error --> Exception: Call to undefined function print_data() E:\xampp\htdocs\digitalwebmark\application\views\applicant_tb.php 5
ERROR - 2020-10-20 19:05:53 --> Severity: Notice --> Undefined variable: records E:\xampp\htdocs\digitalwebmark\application\views\applicant_tb.php 5
ERROR - 2020-10-20 19:06:33 --> Severity: Notice --> Undefined variable: records E:\xampp\htdocs\digitalwebmark\application\views\applicant_tb.php 5
ERROR - 2020-10-20 19:07:02 --> Severity: error --> Exception: Call to undefined function getByWhere() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 71
ERROR - 2020-10-20 19:07:46 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:07:47 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:09:59 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:09:59 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:13:13 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:13:13 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:18:36 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:18:36 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:18:48 --> 404 Page Not Found: Uploads/Arshad_Hussain1591523402.pdf
ERROR - 2020-10-20 19:19:13 --> 404 Page Not Found: Uploads/Saadia_Rehman1592211188.pdf
ERROR - 2020-10-20 19:19:48 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:19:48 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:23:09 --> 404 Page Not Found: Admin/login
ERROR - 2020-10-20 19:23:26 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:23:26 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:24:24 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:24:24 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:24:44 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:24:44 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:25:39 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:25:39 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:26:42 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:26:42 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:27:23 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:27:23 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:28:35 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:28:35 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:28:49 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:28:49 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:29:12 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:29:12 --> 404 Page Not Found: Admin/assets
ERROR - 2020-10-20 19:30:24 --> 404 Page Not Found: Admin/login
ERROR - 2020-10-20 20:02:18 --> 404 Page Not Found: Uploads/Jatesh_Kumar1591503210.pdf
ERROR - 2020-10-20 20:02:27 --> 404 Page Not Found: Uploads/Arshad_Hussain1591523402.pdf
ERROR - 2020-10-20 20:02:30 --> 404 Page Not Found: Uploads/Hamza_Bin_Khalid1591127817.pdf
ERROR - 2020-10-20 20:02:37 --> 404 Page Not Found: Uploads/Saadia_Rehman1592211188.pdf
ERROR - 2020-10-20 20:02:41 --> 404 Page Not Found: Uploads/Muhammad_Arshad1592839140.pdf
