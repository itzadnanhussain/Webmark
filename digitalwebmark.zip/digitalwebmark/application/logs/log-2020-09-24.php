<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-24 01:15:03 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 01:17:12 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 02:50:46 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:32 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:33 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:33 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:33 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 04:51:34 --> 404 Page Not Found: Bank/assets
ERROR - 2020-09-24 06:01:34 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 06:57:23 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-24 07:15:26 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-09-24 07:15:26 --> 404 Page Not Found: Storage/.env
ERROR - 2020-09-24 07:15:26 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-24 08:36:59 --> 404 Page Not Found: Modules/handle-key
ERROR - 2020-09-24 10:35:46 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-24 12:13:50 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-24 13:46:02 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-24 15:01:26 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 15:01:38 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 15:01:46 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 15:03:04 --> 404 Page Not Found: User/register
ERROR - 2020-09-24 18:12:28 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-24 19:08:39 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-24 19:38:31 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-24 21:05:41 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-24 22:35:36 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-24 22:56:26 --> 404 Page Not Found: User/popupSendEmail
