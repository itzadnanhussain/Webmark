<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-22 15:19:00 --> Severity: Notice --> Undefined variable: skills /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 66
ERROR - 2020-06-22 15:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 66
ERROR - 2020-06-22 17:18:42 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-22 19:03:06 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-22 19:03:16 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-22 19:03:27 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-22 19:03:37 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-22 19:03:50 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-22 19:03:57 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-22 19:04:09 --> 404 Page Not Found: Blog/.env
