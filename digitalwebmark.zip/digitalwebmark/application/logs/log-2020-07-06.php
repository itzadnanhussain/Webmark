<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 00:07:13 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-06 02:41:26 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-06 05:00:12 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-06 13:28:10 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-06 14:43:21 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-06 16:47:48 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-06 19:26:47 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-06 19:26:48 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-06 19:26:49 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-06 19:26:50 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-06 19:26:52 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-06 19:26:53 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-06 19:26:54 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-06 19:26:57 --> 404 Page Not Found: System/.env
ERROR - 2020-07-06 19:26:58 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-06 19:27:00 --> 404 Page Not Found: Shop/.env
ERROR - 2020-07-06 22:47:15 --> 404 Page Not Found: Img/portfolio
