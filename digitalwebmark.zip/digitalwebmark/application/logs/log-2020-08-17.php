<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-17 05:48:44 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-17 08:21:40 --> 404 Page Not Found: Blogs/php
ERROR - 2020-08-17 11:43:57 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2020-08-17 11:43:57 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2020-08-17 12:32:46 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-17 17:36:27 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-08-17 17:36:27 --> 404 Page Not Found: Storage/.env
ERROR - 2020-08-17 17:36:28 --> 404 Page Not Found: Public/.env
ERROR - 2020-08-17 20:08:40 --> 404 Page Not Found: Test/wp-login.php
ERROR - 2020-08-17 22:32:17 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-17 23:06:02 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-17 23:06:23 --> 404 Page Not Found: Img/blog
ERROR - 2020-08-17 23:06:23 --> 404 Page Not Found: Assets/img
