<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-01 04:50:37 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-01 15:48:00 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-01 17:52:03 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-01 18:49:40 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-01 18:59:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-01 19:46:28 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-01 21:17:06 --> 404 Page Not Found: Test/vendor
ERROR - 2020-09-01 22:53:53 --> 404 Page Not Found: Laravel/.env
