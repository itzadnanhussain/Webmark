<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-15 04:58:16 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-15 07:17:26 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-15 09:21:56 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-15 10:45:00 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-15 12:06:23 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-15 17:58:49 --> 404 Page Not Found: Modules/default-params
ERROR - 2020-06-15 18:52:05 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Images/wlw
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Static/admin
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Catalog/view
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Order/catalog
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Catalog/view
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Js/mage
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Js/mage
ERROR - 2020-06-15 18:52:06 --> 404 Page Not Found: Skin/adminhtml
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/mage
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Administrator/manifests
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/eccube.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/eccube.legacy.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/css.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/navi.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/win_op.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/site.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/locale.js
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: User_data/css
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Template/admin
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: User_data/packages
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/mage
ERROR - 2020-06-15 18:52:07 --> 404 Page Not Found: Js/lib
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-15 21:36:23 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-15 23:12:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-15 23:37:46 --> 404 Page Not Found: Wp-includes/css
ERROR - 2020-06-15 23:37:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-15 23:44:36 --> 404 Page Not Found: Blogs/blogs
