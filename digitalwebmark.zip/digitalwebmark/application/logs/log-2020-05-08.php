<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: System/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-08 02:02:01 --> 404 Page Not Found: Shop/.env
