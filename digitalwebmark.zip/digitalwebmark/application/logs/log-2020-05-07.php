<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-07 02:00:00 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-07 04:12:26 --> 404 Page Not Found: Php/popupSendEmail.php
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-07 07:34:17 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-07 09:40:10 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-07 10:42:51 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-07 14:28:55 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-07 14:29:02 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-07 14:29:11 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-07 14:29:19 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-07 14:29:27 --> 404 Page Not Found: Phpunit/phpunit
ERROR - 2020-05-07 14:29:35 --> 404 Page Not Found: Phpunit/phpunit
ERROR - 2020-05-07 14:29:41 --> 404 Page Not Found: Phpunit/src
ERROR - 2020-05-07 14:30:01 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-07 14:30:09 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-07 14:30:17 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-07 14:30:33 --> 404 Page Not Found: Sites/all
ERROR - 2020-05-07 14:30:40 --> 404 Page Not Found: Sites/default
ERROR - 2020-05-07 14:30:46 --> 404 Page Not Found: Sites/vendor
ERROR - 2020-05-07 14:30:53 --> 404 Page Not Found: Sitio/vendor
ERROR - 2020-05-07 14:30:59 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-05-07 14:31:07 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-05-07 14:31:15 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-05-07 14:31:24 --> 404 Page Not Found: Modules/ps_checkout
ERROR - 2020-05-07 14:31:38 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-05-07 14:31:45 --> 404 Page Not Found: Modules/vendor
ERROR - 2020-05-07 14:32:00 --> 404 Page Not Found: All/vendor
ERROR - 2020-05-07 14:32:09 --> 404 Page Not Found: Sites/all
ERROR - 2020-05-07 14:32:18 --> 404 Page Not Found: 2020/vendor
ERROR - 2020-05-07 14:32:26 --> 404 Page Not Found: Panel/vendor
ERROR - 2020-05-07 14:32:33 --> 404 Page Not Found: Workspace/drupal
ERROR - 2020-05-07 14:32:41 --> 404 Page Not Found: Test/vendor
ERROR - 2020-05-07 14:32:48 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-05-07 14:32:55 --> 404 Page Not Found: Admin/ckeditor
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-07 17:32:35 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
