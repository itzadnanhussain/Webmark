<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-05 02:02:32 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-05 03:29:40 --> 404 Page Not Found: Blogs/php
ERROR - 2020-07-05 05:41:12 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-05 06:10:00 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-05 06:15:09 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-05 06:52:50 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-05 06:52:50 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-05 06:52:51 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-05 06:52:51 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-05 06:52:51 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-05 06:52:51 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-05 06:52:52 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-05 06:52:52 --> 404 Page Not Found: System/.env
ERROR - 2020-07-05 06:52:52 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-05 06:52:52 --> 404 Page Not Found: Shop/.env
ERROR - 2020-07-05 07:14:05 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-05 10:12:11 --> 404 Page Not Found: Js/mage
ERROR - 2020-07-05 12:11:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-05 12:16:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-05 20:15:10 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-05 21:35:10 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-05 21:35:15 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-05 21:35:20 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-05 21:35:25 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-05 21:35:31 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-05 21:35:37 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-05 21:35:43 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-05 23:51:02 --> 404 Page Not Found: Img/why-us
