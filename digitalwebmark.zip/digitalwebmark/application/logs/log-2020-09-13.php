<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-13 04:05:44 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 04:05:58 --> 404 Page Not Found: Wp/wp-content
ERROR - 2020-09-13 04:06:05 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2020-09-13 04:06:07 --> 404 Page Not Found: Blog/wp-content
ERROR - 2020-09-13 04:06:17 --> 404 Page Not Found: New/wp-content
ERROR - 2020-09-13 04:07:02 --> 404 Page Not Found: Old/wp-content
ERROR - 2020-09-13 04:07:10 --> 404 Page Not Found: Demo/wp-content
ERROR - 2020-09-13 05:40:01 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-13 08:27:51 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-09-13 08:27:51 --> 404 Page Not Found: Administrator/help
ERROR - 2020-09-13 08:27:51 --> 404 Page Not Found: Administrator/language
ERROR - 2020-09-13 08:27:51 --> 404 Page Not Found: Plugins/system
ERROR - 2020-09-13 08:27:52 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-09-13 08:27:54 --> 404 Page Not Found: Admin/view
ERROR - 2020-09-13 08:27:54 --> 404 Page Not Found: Images/editor
ERROR - 2020-09-13 08:27:55 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-09-13 08:27:55 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-13 08:29:01 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-13 08:42:51 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-13 08:48:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 08:48:46 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 10:07:49 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-09-13 10:07:49 --> 404 Page Not Found: Administrator/help
ERROR - 2020-09-13 10:07:50 --> 404 Page Not Found: Administrator/language
ERROR - 2020-09-13 10:07:50 --> 404 Page Not Found: Plugins/system
ERROR - 2020-09-13 10:07:50 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-09-13 10:07:51 --> 404 Page Not Found: Admin/view
ERROR - 2020-09-13 10:07:51 --> 404 Page Not Found: Images/editor
ERROR - 2020-09-13 10:07:52 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-09-13 10:07:52 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-13 10:38:23 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-13 11:49:28 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-13 12:02:30 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-13 17:42:26 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 17:43:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 17:44:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 17:45:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-13 22:19:17 --> 404 Page Not Found: Wp-content/plugins
