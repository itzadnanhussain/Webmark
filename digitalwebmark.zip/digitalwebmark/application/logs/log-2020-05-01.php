<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-01 10:54:38 --> 404 Page Not Found: /index
ERROR - 2020-05-01 11:57:12 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\dwm\application\controllers\Pages.php 16
ERROR - 2020-05-01 11:57:28 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\dwm\application\views\template\head.php 46
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:05:50 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:07:22 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:14:16 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:16:28 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:17:02 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:17:33 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:18:35 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:21:00 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(http://localhost/dwm/assets/css/bootstrap.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(http://localhost/dwm/assets/css/owl/owl.carousel.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:36 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/owl/owl.theme.default.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/slider.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/sweetalert.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/animate.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/mediaQuery.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(http://localhost/dwm/assets/css/custom.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:21:37 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/bootstrap.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/owl/owl.carousel.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/owl/owl.theme.default.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/slider.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/sweetalert.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/animate.min.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/mediaQuery.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): http:// wrapper is disabled in the server configuration by allow_url_include=0 C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(http://localhost/dwm/assets/css/custom.css): failed to open stream: no suitable wrapper could be found C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'http://localhost/dwm/assets/css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:21:42 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:24:22 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/bootstrap.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/bootstrap.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 5
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/owl/owl.carousel.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/owl/owl.carousel.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 8
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/owl/owl.theme.default.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/owl/owl.theme.default.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 11
ERROR - 2020-05-01 12:24:26 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/slider.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/slider.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 14
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/sweetalert.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/sweetalert.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 17
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/animate.min.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/animate.min.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 20
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/mediaQuery.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/mediaQuery.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 27
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(C:\xampp\htdocs\dwmassets/css/custom.css): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\dwmassets/css/custom.css' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_css.php 30
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:24:27 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:26:12 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:26:15 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(js/jquery.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(): Failed opening 'js/jquery.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 4
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(js/bootstrap.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(): Failed opening 'js/bootstrap.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 6
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(js/custom.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(): Failed opening 'js/custom.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 7
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(js/sweetalert.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:28:29 --> Severity: Warning --> include(): Failed opening 'js/sweetalert.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\template\load_js.php 10
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(js/particles.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(): Failed opening 'js/particles.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(js/app.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(): Failed opening 'js/app.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(js/owl.carousel.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(): Failed opening 'js/owl.carousel.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(js/wow.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 12:46:51 --> Severity: Warning --> include(): Failed opening 'js/wow.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(js/particles.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(): Failed opening 'js/particles.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(js/app.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(): Failed opening 'js/app.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(js/owl.carousel.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(): Failed opening 'js/owl.carousel.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(js/wow.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 13:30:56 --> Severity: Warning --> include(): Failed opening 'js/wow.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 13:33:54 --> Severity: error --> Exception: Call to undefined function baseurl() C:\xampp\htdocs\dwm\application\views\main.php 16
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(js/particles.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(): Failed opening 'js/particles.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 397
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(js/app.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(): Failed opening 'js/app.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 398
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(js/owl.carousel.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(): Failed opening 'js/owl.carousel.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 400
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(js/wow.min.js): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 13:34:21 --> Severity: Warning --> include(): Failed opening 'js/wow.min.js' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\main.php 401
ERROR - 2020-05-01 13:54:39 --> Severity: error --> Exception: syntax error, unexpected '=' C:\xampp\htdocs\dwm\application\controllers\Pages.php 25
ERROR - 2020-05-01 13:58:15 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 13:58:15 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 13:58:15 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 13:58:15 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 13:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-01 13:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-01 13:59:10 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 13:59:10 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 13:59:10 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 7
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 7
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 12
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 12
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 78
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 78
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 87
ERROR - 2020-05-01 13:59:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 87
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:22 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-01 14:17:25 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company.php
ERROR - 2020-05-01 14:19:14 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company.php
ERROR - 2020-05-01 14:19:32 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:19:45 --> 404 Page Not Found: Blogs/Five%20signs%20of%20Impressive%20Web%20Design
ERROR - 2020-05-01 14:20:35 --> 404 Page Not Found: Blogs/Five%20signs%20of%20Impressive%20Web%20Design
ERROR - 2020-05-01 14:22:08 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:10 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:11 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:12 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:12 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:12 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 14:22:12 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:16:00 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:16:00 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:16:00 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:16:02 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:16:02 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:16:04 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:16:04 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:16:05 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:16:05 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:16:05 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:16:05 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:16:05 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:16:05 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:17:53 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:17:53 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:53 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:53 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:53 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:53 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:17:58 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:17:58 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:17:58 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:18:01 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:18:01 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:01 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:01 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:01 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:01 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:18:16 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:18:16 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CustomWebsiteDevelopment.php 30
ERROR - 2020-05-01 16:18:16 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 7
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 7
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 12
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 12
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 78
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 78
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 87
ERROR - 2020-05-01 16:19:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 87
ERROR - 2020-05-01 16:20:08 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 66
ERROR - 2020-05-01 16:20:08 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\ResponsiveWebDesignDubai.php 66
ERROR - 2020-05-01 16:20:42 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:20:42 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\CMSWebsiteDevelopment.php 39
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 7
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 7
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 12
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 12
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 159
ERROR - 2020-05-01 16:21:21 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\EcommerceWebsiteDevelopment.php 159
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 7
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 7
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 12
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 12
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 31
ERROR - 2020-05-01 16:21:50 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digitalDevelopment.php 31
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 7
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 7
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 12
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 12
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 28
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 28
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 34
ERROR - 2020-05-01 16:23:47 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 34
ERROR - 2020-05-01 16:24:02 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 16
ERROR - 2020-05-01 16:24:02 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\SearchEngineOptimization.php 16
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\portfolioPage.php 7
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\portfolioPage.php 7
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\portfolioPage.php 12
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\portfolioPage.php 12
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\portfolioPage.php 76
ERROR - 2020-05-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\portfolioPage.php 76
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:24:37 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-05-01 16:25:18 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\contactPage.php 7
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\contactPage.php 7
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\contactPage.php 12
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\contactPage.php 12
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\contactPage.php 37
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\contactPage.php 37
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\contactPage.php 54
ERROR - 2020-05-01 16:25:19 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\contactPage.php 54
ERROR - 2020-05-01 16:29:00 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:29:11 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:29:11 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 5
ERROR - 2020-05-01 16:29:11 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:29:11 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 9
ERROR - 2020-05-01 16:29:11 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:29:12 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\digital-web-services.php 108
ERROR - 2020-05-01 16:29:12 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:29:12 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:29:12 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:29:12 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:29:12 --> 404 Page Not Found: Img/services
ERROR - 2020-05-01 16:31:05 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:32:26 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:40:44 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:43:53 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:44:04 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 266502120 bytes) C:\xampp\htdocs\dwm\system\core\Output.php 198
ERROR - 2020-05-01 16:44:32 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:48:30 --> 404 Page Not Found: Blogs/Never%20Hire%20a%20Cheap%20Web%20Design%20Company
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:32 --> 404 Page Not Found: Blogs/v
ERROR - 2020-05-01 16:50:37 --> 404 Page Not Found: Blogs/v
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:54 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:50:55 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:52:40 --> Severity: error --> Exception: syntax error, unexpected '$viewval' (T_VARIABLE), expecting ')' C:\xampp\htdocs\dwm\application\controllers\Pages.php 21
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:52:59 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:53:01 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:53:04 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:57:18 --> Severity: Notice --> Undefined variable: views C:\xampp\htdocs\dwm\application\views\template\head.php 50
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:18 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:57:24 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:57:52 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\dwm\application\views\template\head.php 50
ERROR - 2020-05-01 16:58:02 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\dwm\application\views\template\head.php 50
ERROR - 2020-05-01 16:58:16 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\dwm\application\views\template\head.php 50
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:29 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:31 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:35 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:58:36 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:16 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 16:59:17 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 16:59:20 --> 404 Page Not Found: Blogs/Never-Hire-a-Cheap-Web-Design-Company
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:37 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:01:38 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\dwm\application\controllers\Pages.php 17
ERROR - 2020-05-01 17:01:38 --> Severity: Warning --> Use of undefined constant views - assumed 'views' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\dwm\application\views\template\head.php 51
ERROR - 2020-05-01 17:01:38 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:01:38 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:04:13 --> Severity: error --> Exception: syntax error, unexpected '$view' (T_VARIABLE), expecting ')' C:\xampp\htdocs\dwm\application\controllers\Pages.php 16
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:39 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 7
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 7
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 12
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 12
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 106
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 106
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 113
ERROR - 2020-05-01 17:04:40 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 113
ERROR - 2020-05-01 17:04:40 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-01 17:04:40 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:04:40 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:04:40 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 7
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 7
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 12
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 12
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 106
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 106
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 113
ERROR - 2020-05-01 17:05:25 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 113
ERROR - 2020-05-01 17:05:25 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-01 17:05:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:42 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 94
ERROR - 2020-05-01 17:05:42 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Never-Hire-a-Cheap-Web-Design-Company.php 94
ERROR - 2020-05-01 17:05:42 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-01 17:05:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:05:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:10:29 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:10:29 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-01 17:10:29 --> 404 Page Not Found: Blogs/assets
