<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-22 05:16:29 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-22 08:48:37 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-22 10:56:28 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-22 12:00:05 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-22 12:38:56 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-22 13:35:47 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-22 13:47:53 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-22 14:05:01 --> 404 Page Not Found: Assets/img
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-22 15:30:05 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-22 15:57:30 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-22 15:58:15 --> 404 Page Not Found: Blogs/assets
