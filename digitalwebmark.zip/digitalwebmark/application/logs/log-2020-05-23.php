<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-23 00:09:16 --> 404 Page Not Found: Img/services
ERROR - 2020-05-23 02:50:21 --> 404 Page Not Found: Img/services
ERROR - 2020-05-23 07:26:45 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-23 09:57:04 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-23 21:25:15 --> 404 Page Not Found: Vendor/phpunit
