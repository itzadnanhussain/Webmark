<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-15 01:50:45 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-15 06:34:16 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-15 10:21:42 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-08-15 10:21:46 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-08-15 10:21:47 --> 404 Page Not Found: Admin/index.php
ERROR - 2020-08-15 12:36:12 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-15 16:34:58 --> 404 Page Not Found: Wp-includes/css
ERROR - 2020-08-15 16:35:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-15 16:35:05 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2020-08-15 16:35:07 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-15 16:35:10 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-08-15 16:35:11 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-08-15 16:35:12 --> 404 Page Not Found: Demo/vendor
