<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 01:30:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-10 06:39:52 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-10 07:38:38 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-10 08:10:42 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-10 08:11:25 --> 404 Page Not Found: Blogs/php
ERROR - 2020-09-10 08:23:22 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-10 09:45:06 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2020-09-10 09:45:06 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-09-10 09:45:06 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Wp2/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Wp3/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Wp4/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Wp5/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2020-09-10 09:45:07 --> 404 Page Not Found: Example/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: Ex/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: En/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: Es/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: Admin/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: Oldsite/wp-admin
ERROR - 2020-09-10 09:45:08 --> 404 Page Not Found: Myblog/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Newblog/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Oldblog/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Test/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Testwp/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Testwordpress/wp-admin
ERROR - 2020-09-10 09:45:09 --> 404 Page Not Found: Site/wp-admin
ERROR - 2020-09-10 09:45:10 --> 404 Page Not Found: New/wp-admin
ERROR - 2020-09-10 09:45:10 --> 404 Page Not Found: Old/wp-admin
ERROR - 2020-09-10 09:45:10 --> 404 Page Not Found: Main/wp-admin
ERROR - 2020-09-10 09:45:10 --> 404 Page Not Found: Try/wp-admin
ERROR - 2020-09-10 09:45:10 --> 404 Page Not Found: Fortest/wp-admin
ERROR - 2020-09-10 11:00:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-10 12:50:52 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-10 12:59:11 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-10 17:45:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-09-10 17:45:06 --> Unable to connect to the database
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Administrator/help
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Administrator/language
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Plugins/system
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Admin/view
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Admin/includes
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Images/editor
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-10 18:06:52 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-09-10 20:14:50 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-10 20:51:20 --> 404 Page Not Found: User/popupSendEmail
