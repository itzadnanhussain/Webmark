<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-16 08:27:49 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-16 16:29:44 --> 404 Page Not Found: Img/why-us
ERROR - 2020-08-16 19:50:39 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-08-16 19:50:39 --> 404 Page Not Found: Storage/.env
ERROR - 2020-08-16 19:50:39 --> 404 Page Not Found: Public/.env
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-16 23:37:50 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
