<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-10 01:10:36 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-10 04:37:43 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-10 07:15:40 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-10 08:04:05 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-10 08:20:52 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-10 08:21:08 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-10 08:21:30 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-10 08:23:23 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-10 13:00:55 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-10 13:01:02 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-10 13:19:07 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-10 13:19:11 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-10 13:19:17 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-10 13:19:21 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-10 13:19:25 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-10 13:19:31 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-10 13:19:36 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-10 13:19:39 --> 404 Page Not Found: System/.env
ERROR - 2020-06-10 13:19:43 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-10 13:19:46 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-10 14:18:53 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-10 15:42:14 --> 404 Page Not Found: Api/vendor
ERROR - 2020-06-10 23:14:31 --> 404 Page Not Found: Modules/handle-key
