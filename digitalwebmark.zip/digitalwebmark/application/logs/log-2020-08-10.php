<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-10 02:13:37 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-10 04:14:53 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-10 04:59:11 --> 404 Page Not Found: Test/vendor
ERROR - 2020-08-10 07:00:40 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-08-10 08:16:42 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-08-10 15:13:33 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-10 16:31:13 --> 404 Page Not Found: Test/vendor
ERROR - 2020-08-10 21:24:42 --> 404 Page Not Found: Img/services-title
ERROR - 2020-08-10 21:57:04 --> 404 Page Not Found: Well-known/assetlinks.json
