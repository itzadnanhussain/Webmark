<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-12 03:27:01 --> 404 Page Not Found: Modules/handle-swal-dom
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-12 09:34:02 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-12 10:23:28 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-12 11:46:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-12 13:11:09 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-12 13:18:45 --> 404 Page Not Found: Test/vendor
ERROR - 2020-06-12 15:59:59 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-12 17:09:33 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-12 22:51:31 --> 404 Page Not Found: 2019/wp-login.php
