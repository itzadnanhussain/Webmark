<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:56:23 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:56:24 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 07:56:24 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 07:56:24 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:57:20 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 07:58:48 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 07:58:48 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 07:58:48 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:00:05 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:00:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:00:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:00:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:00:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:00:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:03:46 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:08:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:08:30 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:09:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:13 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:09:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 7
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 7
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 12
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 12
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 82
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 82
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 89
ERROR - 2020-05-02 08:09:16 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 89
ERROR - 2020-05-02 08:09:16 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:09:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:09:18 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:09:18 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:09:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:21 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\7-Best-Online-Shopping-Websites-in-Dubai.php 23
ERROR - 2020-05-02 08:09:21 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\7-Best-Online-Shopping-Websites-in-Dubai.php 23
ERROR - 2020-05-02 08:09:21 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:09:21 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:21 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:09:21 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:45 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 7
ERROR - 2020-05-02 08:10:45 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 7
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 12
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 12
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 40
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 40
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 119
ERROR - 2020-05-02 08:10:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 119
ERROR - 2020-05-02 08:10:46 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:10:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 39
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 39
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 74
ERROR - 2020-05-02 08:10:47 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 74
ERROR - 2020-05-02 08:10:48 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:48 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:48 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 7
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 7
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 12
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 12
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 39
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 39
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 137
ERROR - 2020-05-02 08:10:49 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 137
ERROR - 2020-05-02 08:10:49 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:10:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 7
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 7
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 12
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 12
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 82
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 82
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 89
ERROR - 2020-05-02 08:10:54 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Five-signs-of-Impressive-Web-Design.php 89
ERROR - 2020-05-02 08:10:54 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:10:54 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:54 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:10:54 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:12:25 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:12:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:12:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:12:25 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:12:26 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-02 08:12:39 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-02 08:13:05 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:13:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:08 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:13:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:41 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:13:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:43 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:13:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:56 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:13:56 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:56 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:13:57 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:39 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:39 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:39 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:14:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:14:46 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:14:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:14:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:16:13 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:16:13 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:16:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 7
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 12
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 39
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:16:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 105
ERROR - 2020-05-02 08:16:15 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:16:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:16:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:17:42 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:17:42 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:17:42 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:17:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:17:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:17:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:23 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:18:23 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:18:23 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:18:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:34 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:18:34 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:18:34 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:34 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:34 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:18:34 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:06 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:19:06 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:19:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:18 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:19:18 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:19:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:19:18 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:13 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:31:13 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\14-Stunning-Restaurant-Websites-Design-Inspiration.php 27
ERROR - 2020-05-02 08:31:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:31:40 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-02 08:32:01 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:01 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:01 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:13 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\7-Best-Online-Shopping-Websites-in-Dubai.php 23
ERROR - 2020-05-02 08:32:13 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\7-Best-Online-Shopping-Websites-in-Dubai.php 23
ERROR - 2020-05-02 08:32:13 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:32:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:32:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:03 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:33:03 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:03 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:04 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:42 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:33:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:42 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:43 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:33:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:33:46 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:33:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:33:46 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:02 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:34:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:13 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:34:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:53 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:54 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:34:54 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:36:50 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:36:50 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:36:50 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:37:23 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:37:23 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:37:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:37:28 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:37:28 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:37:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:37:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 7
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 12
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 33
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:38:11 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Domain-Selling-Websites-in-Dubai.php 71
ERROR - 2020-05-02 08:38:11 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:38:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:38:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:38:11 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:40:35 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:40:35 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:40:35 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:40:35 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:04 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:42:04 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:04 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:04 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:19 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:42:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:45 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:45 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:45 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:55 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 28
ERROR - 2020-05-02 08:42:55 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 28
ERROR - 2020-05-02 08:42:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:42:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:07 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:07 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:07 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:26 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 28
ERROR - 2020-05-02 08:43:26 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.php 28
ERROR - 2020-05-02 08:43:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:26 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:43:41 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 39
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 39
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 74
ERROR - 2020-05-02 08:44:02 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 74
ERROR - 2020-05-02 08:44:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:02 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:31 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:44:32 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 8
ERROR - 2020-05-02 08:44:32 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:44:32 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 13
ERROR - 2020-05-02 08:44:32 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 75
ERROR - 2020-05-02 08:44:32 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-4-low-cast-airlines-websites-in-Dubai.php 75
ERROR - 2020-05-02 08:44:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:44:32 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:45:10 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:45:10 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:45:10 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:12 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:46:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:28 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:46:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:52 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 08:46:52 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:52 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:46:52 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:47:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:47:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:47:55 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 7
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 7
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 12
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 12
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 39
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 39
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 137
ERROR - 2020-05-02 08:48:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 137
ERROR - 2020-05-02 08:48:16 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:48:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:38 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 27
ERROR - 2020-05-02 08:48:38 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 27
ERROR - 2020-05-02 08:48:38 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-02 08:48:38 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:38 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:48:39 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:36 --> Severity: Warning --> include(php/form.php): failed to open stream: No such file or directory C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 27
ERROR - 2020-05-02 08:49:36 --> Severity: Warning --> include(): Failed opening 'php/form.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\dwm\application\views\blogs\Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.php 27
ERROR - 2020-05-02 08:49:36 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:36 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:36 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:49:51 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:51:33 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:51:33 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 08:51:33 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:00:31 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:00:31 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:00:31 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:00:39 --> 404 Page Not Found: Ass%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20ets/img
ERROR - 2020-05-02 09:04:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:04:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:04:16 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:05:06 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-02 09:08:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:08:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:08:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:08:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:08:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:08:49 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-02 09:26:46 --> 404 Page Not Found: Php/popupSendEmail.php
ERROR - 2020-05-02 10:05:18 --> Severity: Notice --> Undefined property: User::$form_validation C:\xampp\htdocs\dwm\application\controllers\User.php 10
ERROR - 2020-05-02 10:05:18 --> Severity: error --> Exception: Call to a member function set_rules() on null C:\xampp\htdocs\dwm\application\controllers\User.php 10
ERROR - 2020-05-02 10:06:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\dwm\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-05-02 10:06:47 --> Unable to connect to the database
ERROR - 2020-05-02 10:07:04 --> Severity: Notice --> Undefined variable: phone C:\xampp\htdocs\dwm\application\controllers\User.php 27
ERROR - 2020-05-02 10:07:06 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 10:08:05 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 10:09:55 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 11:30:54 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 11:35:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 11:37:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 11:37:17 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\dwm\application\controllers\User.php 28
ERROR - 2020-05-02 10:08:52 --> 404 Page Not Found: Git/HEAD
