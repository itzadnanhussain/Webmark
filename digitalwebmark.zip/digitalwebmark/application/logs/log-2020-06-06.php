<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-06 01:21:13 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-06 08:55:44 --> 404 Page Not Found: Blogs/blogs
