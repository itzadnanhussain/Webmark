<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-20 01:07:06 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-20 01:07:12 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-20 01:07:29 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-20 01:07:35 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-20 01:09:17 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-07-20 01:53:08 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-20 02:52:50 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-20 04:32:04 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-20 04:40:47 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-20 05:23:35 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-20 11:52:56 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-20 11:53:01 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-20 11:53:06 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-20 11:53:10 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-20 11:53:16 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-20 11:53:20 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-20 11:53:25 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-20 11:53:30 --> 404 Page Not Found: System/.env
ERROR - 2020-07-20 11:53:35 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-20 11:53:41 --> 404 Page Not Found: Shop/.env
ERROR - 2020-07-20 13:58:55 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Administrator/help
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Administrator/language
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Plugins/system
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Admin/view
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Admin/includes
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Images/editor
ERROR - 2020-07-20 13:58:56 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-07-20 20:47:17 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-20 23:06:06 --> 404 Page Not Found: Img/why-us
