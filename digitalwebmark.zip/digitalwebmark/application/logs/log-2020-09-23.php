<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-23 01:10:54 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-23 01:38:23 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-23 02:44:11 --> 404 Page Not Found: Blogs/php
ERROR - 2020-09-23 07:16:28 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-23 08:45:14 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-23 09:40:00 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:37:54 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-23 11:40:26 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-23 11:40:28 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-23 11:51:09 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:51:18 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:51:46 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:54:22 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:54:46 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:55:27 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:55:48 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:55:58 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:56:32 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:58:04 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 11:58:26 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 12:10:42 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 12:10:51 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 12:33:54 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 12:41:22 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-23 13:50:06 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 14:52:56 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 15:52:04 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 15:59:51 --> 404 Page Not Found: Admin/.env
ERROR - 2020-09-23 15:59:52 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-23 15:59:52 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-23 15:59:52 --> 404 Page Not Found: V1/.env
ERROR - 2020-09-23 15:59:52 --> 404 Page Not Found: App/.env
ERROR - 2020-09-23 15:59:53 --> 404 Page Not Found: Config/.env
ERROR - 2020-09-23 15:59:53 --> 404 Page Not Found: Core/.env
ERROR - 2020-09-23 15:59:53 --> 404 Page Not Found: Apps/.env
ERROR - 2020-09-23 15:59:53 --> 404 Page Not Found: Lib/.env
ERROR - 2020-09-23 15:59:54 --> 404 Page Not Found: Cron/.env
ERROR - 2020-09-23 15:59:54 --> 404 Page Not Found: Database/.env
ERROR - 2020-09-23 15:59:55 --> 404 Page Not Found: Uploads/.env
ERROR - 2020-09-23 15:59:55 --> 404 Page Not Found: Site/.env
ERROR - 2020-09-23 15:59:55 --> 404 Page Not Found: Web/.env
ERROR - 2020-09-23 15:59:56 --> 404 Page Not Found: Administrator/.env
ERROR - 2020-09-23 17:31:59 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 17:32:10 --> 404 Page Not Found: User/register
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 20:06:01 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-23 22:49:04 --> 404 Page Not Found: User/popupSendEmail
