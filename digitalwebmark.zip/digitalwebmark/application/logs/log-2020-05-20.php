<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-20 01:19:06 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-20 01:19:06 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-20 01:19:06 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-20 01:19:07 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-20 02:12:24 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-20 02:12:27 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 02:12:42 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 02:12:47 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 02:13:54 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 05:36:06 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-20 06:22:03 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-20 09:04:33 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-20 12:15:09 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-20 12:15:10 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-20 12:15:10 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-20 12:15:10 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-20 12:15:10 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-20 12:15:10 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-20 12:15:11 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-20 12:15:11 --> 404 Page Not Found: System/.env
ERROR - 2020-05-20 12:15:11 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-20 12:15:11 --> 404 Page Not Found: Shop/.env
ERROR - 2020-05-20 12:57:28 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-20 16:50:58 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-20 21:26:41 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-20 21:26:41 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-20 21:26:42 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-20 21:26:42 --> 404 Page Not Found: Phpmyadmin/scripts
