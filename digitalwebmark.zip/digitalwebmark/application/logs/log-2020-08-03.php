<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-03 00:42:32 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-08-03 00:42:37 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-08-03 00:42:38 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-08-03 00:42:39 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-08-03 00:42:40 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-08-03 00:42:41 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-08-03 00:42:42 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-08-03 00:42:42 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-08-03 00:42:43 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-08-03 00:42:44 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-08-03 00:42:45 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-08-03 00:42:45 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-08-03 00:42:46 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-08-03 00:42:47 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-08-03 00:42:48 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-08-03 00:42:49 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-08-03 00:42:50 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-08-03 07:57:44 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-08-03 10:14:54 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-03 19:23:16 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
