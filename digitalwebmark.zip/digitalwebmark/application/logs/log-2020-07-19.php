<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-19 00:51:32 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-19 01:47:15 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-19 02:15:57 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-07-19 11:25:56 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-19 12:35:57 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-07-19 23:35:20 --> 404 Page Not Found: Img/services-title
