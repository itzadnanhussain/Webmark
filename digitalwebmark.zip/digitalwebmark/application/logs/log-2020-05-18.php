<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-18 02:22:16 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-18 02:22:16 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-18 02:22:17 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-18 02:22:17 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2020-05-18 02:32:59 --> 404 Page Not Found: Img/services
ERROR - 2020-05-18 22:35:09 --> 404 Page Not Found: Img/services
