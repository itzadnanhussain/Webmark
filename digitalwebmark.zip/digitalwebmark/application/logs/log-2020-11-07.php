<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-07 12:24:38 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\digitalwebmark\application\helpers\query_helper.php 57
ERROR - 2020-11-07 12:24:38 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\digitalwebmark\application\helpers\query_helper.php 57
ERROR - 2020-11-07 12:25:53 --> Severity: Notice --> Undefined offset: 0 E:\xampp\htdocs\digitalwebmark\application\helpers\query_helper.php 57
ERROR - 2020-11-07 12:25:53 --> Severity: Notice --> Undefined offset: 1 E:\xampp\htdocs\digitalwebmark\application\helpers\query_helper.php 57
ERROR - 2020-11-07 12:50:20 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 12:56:24 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 7
ERROR - 2020-11-07 12:58:11 --> Query error: Table 'digitalwebmark.applicants' doesn't exist - Invalid query: SELECT *
FROM `applicants`
WHERE `id` = '21'
ERROR - 2020-11-07 12:58:41 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 12:58:41 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 12:58:41 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 12:59:07 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 12:59:24 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 12:59:24 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 12:59:24 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 13:00:28 --> 404 Page Not Found: Careers/bootstrap.js.map
ERROR - 2020-11-07 13:00:59 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 13:02:24 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 13:02:25 --> 404 Page Not Found: Careers/bootstrap.js.map
ERROR - 2020-11-07 13:02:25 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 13:02:44 --> 404 Page Not Found: Careers/careers
ERROR - 2020-11-07 13:02:56 --> 404 Page Not Found: Careers/assets
ERROR - 2020-11-07 13:03:34 --> 404 Page Not Found: Career/assets
ERROR - 2020-11-07 13:03:34 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:03:34 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:03:47 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:03:56 --> 404 Page Not Found: Career/assets
ERROR - 2020-11-07 13:04:12 --> 404 Page Not Found: Career/assets
ERROR - 2020-11-07 13:04:13 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:13 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:13 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:29 --> 404 Page Not Found: Career/assets
ERROR - 2020-11-07 13:04:29 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:29 --> 404 Page Not Found: Career/assets
ERROR - 2020-11-07 13:04:29 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:29 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:04:30 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:05:14 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:05:14 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:05:14 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:07:52 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:07:52 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:08:00 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:21 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:21 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:21 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:56 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:56 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:09:56 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:14:59 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:14:59 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:14:59 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:15:32 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:15:32 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:15:32 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:15:40 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:15:40 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:36:41 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:36:41 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:45:56 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:45:56 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:46:43 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 13:46:43 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:18:01 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:18:02 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:19:37 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:19:37 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:20:52 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:20:52 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:21:01 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:21:01 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:21:13 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:21:13 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:38:35 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-07 14:38:35 --> 404 Page Not Found: Career/clients
