<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-05 01:25:26 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-08-05 01:47:05 --> 404 Page Not Found: Modules/utils
ERROR - 2020-08-05 04:27:07 --> 404 Page Not Found: Img/blog
ERROR - 2020-08-05 04:52:43 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-05 09:19:43 --> 404 Page Not Found: Img/blog
ERROR - 2020-08-05 15:43:28 --> 404 Page Not Found: Modules/handle-click
ERROR - 2020-08-05 16:39:41 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-05 18:18:13 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-05 18:43:23 --> 404 Page Not Found: Admin/login.html
ERROR - 2020-08-05 18:43:24 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-08-05 22:28:33 --> 404 Page Not Found: Vendor/phpunit
