<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-07 09:28:28 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-07 10:54:42 --> 404 Page Not Found: Img/About-Company
