<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 02:25:19 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-13 05:21:40 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-05-13 15:48:17 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-13 21:48:27 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2020-05-13 21:48:27 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2020-05-13 22:20:40 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-13 23:12:42 --> 404 Page Not Found: Img/About-Company
