<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-11 02:14:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-11 06:25:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-11 06:56:49 --> 404 Page Not Found: Blogs/php
ERROR - 2020-06-11 17:32:52 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-11 17:33:14 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-11 17:33:19 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-11 17:33:27 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-11 17:33:32 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-11 17:33:41 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-11 17:34:02 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-11 17:34:21 --> 404 Page Not Found: System/.env
ERROR - 2020-06-11 17:34:38 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-11 17:34:43 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-11 18:31:19 --> 404 Page Not Found: Modules/handle-dom
ERROR - 2020-06-11 18:47:31 --> 404 Page Not Found: Modules/handle-key
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-11 18:59:50 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-06-11 19:05:57 --> 404 Page Not Found: Modules/handle-click
ERROR - 2020-06-11 19:10:37 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2020-06-11 19:44:44 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-11 19:44:45 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-11 19:44:45 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-11 19:44:46 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-11 19:44:47 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-11 19:44:49 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-11 19:44:50 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-11 19:45:03 --> 404 Page Not Found: System/.env
ERROR - 2020-06-11 19:45:05 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-11 19:45:06 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-11 20:37:25 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-11 20:37:39 --> 404 Page Not Found: Api/vendor
ERROR - 2020-06-11 20:37:50 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-11 20:38:14 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-06-11 20:38:30 --> 404 Page Not Found: Sites/all
ERROR - 2020-06-11 20:38:47 --> 404 Page Not Found: Test/vendor
ERROR - 2020-06-11 20:39:03 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-11 20:39:18 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-06-11 20:39:38 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-06-11 20:39:53 --> 404 Page Not Found: System/vendor
ERROR - 2020-06-11 20:40:59 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-06-11 20:41:16 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-06-11 20:41:27 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-11 22:18:23 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2020-06-11 23:20:48 --> 404 Page Not Found: Well-known/assetlinks.json
