<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-26 00:59:41 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-26 01:30:39 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-26 02:06:09 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-26 02:33:48 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-26 02:51:25 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-26 03:05:31 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-07-26 04:05:11 --> 404 Page Not Found: Blogs/php
ERROR - 2020-07-26 04:54:03 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-26 06:48:25 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-26 06:48:29 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-26 07:58:41 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-26 09:12:31 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-26 09:21:10 --> 404 Page Not Found: Img/digitalwebmark.png
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-26 14:40:50 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-26 17:40:44 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-07-26 18:59:54 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-26 18:59:57 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-26 19:00:00 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-26 19:00:03 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-26 19:00:06 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-26 19:00:09 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-26 19:00:12 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-26 19:00:15 --> 404 Page Not Found: System/.env
ERROR - 2020-07-26 19:00:18 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-26 19:00:21 --> 404 Page Not Found: Shop/.env
ERROR - 2020-07-26 23:46:56 --> 404 Page Not Found: Wp-json/wp
