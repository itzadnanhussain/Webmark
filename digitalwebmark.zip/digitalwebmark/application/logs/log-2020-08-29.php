<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-29 00:49:10 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-08-29 00:49:10 --> 404 Page Not Found: Storage/.env
ERROR - 2020-08-29 00:49:11 --> 404 Page Not Found: Public/.env
ERROR - 2020-08-29 00:50:17 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-29 01:29:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-29 05:16:20 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-29 09:00:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-29 11:22:30 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-29 13:16:59 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-29 16:03:28 --> 404 Page Not Found: Assets/img
ERROR - 2020-08-29 20:41:52 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-29 20:42:21 --> 404 Page Not Found: Vendor/phpunit
