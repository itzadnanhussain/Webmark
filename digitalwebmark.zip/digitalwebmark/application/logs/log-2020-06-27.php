<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 17:14:38 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-27 21:20:21 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-06-27 21:20:21 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-06-27 21:20:21 --> 404 Page Not Found: Wordpress/wp-admin
