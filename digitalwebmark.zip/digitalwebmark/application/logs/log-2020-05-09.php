<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 00:01:16 --> 404 Page Not Found: XuQsQgelhJsfL3xgcY/f5Vr2hYo392sid1y
ERROR - 2020-05-09 00:01:21 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-09 01:02:40 --> 404 Page Not Found: Admin/view
ERROR - 2020-05-09 01:10:38 --> 404 Page Not Found: Admin/view
ERROR - 2020-05-09 06:08:45 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-09 06:08:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-09 06:08:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-09 06:08:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-09 06:08:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-09 06:08:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-09 06:09:17 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-09 10:30:11 --> 404 Page Not Found: Dialer/index.php
ERROR - 2020-05-09 10:30:16 --> 404 Page Not Found: Dialer/index.html
ERROR - 2020-05-09 13:04:12 --> 404 Page Not Found: Admin/view
ERROR - 2020-05-09 17:22:44 --> 404 Page Not Found: Phpmyadmin/index.php
