<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-07 04:45:38 --> 404 Page Not Found: __media__/js
ERROR - 2020-06-07 07:17:55 --> 404 Page Not Found: Demo/vendor
ERROR - 2020-06-07 11:55:18 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-07 20:19:30 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-07 20:19:31 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-07 20:19:31 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-07 20:19:32 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-07 20:19:33 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-07 20:19:34 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-07 20:19:34 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-07 20:19:35 --> 404 Page Not Found: System/.env
ERROR - 2020-06-07 20:19:35 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-07 20:19:36 --> 404 Page Not Found: Shop/.env
