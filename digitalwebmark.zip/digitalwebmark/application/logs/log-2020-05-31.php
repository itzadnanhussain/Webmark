<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-31 01:51:35 --> 404 Page Not Found: Img/services
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-31 08:44:59 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-31 16:22:42 --> 404 Page Not Found: Aboutus/social
ERROR - 2020-05-31 16:22:55 --> 404 Page Not Found: Aboutus/social
ERROR - 2020-05-31 16:23:09 --> 404 Page Not Found: Aboutus/social
ERROR - 2020-05-31 16:23:14 --> 404 Page Not Found: Aboutus/social
ERROR - 2020-05-31 16:23:19 --> 404 Page Not Found: Aboutus/social
ERROR - 2020-05-31 16:23:27 --> 404 Page Not Found: Web/index.php
ERROR - 2020-05-31 16:23:31 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:23:35 --> 404 Page Not Found: K2-portfolio/electrical-and-mechanical-installation
ERROR - 2020-05-31 16:23:42 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:23:49 --> 404 Page Not Found: K2-portfolio/electrical-mechanical-materials-supply-and-installation
ERROR - 2020-05-31 16:23:52 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:23:58 --> 404 Page Not Found: K2-portfolio/electrical-mechanical-material-s-supply-and-installation-partition-work
ERROR - 2020-05-31 16:24:08 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:24:21 --> 404 Page Not Found: K2-portfolio/supply-of-earthing-materials
ERROR - 2020-05-31 16:24:30 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:24:35 --> 404 Page Not Found: K2-portfolio/electrical-wire-and-panel-board-supply-and-installation
ERROR - 2020-05-31 16:24:38 --> 404 Page Not Found: Media/k2
ERROR - 2020-05-31 16:24:43 --> 404 Page Not Found: K2-portfolio/electrical-mechanical-material-s-supply-and-installation-partition-work-2
ERROR - 2020-05-31 16:24:46 --> 404 Page Not Found: Component/k2
ERROR - 2020-05-31 16:24:54 --> 404 Page Not Found: Component/k2
ERROR - 2020-05-31 16:24:59 --> 404 Page Not Found: Component/k2
ERROR - 2020-05-31 16:25:03 --> 404 Page Not Found: Component/k2
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-31 16:28:09 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-31 16:28:21 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-31 16:32:38 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-31 17:57:39 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-05-31 18:04:29 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-05-31 18:04:29 --> 404 Page Not Found: Administrator/help
ERROR - 2020-05-31 18:04:30 --> 404 Page Not Found: Administrator/language
ERROR - 2020-05-31 18:04:30 --> 404 Page Not Found: Plugins/system
ERROR - 2020-05-31 18:04:31 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-05-31 18:04:32 --> 404 Page Not Found: Admin/view
ERROR - 2020-05-31 18:04:32 --> 404 Page Not Found: Admin/includes
ERROR - 2020-05-31 18:04:33 --> 404 Page Not Found: Images/editor
ERROR - 2020-05-31 18:04:33 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-05-31 18:04:33 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-31 18:04:34 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-05-31 18:04:38 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2020-05-31 18:04:38 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-05-31 18:04:38 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2020-05-31 18:04:39 --> 404 Page Not Found: Blog/wp-admin
ERROR - 2020-05-31 18:04:39 --> 404 Page Not Found: Test/wp-admin
ERROR - 2020-05-31 18:04:39 --> 404 Page Not Found: Site/wp-admin
