<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-12 00:50:17 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-12 01:02:36 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-12 02:58:02 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-12 03:35:53 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-12 06:09:27 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-12 07:54:14 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-12 08:31:32 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-12 08:31:32 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-12 08:31:34 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-12 09:14:20 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-12 09:43:44 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-12 09:52:31 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-12 10:35:06 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-12 11:12:58 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-12 11:22:15 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-12 11:36:33 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-12 14:57:11 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-07-12 15:27:27 --> 404 Page Not Found: Admin/login
ERROR - 2020-07-12 16:01:55 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-12 17:16:26 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-12 17:23:08 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-12 17:28:07 --> 404 Page Not Found: Img/blog
