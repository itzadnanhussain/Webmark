<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-21 17:48:34 --> Severity: error --> Exception: Call to undefined function print_data() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 9
ERROR - 2020-10-21 18:03:13 --> 404 Page Not Found: Uploads/Jatesh_Kumar1591503210.pdf
ERROR - 2020-10-21 18:12:08 --> 404 Page Not Found: Uploads/Jatesh_Kumar1591503210.pdf
ERROR - 2020-10-21 18:21:31 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:21:35 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:21:45 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:21:50 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:21:58 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:22:05 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:22:07 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:22:08 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:24:43 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:24:45 --> Severity: Warning --> readfile(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 90
ERROR - 2020-10-21 18:26:36 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:26:39 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:27:15 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Muhammad_Arshad1592839140.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:27:17 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Muhammad_Arshad1592839140.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:27:21 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:27:23 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
ERROR - 2020-10-21 18:28:13 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 91
