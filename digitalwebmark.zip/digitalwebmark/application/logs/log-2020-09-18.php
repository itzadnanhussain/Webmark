<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-18 00:55:34 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-09-18 00:56:26 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-09-18 00:57:07 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-09-18 00:57:43 --> 404 Page Not Found: Old/wp-includes
ERROR - 2020-09-18 00:58:00 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-09-18 00:58:15 --> 404 Page Not Found: Backup/wp-includes
ERROR - 2020-09-18 00:58:33 --> 404 Page Not Found: En/wp-includes
ERROR - 2020-09-18 01:00:10 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-09-18 01:02:38 --> 404 Page Not Found: Www/wp-includes
ERROR - 2020-09-18 01:02:53 --> 404 Page Not Found: Staging/wp-includes
ERROR - 2020-09-18 01:03:32 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-09-18 01:04:47 --> 404 Page Not Found: Main/wp-includes
ERROR - 2020-09-18 01:06:16 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-09-18 01:06:28 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-09-18 01:06:43 --> 404 Page Not Found: V1/wp-includes
ERROR - 2020-09-18 01:06:58 --> 404 Page Not Found: 1/wp-includes
ERROR - 2020-09-18 01:07:14 --> 404 Page Not Found: Store/wp-includes
ERROR - 2020-09-18 01:08:17 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-09-18 04:58:00 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-18 05:08:37 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-18 06:50:10 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-18 08:02:53 --> 404 Page Not Found: Bank/user
ERROR - 2020-09-18 08:15:42 --> 404 Page Not Found: Bank/user
ERROR - 2020-09-18 08:53:56 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-18 15:27:25 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-18 17:45:24 --> 404 Page Not Found: Blogs/blogs
