<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-23 00:15:27 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 01:30:29 --> 404 Page Not Found: Js/admin.js
ERROR - 2020-08-23 04:25:34 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-23 05:41:03 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-23 05:41:23 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-23 05:41:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:41:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:41:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:41:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:41:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:42:00 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:42:01 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:42:01 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:42:01 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 05:42:01 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 06:54:02 --> 404 Page Not Found: Blogs/img
ERROR - 2020-08-23 06:54:12 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-08-23 06:54:18 --> 404 Page Not Found: Blogs/img
ERROR - 2020-08-23 06:54:21 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-23 06:54:25 --> 404 Page Not Found: Assets/img
ERROR - 2020-08-23 06:54:30 --> 404 Page Not Found: Blogs/img
ERROR - 2020-08-23 06:54:36 --> 404 Page Not Found: Blogs/img
ERROR - 2020-08-23 06:54:39 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-23 06:54:43 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-08-23 06:54:56 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-23 06:55:19 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-23 09:04:30 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-23 18:19:42 --> 404 Page Not Found: Core/.env
ERROR - 2020-08-23 18:19:57 --> 404 Page Not Found: App/.env
ERROR - 2020-08-23 18:21:00 --> 404 Page Not Found: Vendor/laravel
ERROR - 2020-08-23 22:08:40 --> 404 Page Not Found: Img/why-us
ERROR - 2020-08-23 22:26:20 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-23 22:27:10 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-23 23:34:22 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-23 23:55:13 --> 404 Page Not Found: E/data
