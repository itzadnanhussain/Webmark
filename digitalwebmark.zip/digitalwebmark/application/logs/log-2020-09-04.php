<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-04 02:40:24 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-04 08:42:57 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-04 09:05:01 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-09-04 09:05:01 --> 404 Page Not Found: Administrator/help
ERROR - 2020-09-04 09:05:01 --> 404 Page Not Found: Administrator/language
ERROR - 2020-09-04 09:05:02 --> 404 Page Not Found: Plugins/system
ERROR - 2020-09-04 09:05:02 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-09-04 09:05:03 --> 404 Page Not Found: Admin/view
ERROR - 2020-09-04 09:05:03 --> 404 Page Not Found: Admin/includes
ERROR - 2020-09-04 09:05:03 --> 404 Page Not Found: Images/editor
ERROR - 2020-09-04 09:05:04 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-09-04 09:05:04 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-04 09:05:04 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2020-09-04 09:40:42 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-04 13:07:42 --> 404 Page Not Found: Assets/img
ERROR - 2020-09-04 16:24:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-04 16:24:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-04 16:25:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-04 16:25:32 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-04 19:19:55 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-04 20:12:06 --> 404 Page Not Found: Img/About-Company
