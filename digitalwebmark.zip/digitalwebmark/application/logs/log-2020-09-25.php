<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-25 04:33:24 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-25 05:22:12 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-25 06:49:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-25 06:49:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-25 11:09:25 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-25 11:41:06 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-25 15:38:07 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-25 16:00:43 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-25 18:29:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'usman'@'localhost' (using password: YES) E:\xampp\htdocs\webmark\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-25 18:29:30 --> Unable to connect to the database
ERROR - 2020-09-25 18:30:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'digitalwebmarkdb' E:\xampp\htdocs\webmark\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-25 18:30:01 --> Unable to connect to the database
ERROR - 2020-09-25 18:30:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'digitalwebmarkdb' E:\xampp\htdocs\webmark\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-09-25 18:30:04 --> Unable to connect to the database
ERROR - 2020-09-25 19:09:21 --> Severity: error --> Exception: Call to undefined function print_data() E:\xampp\htdocs\digitalwebmark\application\controllers\Pages.php 22
ERROR - 2020-09-25 19:17:44 --> Severity: error --> Exception: Call to undefined function Pageview() E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 17
ERROR - 2020-09-25 19:22:10 --> Severity: error --> Exception: Call to undefined function Pageview() E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 18
ERROR - 2020-09-25 19:26:09 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 7
ERROR - 2020-09-25 19:27:03 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 7
ERROR - 2020-09-25 19:27:06 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 7
ERROR - 2020-09-25 19:27:07 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 7
ERROR - 2020-09-25 20:08:43 --> Severity: Warning --> mkdir(): No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 34
ERROR - 2020-09-25 20:08:43 --> The upload path does not appear to be valid.
ERROR - 2020-09-25 20:09:45 --> Severity: error --> Exception: Call to undefined function GetByWhere() E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 52
ERROR - 2020-09-25 20:30:16 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\digitalwebmark\system\database\DB_driver.php 1471
ERROR - 2020-09-25 20:30:16 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `applicantstable` (`name`, `phone`, `email`, `address`, `whyhire`, `skills`, `resume_name`) VALUES ('Clarke Clark', '+1 (606) 168-9625', 'renarimy@mailinator.com', 'Fugit fugiat est d', 'Unde quis consequat', Array, 'Clarke_Clark522099851.pdf')
ERROR - 2020-09-25 20:30:30 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\digitalwebmark\system\database\DB_driver.php 1471
ERROR - 2020-09-25 20:30:30 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `applicantstable` (`name`, `phone`, `email`, `address`, `whyhire`, `skills`, `resume_name`) VALUES ('Clarke Clark', '+1 (606) 168-9625', 'renarimy@mailinator.com', 'Fugit fugiat est d', 'Unde quis consequat', Array, 'Clarke_Clark2059765226.pdf')
ERROR - 2020-09-25 20:40:41 --> Severity: Notice --> Undefined index: html E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 24
ERROR - 2020-09-25 20:40:41 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\digitalwebmark\system\database\DB_driver.php 1471
ERROR - 2020-09-25 20:40:41 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `applicantstable` (`name`, `phone`, `email`, `address`, `whyhire`, `skills`, `resume_name`) VALUES ('Iona Cleveland', '+1 (279) 555-2909', 'xacaxujawu@mailinator.com', 'Quaerat corporis vel', 'Nulla consequatur d', Array, 'Iona_Cleveland738620498.pdf')
ERROR - 2020-09-25 20:55:25 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\digitalwebmark\system\database\DB_driver.php 1471
ERROR - 2020-09-25 20:55:25 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `applicantstable` (`skills`, `name`, `phone`, `email`, `address`, `whyhire`, `resume_name`) VALUES (Array, 'Iona Cleveland', '+1 (279) 555-2909', 'xacaxujawu@mailinator.com', 'Quaerat corporis vel', 'Nulla consequatur d', 'Iona_Cleveland159610319.pdf')
ERROR - 2020-09-25 20:57:26 --> Severity: Notice --> Array to string conversion E:\xampp\htdocs\digitalwebmark\system\database\DB_driver.php 1471
ERROR - 2020-09-25 20:57:26 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `applicantstable` (`skills`, `name`, `phone`, `email`, `address`, `whyhire`, `resume_name`) VALUES (Array, 'Iona Cleveland', '+1 (279) 555-2909', 'xacaxujawu@mailinator.com', 'Quaerat corporis vel', 'Nulla consequatur d', 'Iona_Cleveland1914528099.pdf')
ERROR - 2020-09-25 21:02:59 --> Severity: Notice --> Undefined variable: js_level E:\xampp\htdocs\digitalwebmark\application\controllers\Career.php 43
