<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 04:03:14 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-03 05:41:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-03 07:12:39 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-03 07:15:03 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-03 10:27:35 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-03 10:27:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-03 18:31:38 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-09-03 18:31:39 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-09-03 18:31:40 --> 404 Page Not Found: Admin/index.php
ERROR - 2020-09-03 20:05:35 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-03 20:34:51 --> 404 Page Not Found: Php/sendemail.php
ERROR - 2020-09-03 20:34:54 --> 404 Page Not Found: Php/sendemail.php
ERROR - 2020-09-03 20:35:07 --> 404 Page Not Found: Blogs/php
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-03 22:22:46 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
