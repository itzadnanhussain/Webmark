<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-16 00:29:09 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-16 00:44:23 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-16 02:02:13 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-16 02:02:21 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-16 02:02:28 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-16 02:02:35 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-16 02:02:43 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-16 02:02:47 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-16 02:02:57 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-16 02:14:32 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-16 03:44:42 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-16 03:49:54 --> 404 Page Not Found: Img/small-img
ERROR - 2020-07-16 05:25:36 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-16 05:59:20 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-16 06:07:01 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-16 07:09:33 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-16 13:39:41 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-16 20:07:06 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2020-07-16 20:07:06 --> 404 Page Not Found: Wordpress/wp-login.php
ERROR - 2020-07-16 20:59:29 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-07-16 23:49:03 --> 404 Page Not Found: Img/blog
