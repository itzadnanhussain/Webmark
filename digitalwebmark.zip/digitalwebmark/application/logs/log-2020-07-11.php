<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-11 00:29:32 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-11 00:54:37 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-11 00:54:37 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-11 01:02:08 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-11 01:57:58 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-11 05:43:10 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-07-11 05:43:22 --> 404 Page Not Found: Api/vendor
ERROR - 2020-07-11 05:43:34 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-07-11 05:43:45 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-07-11 05:43:57 --> 404 Page Not Found: Sites/all
ERROR - 2020-07-11 05:44:08 --> 404 Page Not Found: Test/vendor
ERROR - 2020-07-11 05:44:20 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-07-11 05:44:32 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-07-11 05:44:43 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-07-11 05:44:56 --> 404 Page Not Found: System/vendor
ERROR - 2020-07-11 05:45:13 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-07-11 05:45:25 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-07-11 05:45:37 --> 404 Page Not Found: Testing/vendor
ERROR - 2020-07-11 05:45:50 --> 404 Page Not Found: Laravel/click_e_money
ERROR - 2020-07-11 05:46:02 --> 404 Page Not Found: Mahara/auth
ERROR - 2020-07-11 05:46:14 --> 404 Page Not Found: Concrete/vendor
ERROR - 2020-07-11 05:46:26 --> 404 Page Not Found: Wbs/vendor
ERROR - 2020-07-11 05:46:39 --> 404 Page Not Found: App1/_lib
ERROR - 2020-07-11 05:46:51 --> 404 Page Not Found: Wp-content/themes
ERROR - 2020-07-11 05:47:02 --> 404 Page Not Found: Proguard/vendor
ERROR - 2020-07-11 05:47:15 --> 404 Page Not Found: Mapa/vendor
ERROR - 2020-07-11 05:47:27 --> 404 Page Not Found: Cambio/vendor
ERROR - 2020-07-11 05:47:40 --> 404 Page Not Found: __MACOSX/vendor
ERROR - 2020-07-11 05:47:52 --> 404 Page Not Found: Quotation/vendor
ERROR - 2020-07-11 05:48:04 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-07-11 05:48:16 --> 404 Page Not Found: Onefolder/vendor
ERROR - 2020-07-11 05:48:28 --> 404 Page Not Found: Pro/vendor
ERROR - 2020-07-11 05:48:41 --> 404 Page Not Found: Staff/vendor
ERROR - 2020-07-11 05:48:54 --> 404 Page Not Found: Supervision/vendor
ERROR - 2020-07-11 05:49:07 --> 404 Page Not Found: Icms/vendor
ERROR - 2020-07-11 05:49:20 --> 404 Page Not Found: Services/lib
ERROR - 2020-07-11 05:49:31 --> 404 Page Not Found: Release/vendor
ERROR - 2020-07-11 05:49:43 --> 404 Page Not Found: Backend/vendor
ERROR - 2020-07-11 05:49:55 --> 404 Page Not Found: Freelance039/vendor
ERROR - 2020-07-11 05:50:07 --> 404 Page Not Found: Sistema/dompdf-master
ERROR - 2020-07-11 05:50:18 --> 404 Page Not Found: Tms/vendor
ERROR - 2020-07-11 05:50:30 --> 404 Page Not Found: Old/vendor
ERROR - 2020-07-11 05:50:43 --> 404 Page Not Found: Cnishopping/vendor
ERROR - 2020-07-11 05:50:55 --> 404 Page Not Found: Protected/vendor
ERROR - 2020-07-11 05:51:06 --> 404 Page Not Found: 2020/vendor
ERROR - 2020-07-11 05:51:17 --> 404 Page Not Found: 2019/vendor
ERROR - 2020-07-11 05:51:30 --> 404 Page Not Found: Demo/vendor
ERROR - 2020-07-11 05:51:42 --> 404 Page Not Found: Code/snippets
ERROR - 2020-07-11 05:51:54 --> 404 Page Not Found: Pp/basic
ERROR - 2020-07-11 05:52:06 --> 404 Page Not Found: Webpublic/admin
ERROR - 2020-07-11 05:52:18 --> 404 Page Not Found: Servicecommon/vendor
ERROR - 2020-07-11 05:52:29 --> 404 Page Not Found: Woodfieldestates/vendor
ERROR - 2020-07-11 05:52:41 --> 404 Page Not Found: Old_stuff/meihome
ERROR - 2020-07-11 05:52:53 --> 404 Page Not Found: Dacol/vendor
ERROR - 2020-07-11 05:53:04 --> 404 Page Not Found: Freelandadm/vendor
ERROR - 2020-07-11 05:53:17 --> 404 Page Not Found: Bank_bak/vendor
ERROR - 2020-07-11 05:53:30 --> 404 Page Not Found: Watern/vendor
ERROR - 2020-07-11 05:53:42 --> 404 Page Not Found: Test/med-decision
ERROR - 2020-07-11 05:53:55 --> 404 Page Not Found: Site/PortalEscolar
ERROR - 2020-07-11 05:54:07 --> 404 Page Not Found: Dev/vendor
ERROR - 2020-07-11 05:54:19 --> 404 Page Not Found: Admin_temp/vendor
ERROR - 2020-07-11 05:54:32 --> 404 Page Not Found: Yii/basic
ERROR - 2020-07-11 05:54:43 --> 404 Page Not Found: MyProject/vendor
ERROR - 2020-07-11 05:54:55 --> 404 Page Not Found: En/vendor
ERROR - 2020-07-11 05:55:07 --> 404 Page Not Found: Administration/vendor
ERROR - 2020-07-11 05:55:20 --> 404 Page Not Found: Google/vendor
ERROR - 2020-07-11 05:55:33 --> 404 Page Not Found: Prensaapi/vendor
ERROR - 2020-07-11 05:55:45 --> 404 Page Not Found: Assets/translation
ERROR - 2020-07-11 05:55:58 --> 404 Page Not Found: Site/vendor
ERROR - 2020-07-11 05:56:10 --> 404 Page Not Found: Assets/translation
ERROR - 2020-07-11 05:56:21 --> 404 Page Not Found: Assets/vendor
ERROR - 2020-07-11 05:56:34 --> 404 Page Not Found: Cpntest/vendor
ERROR - 2020-07-11 05:56:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-07-11 07:27:38 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-07-11 15:36:18 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-11 15:36:19 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-11 15:36:19 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-11 15:36:20 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-11 15:36:20 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-11 15:36:20 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-11 15:36:23 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-11 15:36:24 --> 404 Page Not Found: System/.env
ERROR - 2020-07-11 15:36:25 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-11 15:36:25 --> 404 Page Not Found: Shop/.env
ERROR - 2020-07-11 19:56:57 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-11 22:03:52 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-11 23:11:54 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-11 23:11:55 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-11 23:23:33 --> 404 Page Not Found: Img/services-title
