<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 05:34:57 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-17 05:47:43 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-17 07:08:58 --> 404 Page Not Found: Img/why-us
ERROR - 2020-06-17 09:46:09 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-17 11:12:40 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-17 14:08:21 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-06-17 14:08:22 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-06-17 14:08:23 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-06-17 14:18:58 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-17 15:16:16 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-17 17:23:32 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-17 17:30:07 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-17 17:30:07 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-17 17:30:07 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-17 17:30:07 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-17 17:30:08 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-17 17:30:08 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-17 17:30:09 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-17 17:30:09 --> 404 Page Not Found: System/.env
ERROR - 2020-06-17 17:30:09 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-17 17:30:10 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-17 19:05:39 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-17 19:30:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-17 19:30:05 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-17 19:37:09 --> 404 Page Not Found: Img/why-us
ERROR - 2020-06-17 20:08:20 --> 404 Page Not Found: Img/services
ERROR - 2020-06-17 20:10:34 --> 404 Page Not Found: Img/blog
