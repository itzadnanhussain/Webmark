<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-03 00:51:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-03 05:33:33 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-03 06:45:52 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-03 10:48:58 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-03 12:00:54 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-07-03 12:00:54 --> 404 Page Not Found: Images/wlw
ERROR - 2020-07-03 12:00:54 --> 404 Page Not Found: Static/admin
ERROR - 2020-07-03 12:00:54 --> 404 Page Not Found: Catalog/view
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Order/catalog
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Catalog/view
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/mage
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/mage
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Skin/adminhtml
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/mage
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Administrator/manifests
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/eccube.js
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/eccube.legacy.js
ERROR - 2020-07-03 12:00:56 --> 404 Page Not Found: Js/css.js
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/navi.js
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/win_op.js
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/site.js
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/locale.js
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: User_data/css
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Template/admin
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: User_data/packages
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/mage
ERROR - 2020-07-03 12:00:57 --> 404 Page Not Found: Js/lib
ERROR - 2020-07-03 13:37:37 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-03 14:57:46 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-03 20:53:15 --> 404 Page Not Found: Vendor/phpunit
