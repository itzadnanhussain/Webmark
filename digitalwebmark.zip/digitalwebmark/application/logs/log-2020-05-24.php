<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-24 10:13:46 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-05-24 10:13:46 --> 404 Page Not Found: Images/wlw
ERROR - 2020-05-24 10:13:47 --> 404 Page Not Found: Static/admin
ERROR - 2020-05-24 15:13:45 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2020-05-24 15:13:45 --> 404 Page Not Found: User/login
ERROR - 2020-05-24 19:48:06 --> 404 Page Not Found: Img/services
ERROR - 2020-05-24 20:44:56 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-24 20:44:58 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-24 20:45:00 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-24 20:45:03 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-24 20:45:05 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-24 20:45:08 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-24 20:45:09 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-24 20:45:12 --> 404 Page Not Found: System/.env
ERROR - 2020-05-24 20:45:14 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-24 20:45:15 --> 404 Page Not Found: Shop/.env
