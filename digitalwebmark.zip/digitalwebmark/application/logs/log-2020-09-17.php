<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-17 01:34:51 --> 404 Page Not Found: Assets/img
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-17 06:07:14 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-17 07:34:31 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-17 08:31:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-17 08:31:52 --> 404 Page Not Found: Wp/wp-content
ERROR - 2020-09-17 08:31:54 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2020-09-17 08:32:33 --> 404 Page Not Found: Blog/wp-content
ERROR - 2020-09-17 08:32:55 --> 404 Page Not Found: New/wp-content
ERROR - 2020-09-17 08:32:57 --> 404 Page Not Found: Old/wp-content
ERROR - 2020-09-17 08:33:06 --> 404 Page Not Found: Demo/wp-content
ERROR - 2020-09-17 09:04:17 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-17 09:36:33 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-17 09:43:38 --> 404 Page Not Found: Bank/user
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-17 10:01:06 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-17 11:39:31 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-17 11:56:04 --> 404 Page Not Found: Bank/user
ERROR - 2020-09-17 11:56:15 --> 404 Page Not Found: Bank/user
ERROR - 2020-09-17 13:57:14 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-17 17:44:00 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-17 17:44:00 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-17 17:44:00 --> 404 Page Not Found: %0A/.env
