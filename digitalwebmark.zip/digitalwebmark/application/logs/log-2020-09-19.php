<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-19 02:23:49 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-19 09:27:55 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-19 11:25:57 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-19 11:57:38 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-19 14:05:53 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-19 21:27:14 --> 404 Page Not Found: Modules/handle-key
ERROR - 2020-09-19 23:03:12 --> 404 Page Not Found: Modules/handle-click
ERROR - 2020-09-19 23:38:45 --> 404 Page Not Found: User/popupSendEmail
