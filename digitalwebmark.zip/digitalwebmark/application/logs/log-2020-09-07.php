<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 06:03:58 --> 404 Page Not Found: Blogs/php
ERROR - 2020-09-07 08:29:18 --> 404 Page Not Found: User/register
ERROR - 2020-09-07 08:55:14 --> 404 Page Not Found: User/popupSendEmail
ERROR - 2020-09-07 08:55:16 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-09-07 09:29:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-07 20:17:38 --> 404 Page Not Found: Api/.env
ERROR - 2020-09-07 20:18:05 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-09-07 20:18:29 --> 404 Page Not Found: Test/.env
ERROR - 2020-09-07 20:18:55 --> 404 Page Not Found: Admin/.env
ERROR - 2020-09-07 20:19:20 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-09-07 20:19:43 --> 404 Page Not Found: Sites/.env
ERROR - 2020-09-07 20:20:09 --> 404 Page Not Found: Blog/.env
ERROR - 2020-09-07 20:20:35 --> 404 Page Not Found: System/.env
ERROR - 2020-09-07 20:21:00 --> 404 Page Not Found: Public/.env
ERROR - 2020-09-07 20:21:26 --> 404 Page Not Found: Shop/.env
