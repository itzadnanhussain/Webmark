<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-18 00:22:01 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-18 00:22:07 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-18 00:22:14 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-18 00:22:22 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-18 00:22:27 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-18 00:22:34 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-18 00:22:41 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-18 01:06:56 --> 404 Page Not Found: Img/why-us
ERROR - 2020-06-18 01:13:55 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-18 02:18:05 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-18 02:55:24 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-06-18 06:18:57 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-18 07:54:18 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-18 16:00:01 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-18 18:04:30 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-18 19:17:16 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-18 23:33:47 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-18 23:33:48 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-18 23:33:48 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-18 23:33:49 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-18 23:33:50 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-18 23:33:51 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-18 23:33:51 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-18 23:33:52 --> 404 Page Not Found: System/.env
ERROR - 2020-06-18 23:33:53 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-18 23:33:53 --> 404 Page Not Found: Shop/.env
