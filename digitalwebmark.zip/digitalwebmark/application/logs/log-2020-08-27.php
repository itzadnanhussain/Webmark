<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 18:53:40 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-27 22:07:52 --> 404 Page Not Found: Test/wp-login.php
