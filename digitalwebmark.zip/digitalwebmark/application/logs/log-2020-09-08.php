<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 00:08:37 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 00:16:50 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 00:32:56 --> 404 Page Not Found: Blogs/img
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:43 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:17:44 --> 404 Page Not Found: Pppforms/http
ERROR - 2020-09-08 08:27:09 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-09-08 08:28:47 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-09-08 08:33:09 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-09-08 08:33:28 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-09-08 08:34:43 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-09-08 10:44:54 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 11:16:32 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 11:44:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 11:44:50 --> 404 Page Not Found: Wp/wp-content
ERROR - 2020-09-08 11:44:58 --> 404 Page Not Found: Wordpress/wp-content
ERROR - 2020-09-08 11:45:08 --> 404 Page Not Found: Old/wp-content
ERROR - 2020-09-08 11:45:14 --> 404 Page Not Found: New/wp-content
ERROR - 2020-09-08 11:45:23 --> 404 Page Not Found: Blog/wp-content
ERROR - 2020-09-08 11:45:37 --> 404 Page Not Found: Test/wp-content
ERROR - 2020-09-08 11:45:46 --> 404 Page Not Found: Demo/wp-content
ERROR - 2020-09-08 11:45:58 --> 404 Page Not Found: Admin/wp-content
ERROR - 2020-09-08 11:46:05 --> 404 Page Not Found: 2020/wp-content
ERROR - 2020-09-08 11:46:14 --> 404 Page Not Found: 2019/wp-content
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 14:24:51 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 15:08:33 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 15:08:50 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 15:08:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 15:08:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 15:08:53 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 20:07:25 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-08 23:08:48 --> 404 Page Not Found: Php/sendEmail.php
