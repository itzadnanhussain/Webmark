<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-26 08:32:37 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-26 08:53:50 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-26 08:53:53 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-26 08:53:55 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-26 08:53:59 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-26 08:54:01 --> 404 Page Not Found: Phpunit/phpunit
ERROR - 2020-05-26 08:54:04 --> 404 Page Not Found: Phpunit/phpunit
ERROR - 2020-05-26 08:54:07 --> 404 Page Not Found: Phpunit/src
ERROR - 2020-05-26 08:54:11 --> 404 Page Not Found: Phpunit/Util
ERROR - 2020-05-26 08:54:14 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-26 08:54:16 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-26 08:54:20 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-26 08:54:23 --> 404 Page Not Found: Lib/phpunit
ERROR - 2020-05-26 08:54:29 --> 404 Page Not Found: Panel/vendor
ERROR - 2020-05-26 08:54:35 --> 404 Page Not Found: Test/vendor
ERROR - 2020-05-26 08:54:38 --> 404 Page Not Found: Api/vendor
ERROR - 2020-05-26 08:54:40 --> 404 Page Not Found: Old/vendor
ERROR - 2020-05-26 08:54:42 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-05-26 08:54:46 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-05-26 08:54:49 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-05-26 08:54:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-05-26 08:54:53 --> 404 Page Not Found: Sites/all
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-26 15:41:55 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-26 22:08:50 --> 404 Page Not Found: Blogs/blogs
