<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 00:34:21 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-08 20:11:47 --> 404 Page Not Found: Blogs/blogs
