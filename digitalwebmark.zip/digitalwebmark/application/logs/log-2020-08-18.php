<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-18 01:11:54 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-08-18 01:11:55 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-08-18 01:11:56 --> 404 Page Not Found: Admin/index.php
ERROR - 2020-08-18 02:31:56 --> 404 Page Not Found: Img/services
ERROR - 2020-08-18 04:07:26 --> 404 Page Not Found: Img/why-us
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-18 07:28:31 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-18 08:10:37 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-18 11:19:16 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-18 12:09:30 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-18 13:42:39 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-08-18 13:42:41 --> 404 Page Not Found: Wp-admin/setup-config.php
ERROR - 2020-08-18 21:27:49 --> 404 Page Not Found: Pppforms/user
