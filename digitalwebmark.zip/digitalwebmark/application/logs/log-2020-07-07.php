<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 14:35:00 --> 404 Page Not Found: Api/.env
ERROR - 2020-07-07 14:35:07 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-07-07 14:35:15 --> 404 Page Not Found: Test/.env
ERROR - 2020-07-07 14:35:24 --> 404 Page Not Found: Admin/.env
ERROR - 2020-07-07 14:35:33 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-07-07 14:35:41 --> 404 Page Not Found: Sites/.env
ERROR - 2020-07-07 14:35:48 --> 404 Page Not Found: Blog/.env
ERROR - 2020-07-07 14:35:56 --> 404 Page Not Found: System/.env
ERROR - 2020-07-07 14:36:05 --> 404 Page Not Found: Public/.env
ERROR - 2020-07-07 14:36:15 --> 404 Page Not Found: Shop/.env
