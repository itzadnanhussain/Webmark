<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-25 07:14:51 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-25 11:15:10 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-25 11:25:55 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-25 15:19:12 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
