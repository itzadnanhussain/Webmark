<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 02:01:19 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-25 10:07:54 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-25 11:28:47 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-25 13:25:13 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-25 19:44:56 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-25 22:02:25 --> 404 Page Not Found: Blogs/php
ERROR - 2020-08-25 23:49:04 --> 404 Page Not Found: Core/.env
ERROR - 2020-08-25 23:49:21 --> 404 Page Not Found: Admin/.env
ERROR - 2020-08-25 23:49:46 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-08-25 23:50:16 --> 404 Page Not Found: Dev/.env
ERROR - 2020-08-25 23:50:48 --> 404 Page Not Found: Blog/.env
ERROR - 2020-08-25 23:51:22 --> 404 Page Not Found: Vendor/phpunit
