<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-16 00:24:36 --> 404 Page Not Found: Modules/handle-swal-dom
ERROR - 2020-06-16 02:37:16 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-16 04:18:21 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-16 09:00:33 --> 404 Page Not Found: Mua/EMAIL.php-VyFrqOi1asWqzwR7vrqICrNWqT5Zj3RUzzfmBsss.php
ERROR - 2020-06-16 11:19:51 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-16 11:19:51 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-16 11:19:53 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-16 11:19:54 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-16 11:19:55 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-16 11:19:56 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-16 11:19:56 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-16 11:19:57 --> 404 Page Not Found: System/.env
ERROR - 2020-06-16 11:19:58 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-16 13:16:08 --> 404 Page Not Found: Modules/set-params
ERROR - 2020-06-16 14:15:00 --> 404 Page Not Found: 2020/wp-login.php
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-16 16:15:01 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-16 18:31:08 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-16 21:00:08 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
