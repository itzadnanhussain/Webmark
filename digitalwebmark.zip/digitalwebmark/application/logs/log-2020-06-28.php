<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 08:38:51 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-28 11:34:31 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-06-28 12:02:50 --> 404 Page Not Found: Img/blog
