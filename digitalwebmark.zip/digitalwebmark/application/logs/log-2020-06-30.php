<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-30 05:50:14 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-30 06:13:13 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-30 09:41:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-06-30 09:43:03 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-06-30 09:43:14 --> 404 Page Not Found: Wp-admin/install.php
ERROR - 2020-06-30 09:43:24 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-06-30 13:37:18 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-30 20:18:22 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2020-06-30 20:18:24 --> 404 Page Not Found: New/wp-admin
