<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-29 09:56:18 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-07-29 14:55:25 --> 404 Page Not Found: Well-known/assetlinks.json
