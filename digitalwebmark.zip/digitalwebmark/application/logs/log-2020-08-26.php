<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 03:22:45 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2020-08-26 05:34:55 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2020-08-26 05:34:55 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2020-08-26 08:01:02 --> 404 Page Not Found: Img/blog
ERROR - 2020-08-26 10:05:06 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-26 10:05:07 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-26 10:05:07 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-26 10:05:07 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-26 10:05:07 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-26 10:05:07 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-26 11:58:01 --> 404 Page Not Found: Js/admin.js
ERROR - 2020-08-26 19:02:51 --> 404 Page Not Found: Admindede/login.php
ERROR - 2020-08-26 19:02:51 --> 404 Page Not Found: Htadmin/login.php
ERROR - 2020-08-26 19:02:51 --> 404 Page Not Found: Manager/login.php
ERROR - 2020-08-26 19:02:51 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-08-26 19:02:52 --> 404 Page Not Found: Manage/login.php
ERROR - 2020-08-26 19:02:52 --> 404 Page Not Found: Dede/login.php
