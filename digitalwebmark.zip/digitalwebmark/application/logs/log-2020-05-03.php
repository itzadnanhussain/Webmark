<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-03 04:10:24 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-03 07:46:02 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-03 07:46:02 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-03 07:46:02 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-03 07:46:03 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-03 07:46:03 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:03 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:04 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:04 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:04 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:04 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:05 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:05 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:05 --> 404 Page Not Found: Img/owl.video.play.png
ERROR - 2020-05-03 07:46:05 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-03 07:46:07 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:08 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:09 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:09 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:10 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:11 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:12 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:14 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:14 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/img
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:16 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:16 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-03 07:46:27 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-03 08:43:53 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-03 13:16:39 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-03 22:04:07 --> 404 Page Not Found: Php/sendEmail.php
