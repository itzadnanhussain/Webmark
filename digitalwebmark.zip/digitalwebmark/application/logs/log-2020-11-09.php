<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-09 06:30:39 --> Severity: error --> Exception: Call to undefined function Pageview() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 64
ERROR - 2020-11-09 06:34:59 --> Severity: error --> Exception: Call to a member function helper() on null E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 7
ERROR - 2020-11-09 06:37:01 --> Severity: error --> Exception: Call to undefined function Pageview() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 69
ERROR - 2020-11-09 06:55:38 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-09 06:55:38 --> 404 Page Not Found: Career/clients
ERROR - 2020-11-09 06:55:44 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-09 06:55:44 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-09 06:55:59 --> 404 Page Not Found: Uploads/careers
ERROR - 2020-11-09 06:55:59 --> 404 Page Not Found: Resume/assets
ERROR - 2020-11-09 06:56:00 --> 404 Page Not Found: Resume/assets
