<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-13 01:06:17 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-13 05:29:47 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-13 05:29:48 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-13 05:29:48 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-13 05:29:48 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-13 05:29:48 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-13 05:29:48 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-13 06:34:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:11 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:11 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:12 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:12 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:12 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:13 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:14 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:14 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:14 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:15 --> Unable to connect to the database
ERROR - 2020-07-13 06:34:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (2) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-07-13 06:34:15 --> Unable to connect to the database
ERROR - 2020-07-13 12:39:58 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-13 13:47:22 --> 404 Page Not Found: Img/blog
