<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-10 00:38:02 --> 404 Page Not Found: Api/vendor
ERROR - 2020-05-10 02:23:53 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-10 07:14:25 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-10 07:32:06 --> 404 Page Not Found: Img/services
ERROR - 2020-05-10 09:35:15 --> 404 Page Not Found: Img/services
ERROR - 2020-05-10 19:25:21 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-10 21:23:53 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-10 22:34:40 --> 404 Page Not Found: Pma/index.php
ERROR - 2020-05-10 22:34:40 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2020-05-10 22:34:40 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2020-05-10 22:56:09 --> 404 Page Not Found: PhpMyAdmin/index.php
ERROR - 2020-05-10 22:58:07 --> 404 Page Not Found: Well-known/assetlinks.json
