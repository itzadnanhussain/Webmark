<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-30 10:01:13 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-30 10:01:14 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-30 10:01:16 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-30 10:01:18 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-30 10:01:19 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-30 10:01:20 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-30 10:01:21 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-30 10:01:21 --> 404 Page Not Found: System/.env
ERROR - 2020-05-30 10:01:23 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-30 10:01:26 --> 404 Page Not Found: Shop/.env
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-30 12:59:03 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-30 20:56:38 --> 404 Page Not Found: Vendor/phpunit
