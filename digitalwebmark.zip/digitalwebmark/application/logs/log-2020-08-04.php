<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-04 01:59:43 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-04 06:55:27 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-04 06:55:32 --> 404 Page Not Found: Api/vendor
ERROR - 2020-08-04 06:55:37 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-08-04 06:55:51 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-08-04 06:55:51 --> 404 Page Not Found: Sites/all
ERROR - 2020-08-04 06:55:55 --> 404 Page Not Found: Test/vendor
ERROR - 2020-08-04 06:56:01 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-08-04 06:56:06 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-08-04 06:56:12 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-08-04 06:56:18 --> 404 Page Not Found: System/vendor
ERROR - 2020-08-04 06:56:30 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-08-04 06:56:35 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-08-04 06:56:41 --> 404 Page Not Found: Testing/vendor
ERROR - 2020-08-04 06:56:47 --> 404 Page Not Found: Core/vendor
ERROR - 2020-08-04 06:56:53 --> 404 Page Not Found: Mahara/auth
ERROR - 2020-08-04 06:56:59 --> 404 Page Not Found: Concrete/vendor
ERROR - 2020-08-04 06:57:04 --> 404 Page Not Found: Local/vendor
ERROR - 2020-08-04 06:57:11 --> 404 Page Not Found: Lib/vendor
ERROR - 2020-08-04 06:57:16 --> 404 Page Not Found: Backup/vendor
ERROR - 2020-08-04 06:57:22 --> 404 Page Not Found: Demo/vendor
ERROR - 2020-08-04 06:57:29 --> 404 Page Not Found: Mapa/vendor
ERROR - 2020-08-04 06:57:36 --> 404 Page Not Found: Platform/vendor
ERROR - 2020-08-04 06:57:40 --> 404 Page Not Found: 2018/vendor
ERROR - 2020-08-04 06:57:45 --> 404 Page Not Found: All/vendor
ERROR - 2020-08-04 06:57:51 --> 404 Page Not Found: New/vendor
ERROR - 2020-08-04 06:57:57 --> 404 Page Not Found: Pro/vendor
ERROR - 2020-08-04 06:58:01 --> 404 Page Not Found: Www/vendor
ERROR - 2020-08-04 06:58:07 --> 404 Page Not Found: App/vendor
ERROR - 2020-08-04 06:58:13 --> 404 Page Not Found: Old/vendor
ERROR - 2020-08-04 06:58:18 --> 404 Page Not Found: 2020/vendor
ERROR - 2020-08-04 06:58:22 --> 404 Page Not Found: 2019/vendor
ERROR - 2020-08-04 06:58:29 --> 404 Page Not Found: Beta/vendor
ERROR - 2020-08-04 06:58:36 --> 404 Page Not Found: Portal/vendor
ERROR - 2020-08-04 06:58:40 --> 404 Page Not Found: Pms/vendor
ERROR - 2020-08-04 06:58:45 --> 404 Page Not Found: Id/vendor
ERROR - 2020-08-04 06:58:52 --> 404 Page Not Found: Test/med-decision
ERROR - 2020-08-04 06:58:57 --> 404 Page Not Found: Site/PortalEscolar
ERROR - 2020-08-04 06:59:01 --> 404 Page Not Found: Dev/vendor
ERROR - 2020-08-04 06:59:06 --> 404 Page Not Found: Protected/vendor
ERROR - 2020-08-04 06:59:13 --> 404 Page Not Found: En/vendor
ERROR - 2020-08-04 06:59:16 --> 404 Page Not Found: Administration/vendor
ERROR - 2020-08-04 06:59:21 --> 404 Page Not Found: Login/vendor
ERROR - 2020-08-04 06:59:29 --> 404 Page Not Found: V1/vendor
ERROR - 2020-08-04 06:59:33 --> 404 Page Not Found: Web/vendor
ERROR - 2020-08-04 06:59:37 --> 404 Page Not Found: Site/vendor
ERROR - 2020-08-04 06:59:42 --> 404 Page Not Found: Assets/vendor
ERROR - 2020-08-04 06:59:48 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-04 20:49:59 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-04 20:49:59 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-04 20:49:59 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-04 20:49:59 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-04 20:49:59 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-04 20:50:01 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-04 21:11:57 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-08-04 21:11:59 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-08-04 21:11:59 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-08-04 21:11:59 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-08-04 21:11:59 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-08-04 21:12:00 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-08-04 21:12:00 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-08-04 21:12:00 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-08-04 21:12:00 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-08-04 21:12:00 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-08-04 21:12:01 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-08-04 21:12:01 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-08-04 21:12:01 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-08-04 21:12:01 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-08-04 21:12:13 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-08-04 21:12:13 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-08-04 21:12:13 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-08-04 22:11:32 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-04 22:36:02 --> 404 Page Not Found: Img/services-title
ERROR - 2020-08-04 23:53:58 --> 404 Page Not Found: Blogs/php
