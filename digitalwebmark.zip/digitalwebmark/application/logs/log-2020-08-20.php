<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-20 03:57:57 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-20 04:32:46 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-20 05:07:04 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-20 05:08:30 --> 404 Page Not Found: Blogs/php
ERROR - 2020-08-20 06:49:25 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-08-20 07:44:07 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-20 08:46:28 --> 404 Page Not Found: Wp-content/class.php
ERROR - 2020-08-20 09:26:41 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-08-20 12:01:35 --> 404 Page Not Found: Js/admin.js
ERROR - 2020-08-20 13:57:40 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-20 23:44:54 --> 404 Page Not Found: Js/comm.js
ERROR - 2020-08-20 23:44:54 --> 404 Page Not Found: Js/common.js
ERROR - 2020-08-20 23:44:54 --> 404 Page Not Found: Public/js
ERROR - 2020-08-20 23:44:54 --> 404 Page Not Found: Include/calendar
ERROR - 2020-08-20 23:44:55 --> 404 Page Not Found: E/admin
