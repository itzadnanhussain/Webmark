<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-23 00:01:05 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-23 07:55:46 --> 404 Page Not Found: Img/services-title
ERROR - 2020-07-23 08:46:55 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-23 11:19:32 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-07-23 12:59:24 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-23 16:36:08 --> 404 Page Not Found: Wp-includes/js
ERROR - 2020-07-23 16:36:09 --> 404 Page Not Found: Administrator/help
ERROR - 2020-07-23 16:36:09 --> 404 Page Not Found: Administrator/language
ERROR - 2020-07-23 16:36:09 --> 404 Page Not Found: Plugins/system
ERROR - 2020-07-23 16:36:10 --> 404 Page Not Found: Misc/ajax.js
ERROR - 2020-07-23 16:36:11 --> 404 Page Not Found: Admin/view
ERROR - 2020-07-23 16:36:12 --> 404 Page Not Found: Admin/includes
ERROR - 2020-07-23 16:36:12 --> 404 Page Not Found: Images/editor
ERROR - 2020-07-23 16:36:12 --> 404 Page Not Found: Js/header-rollup-554.js
ERROR - 2020-07-23 16:36:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-07-23 16:36:13 --> 404 Page Not Found: Fckeditor/editor
