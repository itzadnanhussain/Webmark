<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-05 02:04:43 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-05 02:04:43 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-05 02:04:43 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-05 02:04:43 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-05 02:04:59 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-05 02:04:59 --> 404 Page Not Found: Blog/.env
ERROR - 2020-06-05 02:04:59 --> 404 Page Not Found: System/.env
ERROR - 2020-06-05 02:04:59 --> 404 Page Not Found: Public/.env
ERROR - 2020-06-05 02:05:00 --> 404 Page Not Found: Shop/.env
ERROR - 2020-06-05 04:48:16 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-05 07:43:07 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-05 16:59:55 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-05 20:37:01 --> 404 Page Not Found: Blog/robots.txt
ERROR - 2020-06-05 22:20:28 --> 404 Page Not Found: Well-known/assetlinks.json
