<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-13 04:17:58 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-13 05:35:04 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-13 05:48:20 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-13 10:22:22 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-08-13 10:22:23 --> 404 Page Not Found: Storage/.env
ERROR - 2020-08-13 10:22:24 --> 404 Page Not Found: Public/.env
ERROR - 2020-08-13 10:38:46 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-13 14:58:36 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-13 18:45:21 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 18:45:27 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 18:45:27 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 18:45:29 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 18:45:32 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 18:45:35 --> 404 Page Not Found: Pppforms/user
ERROR - 2020-08-13 19:05:16 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-08-13 19:05:17 --> 404 Page Not Found: Storage/.env
ERROR - 2020-08-13 19:05:17 --> 404 Page Not Found: Public/.env
ERROR - 2020-08-13 22:15:06 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-13 22:47:03 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-13 22:49:05 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-08-13 22:57:57 --> 404 Page Not Found: Git/HEAD
