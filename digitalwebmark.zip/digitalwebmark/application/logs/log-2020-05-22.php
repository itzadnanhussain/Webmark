<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-22 00:23:36 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-22 03:07:34 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-22 06:08:13 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-22 07:45:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-22 09:32:12 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-22 10:37:29 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-05-22 10:38:00 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-05-22 10:38:01 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-05-22 10:38:01 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-05-22 10:38:02 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-05-22 10:38:03 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-05-22 10:38:04 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-05-22 10:38:04 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-05-22 10:38:05 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-05-22 10:38:06 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-05-22 10:38:07 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-05-22 10:38:07 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-05-22 10:38:08 --> 404 Page Not Found: Media/wp-includes
ERROR - 2020-05-22 10:38:09 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-05-22 10:38:10 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-05-22 10:38:10 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-05-22 10:38:11 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-05-22 12:18:15 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 13:00:05 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 13:37:25 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 18:09:37 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-22 18:17:26 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 19:08:48 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-22 19:44:59 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-22 19:45:00 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-22 19:45:00 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-22 19:45:00 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-05-22 21:21:18 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
