<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-21 00:02:41 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-21 02:57:33 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-05-21 09:38:29 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-21 11:02:13 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-21 16:14:00 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-21 16:25:59 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-21 18:15:22 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-21 19:58:58 --> 404 Page Not Found: Assets/img
ERROR - 2020-05-21 22:52:18 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-21 23:21:40 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-21 23:48:05 --> 404 Page Not Found: Img/blog
