<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-21 10:55:51 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-21 22:23:26 --> 404 Page Not Found: Well-known/assetlinks.json
