<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-18 02:45:57 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-18 10:32:17 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-18 13:06:14 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-18 20:30:54 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-18 20:52:15 --> 404 Page Not Found: Img/blog
ERROR - 2020-07-18 21:26:02 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-18 22:36:43 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-18 23:22:01 --> 404 Page Not Found: Img/why-us
