<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-24 01:31:55 --> 404 Page Not Found: Img/blog
ERROR - 2020-06-24 01:54:46 --> 404 Page Not Found: Modules/utils
ERROR - 2020-06-24 02:18:18 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-24 05:11:40 --> 404 Page Not Found: Blogs/php
ERROR - 2020-06-24 06:06:09 --> 404 Page Not Found: Img/services
ERROR - 2020-06-24 08:18:02 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-06-24 15:58:55 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-24 15:59:58 --> 404 Page Not Found: Api/vendor
ERROR - 2020-06-24 16:00:19 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-24 16:00:31 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-06-24 16:00:44 --> 404 Page Not Found: Sites/all
ERROR - 2020-06-24 16:00:58 --> 404 Page Not Found: Test/vendor
ERROR - 2020-06-24 16:01:30 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-24 16:02:39 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-06-24 16:03:42 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-06-24 16:04:42 --> 404 Page Not Found: System/vendor
ERROR - 2020-06-24 16:05:51 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-06-24 16:06:54 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-06-24 16:07:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-24 17:43:44 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-24 19:40:11 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
