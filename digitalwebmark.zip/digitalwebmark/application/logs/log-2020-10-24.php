<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-24 07:47:52 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 92
ERROR - 2020-10-24 07:47:55 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Jatesh_Kumar1591503210.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 92
ERROR - 2020-10-24 08:59:14 --> Severity: Notice --> Undefined variable: rows E:\xampp\htdocs\digitalwebmark\application\views\applicant_tb.php 53
ERROR - 2020-10-24 08:59:14 --> Severity: Notice --> Trying to access array offset on value of type null E:\xampp\htdocs\digitalwebmark\application\views\applicant_tb.php 53
ERROR - 2020-10-24 09:16:16 --> Severity: error --> Exception: Call to undefined function DeleteRecord() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 101
ERROR - 2020-10-24 09:16:21 --> Severity: error --> Exception: Call to undefined function DeleteRecord() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 101
ERROR - 2020-10-24 09:16:56 --> Severity: error --> Exception: Call to undefined function DeleteRecord() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 101
ERROR - 2020-10-24 09:17:52 --> Severity: error --> Exception: Call to undefined function DeleteRecord() E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 102
ERROR - 2020-10-24 09:27:10 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Muhammad_Arshad1592839140.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 92
ERROR - 2020-10-24 09:27:15 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Muhammad_Arshad1592839140.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 92
ERROR - 2020-10-24 09:32:32 --> Severity: Warning --> file_get_contents(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 102
ERROR - 2020-10-24 09:32:43 --> Severity: Warning --> readfile(E:\xampp\htdocs\digitalwebmark\/uploads/Muhammad_Arshad1592839140.pdf): failed to open stream: No such file or directory E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 92
ERROR - 2020-10-24 09:33:26 --> Severity: Warning --> file_get_contents(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 102
ERROR - 2020-10-24 09:36:58 --> Severity: Warning --> file_get_contents(): Filename cannot be empty E:\xampp\htdocs\digitalwebmark\application\controllers\Admin.php 103
