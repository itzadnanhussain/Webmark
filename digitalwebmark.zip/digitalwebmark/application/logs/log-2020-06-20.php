<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-20 06:40:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-06-20 06:40:42 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-06-20 06:40:42 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-06-20 06:40:42 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Test/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-06-20 06:40:43 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2020-06-20 07:52:14 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-20 23:02:42 --> 404 Page Not Found: Api/.env
ERROR - 2020-06-20 23:02:55 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-06-20 23:03:10 --> 404 Page Not Found: Test/.env
ERROR - 2020-06-20 23:03:24 --> 404 Page Not Found: Admin/.env
ERROR - 2020-06-20 23:03:39 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-06-20 23:03:52 --> 404 Page Not Found: Sites/.env
ERROR - 2020-06-20 23:04:05 --> 404 Page Not Found: Blog/.env
