<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-12 02:58:54 --> 404 Page Not Found: Img/services
ERROR - 2020-05-12 04:39:13 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-12 07:31:00 --> 404 Page Not Found: Web/wp-login.php
ERROR - 2020-05-12 07:31:39 --> 404 Page Not Found: Cms/wp-login.php
ERROR - 2020-05-12 22:22:46 --> 404 Page Not Found: Php/sendEmail.php
