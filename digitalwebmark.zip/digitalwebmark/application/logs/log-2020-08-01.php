<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-01 00:23:25 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-01 00:49:57 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-01 01:09:36 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-08-01 01:10:12 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-08-01 01:10:23 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-08-01 01:10:33 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-08-01 01:10:48 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-08-01 01:11:01 --> 404 Page Not Found: Old/wp-includes
ERROR - 2020-08-01 01:11:37 --> 404 Page Not Found: Backup/wp-includes
ERROR - 2020-08-01 01:11:47 --> 404 Page Not Found: New/wp-includes
ERROR - 2020-08-01 01:12:22 --> 404 Page Not Found: En/wp-includes
ERROR - 2020-08-01 01:13:09 --> 404 Page Not Found: Web/wp-includes
ERROR - 2020-08-01 01:13:25 --> 404 Page Not Found: Dev/wp-includes
ERROR - 2020-08-01 01:13:45 --> 404 Page Not Found: Home/wp-includes
ERROR - 2020-08-01 01:14:27 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-08-01 01:15:05 --> 404 Page Not Found: Www/wp-includes
ERROR - 2020-08-01 01:15:21 --> 404 Page Not Found: Staging/wp-includes
ERROR - 2020-08-01 01:16:32 --> 404 Page Not Found: News/wp-includes
ERROR - 2020-08-01 01:17:08 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2020-08-01 01:17:33 --> 404 Page Not Found: Main/wp-includes
ERROR - 2020-08-01 01:18:09 --> 404 Page Not Found: Newsite/wp-includes
ERROR - 2020-08-01 01:18:38 --> 404 Page Not Found: V2/wp-includes
ERROR - 2020-08-01 01:19:44 --> 404 Page Not Found: Oldsite/wp-includes
ERROR - 2020-08-01 01:19:54 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-08-01 01:20:19 --> 404 Page Not Found: Website/wp-includes
ERROR - 2020-08-01 01:20:55 --> 404 Page Not Found: Portal/wp-includes
ERROR - 2020-08-01 01:21:41 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2020-08-01 01:21:56 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2020-08-01 01:22:41 --> 404 Page Not Found: V1/wp-includes
ERROR - 2020-08-01 01:22:42 --> 404 Page Not Found: V1/wp-includes
ERROR - 2020-08-01 01:23:19 --> 404 Page Not Found: 1/wp-includes
ERROR - 2020-08-01 02:23:34 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-01 02:48:49 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-01 17:17:46 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-01 19:40:59 --> 404 Page Not Found: Git/HEAD
ERROR - 2020-08-01 20:29:00 --> 404 Page Not Found: Img/services-title
