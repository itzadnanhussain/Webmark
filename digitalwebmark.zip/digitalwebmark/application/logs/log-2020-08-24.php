<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-24 10:02:30 --> 404 Page Not Found: Core/.env
ERROR - 2020-08-24 10:02:30 --> 404 Page Not Found: Admin/.env
ERROR - 2020-08-24 10:02:31 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-08-24 10:02:33 --> 404 Page Not Found: Dev/.env
ERROR - 2020-08-24 10:02:34 --> 404 Page Not Found: Blog/.env
ERROR - 2020-08-24 10:02:35 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: Database/print.css
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: Pma/print.css
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: Phpmyadmin/print.css
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: Myadmin/print.css
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: PhpMyAdmin/print.css
ERROR - 2020-08-24 11:45:08 --> 404 Page Not Found: Mysql/print.css
ERROR - 2020-08-24 15:52:38 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-24 17:37:51 --> 404 Page Not Found: Blogs/img
ERROR - 2020-08-24 23:32:58 --> 404 Page Not Found: Assets/img
