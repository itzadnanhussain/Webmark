<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-09 06:04:38 --> 404 Page Not Found: Wp-admin/admin-ajax.php
ERROR - 2020-08-09 08:15:28 --> 404 Page Not Found: Profile/register
ERROR - 2020-08-09 08:15:28 --> 404 Page Not Found: Wp/profile
ERROR - 2020-08-09 08:15:28 --> 404 Page Not Found: Wordpress/profile
ERROR - 2020-08-09 08:15:29 --> 404 Page Not Found: Blog/profile
ERROR - 2020-08-09 08:15:29 --> 404 Page Not Found: New/profile
ERROR - 2020-08-09 08:15:29 --> 404 Page Not Found: Old/profile
ERROR - 2020-08-09 08:15:29 --> 404 Page Not Found: Demo/profile
ERROR - 2020-08-09 17:21:38 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-08-09 21:36:37 --> 404 Page Not Found: Php/sendEmail.php
