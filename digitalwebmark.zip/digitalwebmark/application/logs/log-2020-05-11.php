<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 01:01:33 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-11 09:50:21 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-11 09:50:31 --> 404 Page Not Found: Api/vendor
ERROR - 2020-05-11 09:50:40 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-05-11 09:50:52 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-05-11 09:51:04 --> 404 Page Not Found: Sites/all
ERROR - 2020-05-11 09:51:14 --> 404 Page Not Found: Test/vendor
ERROR - 2020-05-11 09:51:23 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-05-11 09:51:31 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-05-11 09:51:38 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-05-11 09:51:48 --> 404 Page Not Found: System/vendor
ERROR - 2020-05-11 09:52:00 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-05-11 09:52:10 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-05-11 09:52:19 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-05-11 19:43:25 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-11 19:47:38 --> 404 Page Not Found: Php/sendEmail.php
