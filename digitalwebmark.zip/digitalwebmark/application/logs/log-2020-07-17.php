<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-17 00:06:48 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-17 03:40:32 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-17 06:20:20 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-07-17 07:59:45 --> 404 Page Not Found: Git/config
