<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-25 22:03:44 --> 404 Page Not Found: Laravel/composer.json
