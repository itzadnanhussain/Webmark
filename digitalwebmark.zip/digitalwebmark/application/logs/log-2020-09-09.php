<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-09 05:24:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 07:25:22 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-09-09 07:25:23 --> 404 Page Not Found: Blogs/assets
ERROR - 2020-09-09 14:54:14 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-09 18:01:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-09-09 18:02:46 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 18:02:57 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 18:03:10 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 18:03:20 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 18:04:03 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-09 19:23:36 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-09 19:23:36 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-09 19:23:45 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-09 19:24:35 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-09-09 23:30:48 --> 404 Page Not Found: Img/blog
