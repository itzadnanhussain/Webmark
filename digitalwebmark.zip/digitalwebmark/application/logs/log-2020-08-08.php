<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-08 00:26:21 --> 404 Page Not Found: Demo/vendor
ERROR - 2020-08-08 02:38:59 --> 404 Page Not Found: Api/vendor
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-08 04:02:35 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-08 05:34:33 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-08 07:06:12 --> 404 Page Not Found: Blogs/php
ERROR - 2020-08-08 09:30:14 --> 404 Page Not Found: Demo/vendor
ERROR - 2020-08-08 11:03:06 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-08-08 13:58:22 --> 404 Page Not Found: Api/vendor
