<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-09 00:31:00 --> 404 Page Not Found: ReportServer/pages
ERROR - 2020-07-09 00:31:01 --> 404 Page Not Found: _layouts/15
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 7
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 12
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/ContentWritingServices.php 110
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-09 04:52:21 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-09 06:23:10 --> 404 Page Not Found: Img/portfolio
ERROR - 2020-07-09 07:08:03 --> 404 Page Not Found: Assets/img
ERROR - 2020-07-09 08:10:27 --> 404 Page Not Found: DesktopModules/Admin
ERROR - 2020-07-09 08:10:27 --> 404 Page Not Found: DesktopModules/RadEditorProvider
ERROR - 2020-07-09 08:10:28 --> 404 Page Not Found: Desktopmodules/dnnwerk.radeditorprovider
ERROR - 2020-07-09 09:01:24 --> 404 Page Not Found: Img/why-us
ERROR - 2020-07-09 09:51:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-07-09 13:36:48 --> 404 Page Not Found: DesktopModules/Admin
ERROR - 2020-07-09 13:36:49 --> 404 Page Not Found: DesktopModules/RadEditorProvider
ERROR - 2020-07-09 13:36:51 --> 404 Page Not Found: Modules/shop
ERROR - 2020-07-09 13:36:51 --> 404 Page Not Found: Providers/HtmlEditorProviders
ERROR - 2020-07-09 13:36:51 --> 404 Page Not Found: Common/admin
ERROR - 2020-07-09 14:10:58 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-09 14:22:11 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-07-09 17:27:18 --> 404 Page Not Found: Blogs/img
ERROR - 2020-07-09 21:09:28 --> 404 Page Not Found: Php/sendEmail.php
