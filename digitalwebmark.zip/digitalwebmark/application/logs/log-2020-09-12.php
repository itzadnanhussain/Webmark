<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-12 03:06:09 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-12 05:04:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-12 14:36:40 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-12 15:43:31 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-12 15:44:13 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-12 15:52:08 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-12 15:52:51 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-09-12 20:35:01 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-12 23:21:36 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-09-12 23:35:40 --> 404 Page Not Found: Wp-content/plugins
