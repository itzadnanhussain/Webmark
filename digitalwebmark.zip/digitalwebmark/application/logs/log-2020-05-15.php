<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-15 00:30:38 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-05-15 01:18:15 --> 404 Page Not Found: Img/services
ERROR - 2020-05-15 03:05:32 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-15 03:52:21 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-05-15 04:48:35 --> 404 Page Not Found: Blogs/php
ERROR - 2020-05-15 05:01:42 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: System/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-15 07:46:20 --> 404 Page Not Found: Shop/.env
ERROR - 2020-05-15 07:54:54 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-15 07:54:55 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-15 07:54:56 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-15 07:54:56 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2020-05-15 09:47:50 --> 404 Page Not Found: Api/.env
ERROR - 2020-05-15 09:47:52 --> 404 Page Not Found: Laravel/.env
ERROR - 2020-05-15 09:47:54 --> 404 Page Not Found: Test/.env
ERROR - 2020-05-15 09:47:56 --> 404 Page Not Found: Admin/.env
ERROR - 2020-05-15 09:47:59 --> 404 Page Not Found: Vendor/.env
ERROR - 2020-05-15 09:48:00 --> 404 Page Not Found: Sites/.env
ERROR - 2020-05-15 09:48:02 --> 404 Page Not Found: Blog/.env
ERROR - 2020-05-15 09:48:04 --> 404 Page Not Found: System/.env
ERROR - 2020-05-15 09:48:05 --> 404 Page Not Found: Public/.env
ERROR - 2020-05-15 09:48:06 --> 404 Page Not Found: Shop/.env
ERROR - 2020-05-15 17:10:31 --> 404 Page Not Found: Wp-admin/mysql-adminer.php
ERROR - 2020-05-15 17:10:31 --> 404 Page Not Found: Wp-admin/adminer.php
ERROR - 2020-05-15 17:10:31 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-05-15 20:39:45 --> 404 Page Not Found: Cgi-bin/test-cgi
ERROR - 2020-05-15 20:39:46 --> 404 Page Not Found: Horde/imp
ERROR - 2020-05-15 20:39:47 --> 404 Page Not Found: PhpMyAdmin/scripts
ERROR - 2020-05-15 20:39:48 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2020-05-15 20:55:25 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-05-15 21:44:23 --> 404 Page Not Found: Img/blog
ERROR - 2020-05-15 23:22:47 --> 404 Page Not Found: Img/blog
