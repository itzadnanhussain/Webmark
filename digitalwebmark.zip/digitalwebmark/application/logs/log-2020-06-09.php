<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-09 05:13:37 --> 404 Page Not Found: Backup/vendor
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-09 06:49:56 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-09 07:33:14 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-09 09:43:15 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-09 11:34:00 --> 404 Page Not Found: Lib/vendor
ERROR - 2020-06-09 14:00:10 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-09 14:00:49 --> 404 Page Not Found: Workspace/drupal
ERROR - 2020-06-09 14:01:10 --> 404 Page Not Found: Admin/ckeditor
ERROR - 2020-06-09 14:01:28 --> 404 Page Not Found: Test/vendor
ERROR - 2020-06-09 14:01:48 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-09 14:02:08 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-06-09 14:02:26 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-06-09 14:02:44 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-06-09 14:03:00 --> 404 Page Not Found: Modules/ps_checkout
ERROR - 2020-06-09 14:03:19 --> 404 Page Not Found: Modules/pscartabandonmentpro
ERROR - 2020-06-09 14:03:37 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-09 14:03:55 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-09 14:04:14 --> 404 Page Not Found: Mailchimp/vendor
ERROR - 2020-06-09 14:04:33 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-06-09 14:04:50 --> 404 Page Not Found: Modules/vendor
ERROR - 2020-06-09 14:05:50 --> 404 Page Not Found: Sites/default
ERROR - 2020-06-09 14:06:09 --> 404 Page Not Found: Sites/vendor
ERROR - 2020-06-09 14:06:44 --> 404 Page Not Found: V2/vendor
ERROR - 2020-06-09 18:53:38 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-09 19:36:55 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-09 19:39:20 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-09 19:45:42 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-09 19:53:01 --> 404 Page Not Found: Blogs/blogs
