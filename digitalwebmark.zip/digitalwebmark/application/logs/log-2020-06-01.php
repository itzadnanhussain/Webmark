<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-01 00:38:42 --> 404 Page Not Found: Modules/handle-dom
ERROR - 2020-06-01 00:54:16 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-06-01 05:47:33 --> 404 Page Not Found: User/register.php
ERROR - 2020-06-01 05:48:39 --> 404 Page Not Found: User/register.php
ERROR - 2020-06-01 05:48:43 --> 404 Page Not Found: User/register.php
ERROR - 2020-06-01 05:50:39 --> 404 Page Not Found: User/register.php
ERROR - 2020-06-01 05:51:04 --> 404 Page Not Found: User/register.php
ERROR - 2020-06-01 06:13:18 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-06-01 06:13:27 --> 404 Page Not Found: Api/vendor
ERROR - 2020-06-01 06:13:34 --> 404 Page Not Found: Laravel/vendor
ERROR - 2020-06-01 06:13:43 --> 404 Page Not Found: Modules/autoupgrade
ERROR - 2020-06-01 06:13:52 --> 404 Page Not Found: Sites/all
ERROR - 2020-06-01 06:13:59 --> 404 Page Not Found: Test/vendor
ERROR - 2020-06-01 06:14:09 --> 404 Page Not Found: Admin/vendor
ERROR - 2020-06-01 06:14:24 --> 404 Page Not Found: Modules/ps_facetedsearch
ERROR - 2020-06-01 06:14:31 --> 404 Page Not Found: Blog/vendor
ERROR - 2020-06-01 06:14:37 --> 404 Page Not Found: System/vendor
ERROR - 2020-06-01 06:15:04 --> 404 Page Not Found: Modules/gamification
ERROR - 2020-06-01 06:15:41 --> 404 Page Not Found: Shop/vendor
ERROR - 2020-06-01 06:15:47 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-06-01 06:32:11 --> Severity: Notice --> Undefined variable: extract /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 60
ERROR - 2020-06-01 06:32:11 --> Severity: error --> Exception: Function name must be a string /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 60
ERROR - 2020-06-01 06:32:15 --> Severity: Notice --> Undefined variable: extract /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 60
ERROR - 2020-06-01 06:32:15 --> Severity: error --> Exception: Function name must be a string /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 60
ERROR - 2020-06-01 06:33:12 --> Severity: Notice --> Undefined property: User::$upload /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 63
ERROR - 2020-06-01 06:33:12 --> Severity: error --> Exception: Call to a member function initialize() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 63
ERROR - 2020-06-01 06:34:37 --> Severity: Notice --> Undefined property: User::$upload /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 63
ERROR - 2020-06-01 06:34:37 --> Severity: error --> Exception: Call to a member function initialize() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 63
ERROR - 2020-06-01 06:40:49 --> Severity: error --> Exception: Call to undefined method CI_Upload::register() /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 85
ERROR - 2020-06-01 06:44:53 --> 404 Page Not Found: Modules/set-params
ERROR - 2020-06-01 06:57:30 --> Severity: Notice --> Array to string conversion /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 67
ERROR - 2020-06-01 06:58:16 --> Severity: Notice --> Undefined index: resume /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 67
ERROR - 2020-06-01 07:02:15 --> Severity: Notice --> Array to string conversion /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 67
ERROR - 2020-06-01 07:02:15 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:10:44 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:11:35 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:12:34 --> Severity: Notice --> Undefined index: userfile /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 84
ERROR - 2020-06-01 07:15:47 --> Severity: Warning --> Illegal offset type in isset or empty /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 377
ERROR - 2020-06-01 07:15:47 --> Severity: Warning --> preg_match_all() expects parameter 2 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 382
ERROR - 2020-06-01 07:19:13 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:24:20 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:32:33 --> Severity: Warning --> is_uploaded_file() expects parameter 1 to be string, array given /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/libraries/Upload.php 412
ERROR - 2020-06-01 07:33:29 --> The file could not be written to disk.
ERROR - 2020-06-01 07:33:46 --> The file could not be written to disk.
ERROR - 2020-06-01 07:35:41 --> The file could not be written to disk.
ERROR - 2020-06-01 07:37:30 --> The file could not be written to disk.
ERROR - 2020-06-01 07:37:56 --> Severity: Notice --> Undefined property: User::$db /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 93
ERROR - 2020-06-01 07:37:56 --> Severity: error --> Exception: Call to a member function insert() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 93
ERROR - 2020-06-01 07:53:36 --> 404 Page Not Found: Modules/utils
ERROR - 2020-06-01 07:56:19 --> Severity: Notice --> Undefined property: User::$db /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 94
ERROR - 2020-06-01 07:56:19 --> Severity: error --> Exception: Call to a member function insert() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 94
ERROR - 2020-06-01 07:56:50 --> Severity: Notice --> Undefined property: User::$db /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 95
ERROR - 2020-06-01 07:56:50 --> Severity: error --> Exception: Call to a member function insert() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 95
ERROR - 2020-06-01 07:57:07 --> Severity: Notice --> Undefined property: User::$db /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 96
ERROR - 2020-06-01 07:57:07 --> Severity: error --> Exception: Call to a member function insert() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 96
ERROR - 2020-06-01 07:57:59 --> Severity: Notice --> Undefined property: User::$db /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 93
ERROR - 2020-06-01 07:57:59 --> Severity: error --> Exception: Call to a member function insert() on null /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 93
ERROR - 2020-06-01 07:59:58 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'w1ft43q4sr3u'@'localhost' (using password: NO) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-06-01 07:59:58 --> Unable to connect to the database
ERROR - 2020-06-01 07:59:59 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'w1ft43q4sr3u'@'localhost' (using password: NO) /home/w1ft43q4sr3u/public_html/digitalwebmark.com/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2020-06-01 07:59:59 --> Unable to connect to the database
ERROR - 2020-06-01 08:02:24 --> Query error: Table 'digitalwebmarkdb.entries' doesn't exist - Invalid query: INSERT INTO `entries` (`name`, `phone`, `email`, `address`, `whyhire`, `resume_name`) VALUES ('Abu bakker usman akram', '+923135300473', 'abubkr.akram@gmail.com', 'House No. 96, Street no. 3, Sher-e-Rabbani Town', 'sda', 'Abu_bakker_usman_akram1590998544.pdf')
ERROR - 2020-06-01 08:16:27 --> Query error: Table 'digitalwebmarkdb.entries' doesn't exist - Invalid query: INSERT INTO `entries` (`name`, `phone`, `email`, `address`, `whyhire`, `resume_name`) VALUES ('Abu bakker usman akram', '+923135300473', 'abubkr.akram@gmail.com', 'House No. 96, Street no. 3, Sher-e-Rabbani Town', 'sda', 'Abu_bakker_usman_akram1590999387.pdf')
ERROR - 2020-06-01 08:16:40 --> Query error: Table 'digitalwebmarkdb.aplicantstable' doesn't exist - Invalid query: INSERT INTO `aplicantstable` (`name`, `phone`, `email`, `address`, `whyhire`, `resume_name`) VALUES ('Abu bakker usman akram', '+923135300473', 'abubkr.akram@gmail.com', 'House No. 96, Street no. 3, Sher-e-Rabbani Town', 'sda', 'Abu_bakker_usman_akram1590999400.pdf')
ERROR - 2020-06-01 08:23:41 --> Severity: Notice --> Undefined variable: skills /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 65
ERROR - 2020-06-01 08:33:30 --> 404 Page Not Found: Modules/handle-swal-dom
ERROR - 2020-06-01 08:35:07 --> Severity: Notice --> Undefined variable: html /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 66
ERROR - 2020-06-01 08:35:07 --> Severity: Notice --> Undefined variable: css3 /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 66
ERROR - 2020-06-01 08:39:49 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE), expecting ',' or ';' /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 71
ERROR - 2020-06-01 08:40:02 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE), expecting ',' or ';' /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 71
ERROR - 2020-06-01 09:09:41 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:09:47 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:11:04 --> Severity: error --> Exception: Call to undefined method User::assignTitle() /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 134
ERROR - 2020-06-01 09:12:02 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:12:03 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:12:03 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:12:03 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:12:03 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:15:01 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:15:02 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:15:03 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:15:04 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:15:04 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:17:52 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:17:53 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:17:53 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:17:53 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:17:53 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:17:57 --> 404 Page Not Found: User/careers
ERROR - 2020-06-01 09:18:12 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:18:28 --> Severity: Notice --> Undefined variable: html_level /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 67
ERROR - 2020-06-01 09:18:28 --> Severity: Notice --> Undefined variable: css3_level /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/controllers/User.php 67
ERROR - 2020-06-01 09:18:28 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:18:30 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:31 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:18:40 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:41 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:18:41 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:47 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:18:48 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:48 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:49 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:18:49 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:25:25 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:25:26 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:25:26 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:25:26 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:25:26 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:26:36 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:26:36 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:26:37 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:26:37 --> 404 Page Not Found: User/assets
ERROR - 2020-06-01 09:26:37 --> 404 Page Not Found: User/bootstrap.js.map
ERROR - 2020-06-01 09:29:10 --> 404 Page Not Found: User/careers
ERROR - 2020-06-01 09:29:25 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:30:35 --> Severity: Notice --> Undefined variable: message /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/careers.php 128
ERROR - 2020-06-01 09:33:44 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-01 10:33:12 --> 404 Page Not Found: Modules/handle-key
ERROR - 2020-06-01 11:08:00 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-06-01 14:59:12 --> 404 Page Not Found: Modules/handle-click
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-01 16:24:15 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-01 16:24:26 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
