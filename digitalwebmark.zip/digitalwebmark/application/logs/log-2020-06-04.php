<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-04 01:20:31 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-04 08:27:06 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-04 08:27:06 --> 404 Page Not Found: Img/About-Company
ERROR - 2020-06-04 08:27:06 --> 404 Page Not Found: Assets/Digital_webmark_stacked-01-01.png
ERROR - 2020-06-04 08:27:10 --> 404 Page Not Found: Assets/Digital_webmark_stacked-01-01.png
ERROR - 2020-06-04 08:27:11 --> 404 Page Not Found: Assets/download.jpg
ERROR - 2020-06-04 08:27:11 --> 404 Page Not Found: Assets/asset-1502350566538.png
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-04 08:50:14 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-06-04 13:18:09 --> 404 Page Not Found: Api/vendor
ERROR - 2020-06-04 15:41:41 --> 404 Page Not Found: Php/sendEmail.php
