<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-31 07:15:50 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-31 12:12:41 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-31 14:12:20 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/varien
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/mage
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/mage
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/mage
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Skin/adminhtml
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/lib
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/mage
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/varien
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/prototype
ERROR - 2020-08-31 15:11:55 --> 404 Page Not Found: Js/varien
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Js/mage
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Js/varien
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Js/js.js
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Images/wlw
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Static/admin
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Core/CHANGELOG.txt
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Misc/druplicon.png
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: Misc/drupal.js
ERROR - 2020-08-31 15:11:56 --> 404 Page Not Found: A/j
ERROR - 2020-08-31 15:11:57 --> 404 Page Not Found: Catalog/view
ERROR - 2020-08-31 15:11:57 --> 404 Page Not Found: Order/catalog
ERROR - 2020-08-31 15:11:57 --> 404 Page Not Found: Catalog/view
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/eccube.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/eccube.legacy.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/css.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/navi.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/win_op.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/site.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Js/locale.js
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: User_data/css
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: Template/admin
ERROR - 2020-08-31 15:11:58 --> 404 Page Not Found: User_data/packages
ERROR - 2020-08-31 15:11:59 --> 404 Page Not Found: Administrator/manifests
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-31 17:02:16 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-31 19:04:02 --> 404 Page Not Found: Php/sendEmail.php
ERROR - 2020-08-31 19:16:16 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2020-08-31 19:41:42 --> 404 Page Not Found: Blogs/blogs
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(php/head.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(): Failed opening 'php/head.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 7
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(php/nav.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(): Failed opening 'php/nav.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 12
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(php/footer.php): failed to open stream: No such file or directory /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
ERROR - 2020-08-31 22:26:19 --> Severity: Warning --> include(): Failed opening 'php/footer.php' for inclusion (include_path='.:/opt/alt/php72/usr/share/pear') /home/w1ft43q4sr3u/public_html/digitalwebmark.com/application/views/RefundPrivacy.php 45
