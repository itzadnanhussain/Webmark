<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    public function popupSendEmail()
	{
        $errors = '';
        if ($_SERVER['REQUEST_METHOD'] == 'POST')
        {
            $this->form_validation->set_rules('name',"Name","required|trim");
    		$this->form_validation->set_rules('email',"Email","required|trim");
    		$this->form_validation->set_rules('message',"Message","required|trim");
            if ($this->form_validation->run() == false) 
    		{
    			die(validation_errors().'-red-');
    		}
            extract($_POST);
            
            if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",$email))
            {
                die("Invalid email address-red-");
            }
            $subject="Digital Web Marketing";
            
            $to="info@digitalwebmark.com";
            $headers="From: ".$email;
            $message="Name: ".$name."\n\rMessage: ".$message;
            if(mail($to,$subject,$message,$headers)){
                die("Message Sent Successfully-green-");
            }
            echo "There has been error-red-";
        }
        else{
        echo "<h2>Access Denied</h2>";
        }
	}
}
