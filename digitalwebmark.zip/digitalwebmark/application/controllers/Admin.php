<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Admin extends CI_Controller
{
   

    public function AdminLogin()
    {
        if ($this->input->is_ajax_request()) {
            // $this->load->helper('functions_helper');
            // $this->load->helper('query_helper');
            ///Set Form Validation
            $this->form_validation->set_rules('email', 'Email', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
            ////After Validation
            if ($this->form_validation->run()) {

                extract($_POST);

                $where = array('email' => $email);
                ///add Records into DataBase
                $data = GetByWhere('usertable', '*', $where);
                if ($data) {
                    $check = password_verify($password, $data[0]->password);
                    if ($check) {
                        $data = array(
                            'name' => $data[0]->name,
                            'email' => $data[0]->email,
                            'user_id' => $data[0]->user_id,
                            'user_type' => $data[0]->user_type,
                            'logged_in' => True
                        );
                        ///Set Session
                        $this->session->set_userdata($data);
                        $data = array('code' => 'success', 'message' => 'Success Logged in');
                        echo json_encode($data);
                        die;
                    } else {
                        $data = array('code' => 'warning', 'message' => 'Password not Match');
                        echo json_encode($data);
                        die;
                    }
                } else {
                    $data = array('code' => 'warning', 'message' => 'Record Not Exists');
                    echo json_encode($data);
                    die;
                }
            } else {
                $error_array = array();
                foreach (array_merge($_POST, $_FILES) as $key => $value) {
                    if (form_error($key)) {
                        $error_array[] = array($key, form_error($key, null, null));
                    }
                }
                $data = array('code' => 'error', 'message' => $error_array);
                echo json_encode($data);
                die;
            }
        } else {
            // $this->load->helper('view_load_helper');
            $title = "Admin Sign In";
            $data = array();
            $page = 'login';
            Pageview($page, $data, $title);
        }
    }


    ///load Applicant Table
    public function LoadTableApplicants()
    {
        $this->load->helper('view_load_helper');
        $this->load->helper('functions_helper');
        $this->load->helper('query_helper');
        $title = "Admin Sign In";
        $data['records'] = getByWhere('applicantstable', '*', array(), array('id', 'DESC'));
        $page = 'applicant_tb';
        Pageview($page, $data, $title);
    }

    ///ViewResume
    public function ViewResume()
    {
        $fname = $this->uri->segment(2);
        $tofile = FCPATH . "/uploads/" . $fname;
        $this->load->helper('view_load_helper');
        $data['file'] = $fname;
        $title = "View Admin Resume";
        $page = 'resumeView';
        Pageview($page, $data, $title);


        // header('Content-Type: application/pdf');
        // readfile($tofile);
    }
    ///file_download
    public function file_download()
    {
        $fname = $this->uri->segment(2);

        $tofile = FCPATH . "/uploads/" . $fname;
        $file_name = $this->input->get($tofile);

        $this->load->helper('download');
        $data = file_get_contents($file_name);
        force_download($fname, $data);
        //force_download($file_name, NULL); will get the file name for you
    }

    //Delete
    public function Delete()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->helper('query_helper');
            extract($_POST);
            $result = deleteRecordWhere($table, array('id' => $id));
            if ($result) {
                $data = array('code' => 'done');
                echo json_encode($data);
                die;
            }
        }
    }

    ///SendUserEmail
    public function SendUserEmail()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');

            ///check validation
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('phone', 'Phone', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('message', 'Message', 'required');

            if ($this->form_validation->run() == true) {
                extract($_POST);
                // Define email data
                $mailData = array(
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'address' => $address,
                    'message' => $message
                );
                // Send an email to the site admin
                $send = $this->sendEmail($mailData);
                // Check email sending status
                if ($send) {
                    $data = array('code' => 'success', 'message' => 'email has been send');
                    echo json_encode($data);
                    die;
                } else {
                    $data = array('code' => 'warning', 'message' => 'email has been not send');
                    echo json_encode($data);
                    die;
                }
            } else {
                $error_array = array();
                foreach (array_merge($_POST, $_FILES) as $key => $value) {
                    if (form_error($key)) {
                        $error_array[] = array($key, form_error($key, null, null));
                    }
                }
                $data = array('code' => 'error', 'message' => $error_array);
                echo json_encode($data);
                die;
            }
        }
    }


    ///sendEmail
    function sendEmail($mailData)
    {
        // Load the email library
        $this->load->library('email'); 
        // Mail config
        $to = 'dani1707276@gmail.com';
        $from = $mailData['email'];
        $fromName = $mailData['name'];
        $mailSubject = 'Contact Request Submitted by ' . $mailData['name'];

        // Mail content
        $mailContent = '
           <h2>Contact Request Submitted</h2>
           <p><b>Name: </b>' . $mailData['name'] . '</p>
           <p><b>Email: </b>' . $mailData['email'] . '</p>
           <p><b>Email: </b>' . $mailData['phone'] . '</p> 
           <p><b>Message: </b>' . $mailData['message'] . '</p>
       ';

        $config['mailtype'] = 'html';
        $this->email->initialize($config);
        $this->email->to($to);
        $this->email->from($from, $fromName);
        $this->email->subject($mailSubject);
        $this->email->message($mailContent);

        // Send email & return status
        return $this->email->send() ? true : false;
    }
}
