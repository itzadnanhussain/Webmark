<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Career extends CI_Controller
{
    



    public function AddNewCareer()
    {
        if ($this->input->is_ajax_request()) {
            $this->load->helper('functions_helper');
            $this->load->helper('query_helper');

            ///Set Form Validation
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('phone', 'Phone', 'trim|required');
            $this->form_validation->set_rules('email', 'Email', 'trim|required');
            $this->form_validation->set_rules('address', 'Address', 'trim|required');
            $this->form_validation->set_rules('whyhire', 'whyhire', 'trim|required');
            if (isset($_FILES['resume']['name']) && empty($_FILES['resume']['name'])) {
                $this->form_validation->set_rules('resume', 'Resume', 'required');
            }

            ////After Validation
            if ($this->form_validation->run()) {
                extract($_POST);
                $count = count($skills);
                $str = "";
                for ($i = 0; $i < $count; $i++) {
                    if ($skills[$i] == 'html' && isset($html_level)) {
                        $str .= ", HTML: " . $html_level;
                    }
                    if ($skills[$i] == 'css3' && isset($css3_level)) {
                        $str .= ", CSS3: " . $css3_level;
                    }
                    if ($skills[$i] == 'bs' && isset($bs_level)) {
                        $str .= ", Bootstrap: " . $bs_level;
                    }
                    if ($skills[$i] == 'js' && isset($js_level)) {
                        $str .= ", Javascript: " . $js_level;
                    }
                    if ($skills[$i] == 'jq' && isset($jq_level)) {
                        $str .= ", Jquery: " . $jq_level;
                    }
                    if ($skills[$i] == 'php' && isset($php_level)) {
                        $str .= ", PHP: " . $php_level;
                    }
                    if ($skills[$i] == 'ci' && isset($ci_level)) {
                        $str .= ", Codeigniter: " . $ci_level;
                    }
                }
                $data['skills'] = $str;
                $data['name'] = $name;
                $data['phone'] = $phone;
                $data['email'] = $email;
                $data['address'] = $address;
                $data['whyhire'] = $whyhire;
                $data['date'] = date("d M Y G:i:s");


                ////image upload 
                if (isset($_FILES['resume']['name']) && !empty($_FILES['resume']['name'])) {

                    //create directory path
                    $dir_path = FCPATH . 'uploads/';
                    if (!is_dir($dir_path)) {
                        mkdir($dir_path, 0777, true);
                    }
                    $config['upload_path'] = $dir_path;
                    $config['allowed_types'] = 'pdf';
                    $config['file_name'] = $name . rand();
                    $config['overwrite'] = true;
                    $this->load->library('upload', $config);
                    if ($this->upload->do_upload('resume')) {
                        $data1 = $this->upload->data();
                        $data['resume_name'] = $data1['file_name'];
                    } else {
                        $data = array('code' => 'warning', 'message' => 'Only PDF File Allowed');
                        echo json_encode($data);
                        die;
                    }
                }
                $where = array('email' => $email);
                ///add Records into DataBase
                $check_record = GetByWhere('applicantstable', '*', $where);
                if (!$check_record) {
                    $last_id = addNew('applicantstable', $data);
                    if ($last_id) {
                        $data = array('code' => 'success', 'message' => 'Record added Successfully!');
                        echo json_encode($data);
                        die;
                    }
                } else {
                    $data = array('code' => 'warning', 'message' => 'Record Already Exists');
                    echo json_encode($data);
                    die;
                }
            } else {
                $error_array = array();
                foreach (array_merge($_POST, $_FILES) as $key => $value) {
                    if (form_error($key)) {
                        $error_array[] = array($key, form_error($key, null, null));
                    }
                }
                $data = array('code' => 'error', 'message' => $error_array);
                echo json_encode($data);
                die;
            }
        } else {
            $this->load->helper('view_load_helper'); 
            $title = "Career";
            $data = array();
            $page = 'careers';
            Pageview($page, $data, $title);
        }
    }

    ///ViewClientRecords
    public function ViewClientRecords()
    {
        $this->load->helper('view_load_helper');
        $this->load->helper('functions_helper');
        $this->load->helper('query_helper');
        $id = $this->uri->segment(3);
        $title = "Clients View Records";
        $data['records'] = getByWhere('applicantstable','*',array('id'=>$id));
        
        $page = 'customer';
        Pageview($page, $data, $title);
    }
}
