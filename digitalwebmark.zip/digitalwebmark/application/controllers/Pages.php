<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
    
    public function index()
	{
        
        $this->loadView('main');
	}
	public function view($view)
	{
         
        $this->loadView($view);
	}
    public function blogView($view)
	{
        $this->loadView("blogs/".$view);
    }
    
    public function loadView($view){
        
        $data["title"]="";
        if (strpos($view, 'blogs/') !== false) {
            
           $data["title"]=$this->assignTitle(explode("/",$view)[1]);
        }
        else{
            

            $data["title"]=$this->assignTitle($view);
        }
        $this->load->view('template/head',$data);
        //echo $view;
        $this->load->view($view);
        $this->load->view('template/footer');
    }
    function assignTitle($view){
        $flag=0;
        $titles = array("main"=>"DigitalWebMark - A Leading SEO, digital Marketing and Web design Dubai Company","aboutPage"=>"About Us| DigitalWebMark");
        foreach($titles as $title => $title_value) {
            if($title==$view){
                $flag=1;
                return $title_value;
            }
        }
        if($flag==0){
            return $view;
        }
    
    }
}
