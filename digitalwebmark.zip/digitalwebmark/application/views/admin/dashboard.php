<div class="row">
    <div class="col-md-12"> 
        <form action="#" method="post" novalidate="novalidate">
            <div class="row">
                <div class="col-md-2 ">
                </div>
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-3 p-0">
                            <input type="datetime-local" class="form-control datetime search-slt" placeholder="Enter Date">
                        </div>
                        <div class="col-md-2 p-0">
                            <input type="number" class="form-control search-slt" placeholder="Extension">
                        </div>
                        <div class="col-md-2 p-0">
                            <input type="number" class="form-control search-slt" placeholder="Destination">
                        </div>
                        <div class="col-md-1 p-0">
                            <button type="button" class="btn btn-info"><i class="fa fa-search"></i> Search</button>
                        </div>
                        <div class="col-md-1 p-0">
                            <button type="button" class="btn btn-info"><i class="fa fa-download"></i> Bulk</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="col-md-2 quickmenu">
    <h5>Quick Menu</h5>
        <a href="#" class="a-active">Recordings</a>
        <a href="#">Call History</a>
        <a href="#">Active Calls</a>
    </div>
    
    <div class="col-md-10">
        <table>
            <tr>
                <th>
                    <a href="#">Select All</a>
                    <a href="#"> <i class="fa fa-download btn btn-info"></i></a>
                </th>
                <th>
                    Date
                </th>
                <th>
                    Time
                </th>
                <th>
                    Duration
                </th>
                <th>
                    Source
                </th>
                <th>
                    Destination
                </th>
                <th>
                    Extension/Device ID
                </th>
                <th>
                    Recording
                </th>
            </tr>
            <tr>
                <td>
                    <input type="checkbox">
                </td>
                <td>
                    11/22/2020
                </td>
                <td>
                    01:23:24
                </td>
                <td>
                    23:24
                </td>
                <td>
                    123456789
                </td>
                <td>
                    3646465456
                </td>
                <td>
                    1245
                </td>
                <td>
                    <audio controls>
                      <source src="horse.mp3" type="audio/mpeg">
                      Your browser does not support the audio element.
                    </audio>
                </td>
            </tr>
            <tr>
                <td>
                    <input type="checkbox">
                </td>
                <td>
                    11/22/2020
                </td>
                <td>
                    01:23:24
                </td>
                <td>
                    23:24
                </td>
                <td>
                    123456789
                </td>
                <td>
                    3646465456
                </td>
                <td>
                    1245
                </td>
                <td>
                    <audio controls>
                      <source src="horse.mp3" type="audio/mpeg">
                      Your browser does not support the audio element.
                    </audio>
                </td>
            </tr>
            <tr>
                <td>
                    <input type="checkbox">
                </td>
                <td>
                    11/22/2020
                </td>
                <td>
                    01:23:24
                </td>
                <td>
                    23:24
                </td>
                <td>
                    123456789
                </td>
                <td>
                    3646465456
                </td>
                <td>
                    1245
                </td>
                <td>
                    <audio controls>
                      <source src="horse.mp3" type="audio/mpeg">
                      Your browser does not support the audio element.
                    </audio>
                </td>
            </tr>
        </table>
        <br>
                            <a href="#"><i class="fa fa-download"></i> Download Table as CSV </a>
    </div>
</div>