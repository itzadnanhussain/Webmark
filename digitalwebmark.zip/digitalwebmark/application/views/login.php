<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<div class="container">

    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <h3 class="text-center">Login</h3>
            <form id="contact-form">
                <div class="form-group">
                    <input type="text" name="email" class="form-control" placeholder="Enter Email">
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control" placeholder="Password">
                </div>
                <div class="form-group">
                    <input type="submit" id="submit-btn" class="form-control btn btn-primary" value="Login">
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $('#contact-form').submit(function(e) {
        e.preventDefault();
        var form = $(this).serialize();
        $.ajax({
            beforeSend: function()
            {
                $('#submit-btn').val('Processing...');
            },
            type: 'POST',
            data: form,
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        swal('Success', res.message, 'success', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.href="<?php echo base_url('applicants') ?>";
                        }, 3000)

                        break;
                    case 'warning':
                        swal('Warning', res.message, 'warning', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.reload();
                        }, 3000)

                        break;

                    case 'error':
                        res.message.forEach(function(error) {
                            $('[name=' + error[0] + ']').parent().append('<p style="color:red;font-size:12px">' + error[1] + '</p>');
                        })
                        break;

                }

            },
            complete: function()
            {
                $('#submit-btn').val('Submit');
            },
           
        });
    });
</script>