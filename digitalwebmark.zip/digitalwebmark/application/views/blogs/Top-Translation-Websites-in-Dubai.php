
    <div class="container-fluid">
        <div class="banner center">
                <h1>Top translation websites in Dubai</h1>
        </div>
    </div>
    <!----content Section---->
    <section class="blog-pad">
        <div class="container">
            <!----Row Section 1---->
            <div class="row">
                <!----column 1---->
                <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 blog-border">
                    <div>
                        <img class="img-responsive" src="<?php echo base_url()?>assets/img/blog/Top-Translation-Websites-in-Dubai.png" alt="Top translation websites in Dubai">
                    </div>
                    <p>
                        <a href=""></a>
                    </p>
                </div>
                <!----column 2---->

                <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 blog-padding">
                <?php $this->view('template/form.php');?>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 blog-border">
                    
                    
                    <h2></h2>
                    <p>
                        <a href="" rel="nofollow"></a> 
                    
                    </p>
                    
                    
                    <h2></h2>
                    <p>
                        <a href="" rel="nofollow"></a> 
                    
                    </p>
                    
                    
                    <h2></h2>
                    <p>
                        <a href="" rel="nofollow"></a> 
                    
                    </p>
                    
                    
                    <h2></h2>
                    <p>
                        <a href="" rel="nofollow"></a> 
                    
                    </p>
                </div>
            </div>
        </div>
        <br/>
    </section>