 
<!--footer bottom---->
<footer>
    <div class="container center footer">
        <div class="row">
            <div class="col-lg-2 col-md-3 col-sm-12 block">
                
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 block">
                <h2 >Quick Links</h2>
                <a href="<?php echo base_url();?>" title="Home">Home </a>
                <a href="portfolioPage" title="Portfolio"> Portfolio </a>
                <a href="blogPage" title="Blog">Our Blog </a>
                <a href="aboutPage" title="About Us"> About Us </a>
                <a href="contactPage" title="Contact Us"> Contact Us </a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 block">
                <h2 >Services</h2>
                <a href="CustomWebsiteDevelopment">Custom website development Dubai</a>
                <a href="ResponsiveWebDesignDubai">Responsive webdesign Dubai</a>
                <a href="SearchEngineOptimization">Search Engine Optimization</a>
                <a href="EcommerceWebsiteDevelopment">E-commerce website development</a>
                <a href="DigitalMarketing">Digital Marketing</a>

            </div>
            <div class="col-lg-3 col-md-3 col-sm-12 block">
                <h2 >Contact</h2>
                <a href="mailto:info@digitalwebmark.com" title="email">info@digitalwebmark.com</a>
                <a href="tel:+971 50 110 4680" title="Phone no.">+971-50-110-4680</a>
                <a  title="Address"> Al Attar Tower, Sheikh zayed road<br/> Dubai </a>
                
            </div>
        </div>
    </div>
        <div class="footer_bottom">
            <div class="row">
                <div class="col-md-2">
                </div>
                <div class="col-md-4">
                <a>Copyright © 2019 DigitalWebMark </a>
                </div>
                <div class="col-md-1">
                <a href="#" title="Terms of use">Terms of use</a>
                </div>
                <div class="col-md-1">
                <a href="privacypolicy" title="privacy policy">Privacy policy</a>
                </div>
                <div class="col-md-1">
                <a href="RefundPrivacy" title="Refund Policy">Refund Policy</a>
                </div>
                <div class="col-md-2">
                </div>
            </div>
        </div>
            
        </div>
</footer>

<?php $this->view('template/Popupform');?>
<?php $this->view('template/ScrollButton');?>
<?php $this->view('template/load_js');?> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
     $('.phone').mask('0000-0000000');
</script>
 
<!--Start of HubSpot Embed Code 
<script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/5978873.js"></script>-->
</body>
</html>