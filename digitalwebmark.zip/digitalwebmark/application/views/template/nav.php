<header>
    <div class="top_bar">
        <div class="row">
            <div class="pull-right">
                
                <a href="tel:+971 50 110 4680" title="Contact Us"><i class="icon-mobile"></i>+971 50 110 4680</a>
                <a href="email:info@digitalwebmark.com" title="Contact Us"><i class="icon-email"></i>info@digitalwebmark.com</a>
            </div>
        </div>
    </div>
    <nav class="navbar nav-back-color"><!-- class=navbar-fixed-top-->
        <div class="container-fluid">
            <div class="navbar-header">
                <a id="nav" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar"><i class="icon-menu"></i></a>
                <a class="navbar-bran" href="<?php echo base_url()?>" title="Go to Home Page"><img class="margin-left img-responsive nav_img" src="<?php echo base_url();?>assets/img/digitalwebmark.png" alt="DigitalWebMark - a web design company in Dubai"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <!----Drop Down Menu------------->
                    <li class="active dropdown"><a href="digital-web-services">Services</a>
                        <div class="dropdown-content">
                            <a href="CustomWebsiteDevelopment">Custom website development</a>
                            <a href="ResponsiveWebDesignDubai">Responsive webdesign</a>
                            <a href="CMSWebsiteDevelopment"> CMS website development</a>
                            <a href="EcommerceWebsiteDevelopment">E-commerce website development</a>
                            <a href="DigitalMarketing">Digital Marketing</a>
                            <a href="SearchEngineOptimization">SEO</a>
                        </div>
                    </li>
                    <!----Drop Down Menu End------------->
                    <li><a href="portfolioPage" title="Portfolio">Portfolio</a></li>
                <li><a href="careers" title="Careers">Careers</a></li>
                    <li><a href="<?php echo base_url();?>blogPage" title="Go To Blog">Blog</a></li>
                    <li><a href="aboutPage" title="About Us">About</a></li>
                    <li><a href="contactPage" title="Contact Us">Contact</a></li>
                </ul>
            </div>
        </div>
        <div class="progress-container">
            <div class="progress-bar" id="myBar"></div>
        </div>
    </nav>
</header>