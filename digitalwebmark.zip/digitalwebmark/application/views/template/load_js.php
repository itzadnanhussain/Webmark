<script>
    <?php   
        /*******Js Plugins***********/
		       include getcwd()."/assets/js/bootstrap.js"; 
		       include getcwd()."/assets/js/custom.js";
        /******SweetAlert Plugins*******/ 
               //include getcwd()."/assets/js/sweetalert.min.js"; 
	?>
    
</script>