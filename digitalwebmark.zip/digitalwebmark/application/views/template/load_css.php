<style>
    <?php
    
    echo "\n\n /*Bootstrap css*/ \n\n";
    include getcwd().'/assets/css/bootstrap.min.css';
    
    echo "\n\n /* owl.carousel.min css*/ \n\n";
    include getcwd().'/assets/css/owl/owl.carousel.min.css';
    
    echo "\n\n /* owl.theme.default css*/ \n\n";
    include getcwd().'/assets/css/owl/owl.theme.default.css';
    
    echo "\n\n /* slider css*/ \n\n";
    include getcwd().'/assets/css/slider.css';
    
    //echo "\n\n /* sweetalert css*/ \n\n";
    //include getcwd().'/assets/css/sweetalert.css';
    
    echo "\n\n /* animate css*/ \n\n";
    include getcwd().'/assets/css/animate.min.css';
    
    
    //echo "\n\n /* form css*/ \n\n";
    //include 'assets/css/form.css';
    
    echo "\n\n /* mediaQuery css*/ \n\n";
    include getcwd().'/assets/css/mediaQuery.css';
    
    echo "\n\n /* custom css*/ \n\n";
    include getcwd().'/assets/css/custom.css';
    ?>
</style>