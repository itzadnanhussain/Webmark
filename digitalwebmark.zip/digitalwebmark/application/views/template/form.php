<!----=============================Form HTML==================================-->
<div class="form_main margin-left">
    <h3 class="heading">Contact us</h3>
    <div class="form">
        <form name="contactform" method="post" action="php/sendEmail.php" id="contactform">
            <input type="text" required placeholder="Please input your Name" name="name" class="form_txt_ctrl">
            <input type="text" required placeholder="Please input your mobile No" name="phone" class="form_txt_ctrl">
            <input type="text" required placeholder="Please input your Email" name="email" class="form_txt_ctrl">
            <input type="text" required placeholder="Please input your Address" name="Address" class="form_txt_ctrl">
            <textarea placeholder="Your Message" name="message" type="text" class="form_txt_ctrl"></textarea>
            <input type="submit" value="submit" name="submit" class="default-btn">
        </form>
    </div>
</div>