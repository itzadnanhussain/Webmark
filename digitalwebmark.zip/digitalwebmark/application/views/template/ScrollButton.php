<!---Html---->
<a href="#" class="scrollToTop"><span class="icon-arrow-up"></span></a>