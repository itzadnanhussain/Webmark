<!--open form button coding---->

<div  id="pop" class="form-open-button animated bounceInUp default-bg" onclick="openForm()">
	<a  title="Open form" onclick="closeForm()"><i class="icon-user "> Leave a message </i><i class="icon-circle-up"></i> </a>
</div>

<!--form coding---->
<div class="form-popup" id="popupForm">
	<div class="form-popup-header default-bg" id="pop">
		<p>Leave a message</p><a title="Minimize" onclick="closeForm()"><i class="icon-minus"></i></a>
	</div>
    
	<form action="<?php echo base_url();?>user/popupSendEmail" method="post" class="form-container center" id="myForm">
		<p>There are no agents available right now to take your call. Please leave a message and we will reply by email.</p>
		<input type="text" required placeholder="Please input your Name" name="name" class="form_txt_ctrl"/>
		<input type="text" placeholder="Enter your Email" name="email" class="form_txt_ctrl" required/> 
		<textarea placeholder="Your Message" name="message" type="text" class="form_txt_ctrl"></textarea>
        <div class="formstatus"></div>
		<input type="submit" value="Send" name="submit" class="default-btn"/> 
	</form>
</div>