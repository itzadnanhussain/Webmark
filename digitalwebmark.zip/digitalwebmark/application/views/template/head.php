<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    
<head>
<!---------------------------favicon--------------------------->
<link rel="shortcut icon" href="<?php echo base_url();?>assets/img/favicon.png"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"  />
<!---------- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131565120-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131565120-1');
</script>

<!---------------------Facebook Open Graph Meta Tags----------------------------->
 <meta property="og:image" content="http://digitalwebmark.com/img/About-Company/company.jpg"/>
 <meta property="og:title" content="Responsive Web Design,Development Dubai-Digital Web Marketing"/>
 <meta property="og:url" content="http://digitalwebmark.com"/>
 <meta property="og:site_name" content="Digital Web Mark"/>
 <meta property="og:type" content="Responsive Websites"/>
 <meta property="og:description" content="Top Ranking Responsive Web Development Company Dubai, UAE, Experts business websites, e-commerce, Digital Marketing, SEO, Content Writing." />
 <meta property="og:locale" content="en_US" />
 <!-------------------- Twitter Card data ---------------------------------------
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@DigitalWebMark">
<meta name="twitter:title" content="Digital Web Marketing">
<meta name="twitter:description" content="Top Ranking Responsive Web Development Company Dubai, UAE, Experts business websites, e-commerce, Digital Marketing, SEO, Content Writing.">
<meta name="twitter:creator" content="@DigitalWebMark"> 
<meta name="twitter:image" content="https://digitalwebmark.com/img/About-Company/company.jpg">

<!---------------------meta tags-----------------------------> 
<meta charset="UTF-8">
<meta name="description" content="DigitalWebMark is a Leading SEO, digital Marketing and Web design company in Dubai. Contact us for a free consultation or quote">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans&display=swap" rel="stylesheet">
<!----------------------- Css Plugins--------------------------> 
    
<?php $this->view('template/load_css.php');?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<title><?php if(isset($title)){
    echo $title;}?></title>
</head>
<body>
<?php $this->view('template/nav.php');?>
    