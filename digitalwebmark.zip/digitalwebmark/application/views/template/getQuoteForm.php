<!DOCTYPE html>
<html lang="en">

<head>
    <title>Digitalwebmark – Get your best Quote</title>
    <?php include 'php/head.php';  ?>
</head>

<body>

	<?php include 'php/nav.php';  ?>
            <div class="container-fluid">
                    <div class="banner center">
                        <h1>Get your best Quote</h1>
                    </div>
            </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="form">
                    <form name="contactform" method="post" action="php/sendEmail.php" id="messageform">
                      <div class="form-group">
                        <label for="name" class="control-label">Name</label> 
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-address-card"></i>
                          </div> 
                          <input id="name" name="firstname" type="text" required="required" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="email" class="control-label">Email</label> 
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-envelope"></i>
                          </div> 
                          <input id="email" name="email" type="email" required="required" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="phone" class="control-label">Phone number</label> 
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-phone"></i>
                          </div> 
                          <input id="phone" name="phone" type="text" required="required" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="subject" class="control-label">Subject</label> 
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-adn"></i>
                          </div> 
                          <input id="subject" name="subject" type="text" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="content" class="control-label">Description</label> 
                        <textarea id="content" name="content" cols="40" rows="5" class="form-control"></textarea>
                      </div> 
                      <div class="form-group">
                        <input name="submit" type="submit" class="btn btn-primary" Value="Send"/>
                      </div>
                    </form>           
                </div>
            </div>
        </div>
    </div>
    <?php include 'php/footer.php'; ?>
</body>

</html>