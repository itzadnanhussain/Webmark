
    <div class="container-fluid">
        <div class="banner center">
            <h1>Portfolio</h1>
        </div>
        <!----content Section---->
        <section class="padding">
            <div class="container portfolio">
                <!--column 1--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/booking.jpg" alt="booking website" class="img-responsive">
                        </a>
                    </div>
                </div>
                <!--column 2--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/etsy.jpg" alt="e-commerce website" class="img-responsive">
                        </a>
                    </div>
                </div>
                <!--column 3--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/hotwire.jpg" alt="hotel booking web design" class="img-responsive">
                        </a>
                    </div>
                </div>

                <!--column 4--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/harvey.jpg" alt="Online shopping website" class="img-responsive">
                        </a>
                    </div>
                </div>

                <!--column 5--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/uo.jpg" alt="Online shopping website" class="img-responsive">
                        </a>
                    </div>
                </div>

                <!--column 6--->
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="#" class="caption" rel="nofollow">
                            <img src="<?php echo base_url();?>assets/img/portfolio/wool.jpg" alt="Online shopping website" class="img-responsive">
                        </a>
                    </div>
                </div>
            </div>
        </section>