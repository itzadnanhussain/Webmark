
    <div class="container-fluid">
        <div class="banner center">
            <h1>Our Services</h1>
        </div>
    </div>
    <!----content Section---->
    <section class="portfolio-column-4-area">
        <div class="container">
            <!----Row 1---->
            <div class="row">
                <!--column 1-->
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                        <a href="CustomWebsiteDevelopment">
                            <img src="<?php echo base_url();?>assets/img/services/responsive-website-development.jpeg" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="CustomWebsiteDevelopment">
                            Responsive Website Design &amp; development</a></h3>
                </div>
                <!--column 2-->
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                        <a href="CMSWebsiteDevelopment">
                            <img src="<?php echo base_url();?>assets/img/services/cms-web-development.jpg" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="CMSWebsiteDevelopment">CMS website development</a>
                    </h3>
                </div>
                <!--column 3-->
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                        <a href="EcommerceWebsiteDevelopment">
                            <img src="<?php echo base_url();?>assets/img/services/ecommerce-website-development.jpg" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="EcommerceWebsiteDevelopment">E-commerce website development</a>
                    </h3>
                </div>
            </div>
            <!----Row 2---->
            <div class="row">
                <!--column 1-->
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                        <a href="DigitalMarketing">
                            <img src="<?php echo base_url();?>assets/img/services/digital-marketing.jpg" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4">
                        <a href="DigitalMarketing">Digital Marketing</a></h3>
                </div>
                <!--column 2-->
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                        <a href="SearchEngineOptimization">
                            <img src="<?php echo base_url();?>assets/img/services/seo.png" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="SearchEngineOptimization">Search engine optimization</a>
                    </h3>
                </div>
                <!----column 3--
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                            <a href="ContentWritingServices">
                                    <img src="<?php echo base_url();?>assets/img/services/content-writing.jpg" class="img-responsive">
                            </a>
                                </div>
                                        <h3 class="h4">
                            <a href="ContentWritingServices">
                                            Content writing
</a>
                                        </h3>
                </div>
-->
            </div>
            <!----Row 3---
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="green-box">
                            <a href="GoogleAdWords">
                                    <img src="<?php echo base_url();?>assets/img/services/g_adwords.JPG" class="img-responsive">
                            </a>
                                </div>
                                        <h3 class="h4"><a href="ContentWritingServices">
                                            Google adword
</a>
                                        </h3>
                </div>
            </div>
            -->
        </div>
    </section>