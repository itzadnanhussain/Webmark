
    <div class="container-fluid">
        <div class="banner center">
            <h1>WELCOME TO OUR BLOG</h1>
        </div>
    </div>
    <!----Blog Section---->
    <section class="padding">
        <div class="container">
            <!----Row Section complete 1---->
            <div class="row">
                <!----1---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="<?php echo base_url()?>blogs/Never-Hire-a-Cheap-Web-Design-Company" class="caption">
                            <img src="<?php echo base_url()?>assets/img/blog/Never-Hire-a-Cheap-Web-Design-Company.jpg" alt="Never Hire a Cheap Web Design Company" class="img-responsive">
                        </a>
                    </div>
                    <div class="blog-text">
                        <h3 class="h4"><a href="<?php echo base_url()?>blogs/Never-Hire-a-Cheap-Web-Design-Company">Never Hire a Cheap Web Design Company</a></h3>
                        <p>Are you searching for a cheap web design company? We will clarify why the cost of a web design and development differs a great deal from company to company and why you should never hire a cheap web design company. […]</p>
                    </div>

                </div>
                <!----2---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="<?php echo base_url()?>blogs/Web-Designs-Statistics-Every-Business-Owner-Should-Know" class="caption">
                            <img src="<?php echo base_url()?>assets/img/blog/Web-Designs-Statistics-Every-Business-Owner-Should-Know.jpg" alt="Web Designs Statistics Every Business Owner Should Know" class="img-responsive">
                        </a>
                    </div>
                    <div class="blog-text">
                        <h3 class="h4"><a href="<?php echo base_url()?>blogs/Web-Designs-Statistics-Every-Business-Owner-Should-Know">Web Designs Statistics Every Business Owner Should Know</a></h3>
                        <p>Websites became necessary for every kind of business. You’ll be able to get a cool website by just hiring good web design company. Make sure, your web designer creates your website easy to use. […]</p>
                    </div>
                </div>


                <!----3---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="<?php echo base_url()?>blogs/Five-signs-of-Impressive-Web-Design">
                            <img src="<?php echo base_url()?>assets/img/blog/Five-signs-of-Impressive-Web-Design.jpg" alt="Five Signs of Impressive Web Design" class="img-responsive">
                        </a>
                    </div>

                    <div class="blog-text">
                        <h3 class="h4"><a href="<?php echo base_url()?>blogs/Five-signs-of-Impressive-Web-Design">Five Signs of Impressive Web Design</a></h3>
                        <p>For a company, impressive web designing is most important. Your website will be source of connection between your organization and most of the clients.[..]</p>
                    </div>
                </div>
                <!----4---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="<?php echo base_url()?>blogs/14-Stunning-Restaurant-Websites-Design-Inspiration">
                                <img src="<?php echo base_url()?>assets/img/blog/14-Stunning-Restaurant-Websites-Design-Inspiration.jpg" alt="14 Stunning Restaurant Websites Design Inspiration" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="<?php echo base_url()?>blogs/14-Stunning-Restaurant-Websites-Design-Inspiration">14 Stunning Restaurant Websites Design Inspiration</a></h3>
                    <p>The stunning restaurant sites have a single thing in common; pretty presentation. A good-looking design with beautiful imagery can fetch you many clients[..]</p>
                </div>

                <!----5---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="<?php echo base_url()?>blogs/7-Best-Online-Shopping-Websites-in-Dubai">
                                <img src="<?php echo base_url()?>assets/img/blog/7-Best-Online-Shopping-Websites-in-Dubai.jpg" alt="7 Best Online Shopping Websites in Dubai" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="<?php echo base_url()?>blogs/7-Best-Online-Shopping-Websites-in-Dubai">7 Best Online Shopping Websites in Dubai</a></h3>
                    <p>Dubai is popular for being a spot where all the people go to shopping. However, not every person has time or energy to visit shopping centers [..]</p>
                </div>


                <!----6---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="blogs/Top-Domain-Selling-Websites-in-Dubai">
                                <img src="<?php echo base_url()?>assets/img/blog/Top-Domain-Selling-Websites-in-Dubai.jpg" alt="Top Domain Selling and Hosting Websites in Dubai" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="blogs/Top-Domain-Selling-Websites-in-Dubai">Top Domain Selling and Hosting Websites in Dubai</a></h3>
                    <p>A domain is a name that illustrates your brand and provides you an online identification. Now in an advanced era, it’s the most important way to represent a recognizable identification [..]</p>
                </div>
                <!----7---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="blogs/Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration">
                                <img src="<?php echo base_url()?>assets/img/blog/Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration.jpg" alt="Top 10 Fast Food Restaurant Websites in Dubai for Design Inspiration" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="blogs/Top-10-Fast-Food-Restaurant-Websites-in-Dubai-for-Design-Inspiration">Top 10 Fast Food Restaurant Websites in Dubai for Design Inspiration</a></h3>
                    <p>The top best Dubai restaurant websites have to hold one of the things in same; eye attractive presentation. A stunning design with [..]</p>
                </div>
                
                <!----8---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="blogs/Top-4-low-cast-airlines-websites-in-Dubai">
                                <img src="<?php echo base_url()?>assets/img/blog/Top-4-low-cast-airlines-websites-in-Dubai.png" alt="Top Four low-cost airlines websites in Dubai" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="blogs/Top-4-low-cast-airlines-websites-in-Dubai">Top Four low-cost airlines websites in Dubai</a></h3>
                    <p>Low-cost online booking Airline websites of Dubai are listed here. You can search best route information for UAE by using these top four Dubai airline websites [..]</p>
                </div>
                
                
                
                <!----9---->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="blogs/Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream">
                                <img src="<?php echo base_url()?>assets/img/blog/Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream.jpg" alt="Top Five Breakout Website Design Trends Begging To Go Mainstream" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="blogs/Top-Five-Breakout-Website-Design-Trends-Begging-To-Go-Mainstream">Top Five Breakout Website Design Trends Begging To Go Mainstream</a></h3>
                    <p>In 2018, the website design industry experienced critical changes that are adjusting the manner in which we plan now. We started a year ago with the [..]</p>
                </div>
                
                <!----10--
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="green-box">
                        <a href="blogs/Top-Translation-Websites-in-Dubai">
                                <img src="<?php echo base_url()?>assets/img/blog/Top-Translation-Websites-in-Dubai.png" alt="Top Translation Websites in Dubai" class="img-responsive">
                        </a>
                    </div>
                    <h3 class="h4"><a href="blogs/Top-Translation-Websites-in-Dubai">Top Translation Websites in Dubai</a></h3>
                    <p>DDDDDDDDDD [..]</p>
                </div>
                -->
            </div>
        </div>
    </section>