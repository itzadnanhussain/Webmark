<html lang="en">

<head>
	<!----Title Section---->
	<title>Refund &amp; privacy policy</title>
	<!----head Section---->
	<?php include 'php/head.php';?>
</head>

<body>
	<!----Navigation Section---->
	<?php include 'php/nav.php';  ?>
	<!----Tiltle Section---->
	<div class="container-fluid">
					<div class="banner center">
						<h1>Refund &amp; privacy policy</h1>
					</div>
	</div>
	<!----content Section----
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12" id="refund-content">
				 
			
			
			
			
			</div>
		
		
		
		
		</div>
	
	
	</div>
	
	
	
	
	
	
	
	<!----Foter Section---->
	<?php include 'php/footer.php'; ?>  

</body> 

</html>