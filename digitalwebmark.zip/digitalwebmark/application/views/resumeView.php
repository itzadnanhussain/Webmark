 <!----Content Section---->
 <div class="container" id="location">
     <!---------------------Row 2--->
     <div class="row">
         <div class="col-md-12 col-sm-12">
             <!----=============================Form HTML==================================-->
             <div class="form_main margin-left">
                 <div class="formstatus"></div>
                 <h3 class="heading">Applicants Resume</h3>
                 <div class="form">
                     <iframe src="<?php echo base_url('uploads/' . $file) ?>" id="pdf" frameborder="0"></iframe> 
                     <style>
                         #pdf {
                             width: 100%;
                             height: 700px;
                         }
                     </style>
                 </div>
             </div>
         </div>


     </div>
 </div>
 <br>
 <div class="container-fluid">
     <div class="row">
         <div class="col-md-12 col-sm-12">
             <p>
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.7139739335316!2d55.275120614420096!3d25.21286658388894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f428e9e514339%3A0x4ea8ae12477feeaa!2sAl+Attar+Tower!5e0!3m2!1sen!2s!4v1545891065301" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

             </p>
         </div>
     </div>
 </div>