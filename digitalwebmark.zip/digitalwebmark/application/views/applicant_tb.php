<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col" class="text-center">App_id</th>
                        <th scope="col" class="text-center">Name</th>
                        <th scope="col" class="text-center">Phone</th>
                        <th scope="col" class="text-center">Email</th>
                        <th scope="col" class="text-center">Date</th>
                        <th scope="col" class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (isset($records) && !empty($records)) { ?>
                        <?php foreach ($records as $key => $value) { ?>

                            <tr>
                                <th scope="row"><?php echo $value->id ?></th>
                                <td><?php echo $value->name ?></td>
                                <td><?php echo $value->phone ?></td>
                                <td><?php echo $value->email ?></td>
                                <td><?php echo $value->date ?></td>
                                <td class="text-center">
                                    <a href="<?php echo base_url('resume/' . $value->resume_name) ?>" target="_blank"><i class="fas fa-file-alt icon"></i> </a>
                                    <a href="<?php echo base_url('career/clients/'.$value->id) ?>" target="_blank"><i class="fas fa-eye icon"></i> </a>
                                    <a href="<?php echo base_url('download/' . $value->resume_name) ?>"><i class="fas fa-download icon"></i> </a>
                                    <a href="javascript:void(0)" onclick="archiveFunction(<?php echo $value->id ?>)">
                                        <i class="fas fa-trash-alt icon"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php }  ?>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">

<script>
    function archiveFunction(id) {
        event.preventDefault(); // prevent form submit
        var form = event.target.form; // storing the form
        swal({
                title: "Are you sure?",
                text: "You Want Delete It",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, Delete it!",
                cancelButtonText: "No, Cancel!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url('admin/delete') ?>',
                        data: {
                            table: 'applicantstable',
                            id: id,
                        },
                        success: function(response) {
                            let res = JSON.parse(response);
                            if (res.code == 'done') {
                                window.location.reload();

                            }


                        }
                    }) // submitting the form when user press yes
                } else {
                    swal("Cancelled", "Your file is safe :)", "error");
                }
            });
    }
</script>
<style type="text/css">
    td>a {
        margin-right: 5px;
    }

    .fa-trash-alt {
        color: red;

    }

    .fa-download {
        color: #002034 !important;
    }

    .icon {
        margin-right: 15px;
        padding: 5px;
        background-color: gainsboro;
        border: 1px solid;
        border-radius: 4px;
        font-size: 16px;
    }
    a:hover
    {
        text-decoration: none !important;
    }
    .icon:hover
    {
        text-decoration: none !important;
    }
    table>thead>tr>th
    {
        background: linear-gradient(90deg,#002034 4%,#002c47 100%);
    color: aliceblue;
    }
</style>