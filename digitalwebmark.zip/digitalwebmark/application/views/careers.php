<div class="container-fluid">
    <div class="center careers">
        <h1>Become an insider</h1>
    </div>
</div>
<!----Content Section---->
<div class="container" id="location">
    <!---------------------Row 2--->
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <!----=============================Form HTML==================================-->
            <div class="form_main margin-left">
                <div class="formstatus"></div>
                <h3 class="heading">Application form</h3>
                <div class="form">
                    <form id="careerForm">
                        <div class=form-group>
                            <input type="text" placeholder="Name" name="name" class="form_txt_ctrl">
                        </div>
                        <div class="form-group"> 
                            <input type="text" placeholder="Mobile No" name="phone" class="form_txt_ctrl phone" >
                        </div>
                        <div class="form-group"> 
                            <input type="text" placeholder="Email" name="email" class="form_txt_ctrl">
                        </div>
                        <div class="form-group"> 
                            <input type="text" placeholder="Address" name="address" class="form_txt_ctrl">
                        </div>

                        <div class="skillset form_txt_ctrl">
                            <div class="row">
                                <div class="col-md-3">
                                    <b>Skill set:</b>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="html" id="html" name="skills[]" onclick="checkskill(this)">HTML</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="css3" id="css3" name="skills[]" onclick="checkskill(this)">CSS3</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="bs" id="bs" name="skills[]" onclick="checkskill(this)">Bootstrap</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="js" id="js" name="skills[]" onclick="checkskill(this)">Javascript</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="jq" id="jq" name="skills[]" onclick="checkskill(this)">Jquery</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="php" id="php" name="skills[]" onclick="checkskill(this)">PHP</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="ci" id="ci" name="skills[]" onclick="checkskill(this)">CodeIgniter</label>
                                    </div>
                                </div>
                                <div class="col-md-9 skilllevel">
                                    <b>Expertise level:</b>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="html_level" id="html_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="html_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="html_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="html_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="css3_level" id="css3_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="css3_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="css3_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="css3_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="bs_level" id="bs_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="bs_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="bs_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="bs_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="js_level" id="js_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="js_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="js_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="js_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="jq_level" id="jq_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="jq_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="jq_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="jq_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="php_level" id="php_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="php_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="php_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="php_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" name="ci_level" id="ci_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" name="ci_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" name="ci_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" name="ci_level">Professional</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group"> 
                            <textarea placeholder="Why should we hire you?" name="whyhire" type="text" class="form_txt_ctrl"></textarea>
                        </div>

                        <label class="form_txt_ctrl resume">Attach your resume (pdf files only) <input type="file" name="resume"></label>

                        <input type="submit" id="submit-btn" value="submit" name="submit" class="default-btn">
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <p>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.7139739335316!2d55.275120614420096!3d25.21286658388894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f428e9e514339%3A0x4ea8ae12477feeaa!2sAl+Attar+Tower!5e0!3m2!1sen!2s!4v1545891065301" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

            </p>
        </div>
    </div>
</div>


<script>
    var message = `<?php echo $this->session->userdata('message'); ?>`;
    if (message.length > 1) {
        var datavalues = message.split('-');
        $(".formstatus").empty();
        $(".formstatus").append('<p>' + datavalues[0] + '</p>');
        $(".formstatus").children().css("color", datavalues[1]);
        $(".formstatus").children().css("background-color", "#e0ebeb");
        $(".formstatus").show().delay(4000).fadeOut();
    }

    ///submit Event
    $('#careerForm').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = new FormData($(this)[0]);
        //check validation  
        $.ajax({
            beforeSend: function()
            {
                $('#submit-btn').val('Processing...');
            },
            type: 'POST',
            data: form,
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        swal('Success', res.message, 'success', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.reload();
                        }, 3000)

                        break;
                    case 'warning':
                        swal('Warning', res.message, 'warning', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.reload();
                        }, 3000)

                        break;

                    case 'error':
                        res.message.forEach(function(error) {
                            $('[name=' + error[0] + ']').parent().append('<p style="color:red;font-size:12px">' + error[1] + '</p>');
                        })
                        break;

                }

            },
            complete: function()
            {
                $('#submit-btn').val('Submit');
            },
            cache: false,
            contentType: false,
            processData: false
        });
    })
</script>