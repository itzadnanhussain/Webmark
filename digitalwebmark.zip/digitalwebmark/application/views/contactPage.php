<div class="container-fluid">
    <div class="banner center">
        <h1>Contact Us Friendly</h1>
    </div>
</div>
<!----Content Section---->
<div class="container" id="location">
    <!---------------------Row 1--->
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <h2 class="text-center">We Are Located Here:</h2>
        </div>
        <div class="col-md-6"></div>
    </div>
    <!---------------------Row 2--->
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <h2 class="text-left">
                Dubai
            </h2>
            <p><i class="icon-location"></i> Al Attar Tower, sheikh zayed road</p>
        </div>
        <div class="col-md-6 col-sm-12">
            <!----=============================Form HTML==================================-->
            <div class="form_main margin-left">
                <h3 class="heading">Contact us</h3>
                <div class="form">
                    <form id="contactform">
                        <input type="text" placeholder="Please input your Name" name="name" class="form_txt_ctrl">
                        <input type="text" placeholder="Please input your mobile No" name="phone" class="form_txt_ctrl">
                        <input type="email" placeholder="Please input your Email" name="email" class="form_txt_ctrl">
                        <input type="text" placeholder="Please input your Address" name="address" class="form_txt_ctrl">
                        <textarea placeholder="Your Message" name="message" type="text" class="form_txt_ctrl"></textarea>
                        <input type="submit" value="submit" name="submit" class="default-btn" id="submit-btn">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <p>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.7139739335316!2d55.275120614420096!3d25.21286658388894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f428e9e514339%3A0x4ea8ae12477feeaa!2sAl+Attar+Tower!5e0!3m2!1sen!2s!4v1545891065301" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

            </p>
        </div>
    </div>
</div>
<script>
    ///submit Event
    $('#contactform').submit(function(e) {
        e.preventDefault();
        e.stopPropagation();
        let form = $(this).serialize();
        //check validation  
        $.ajax({
            beforeSend: function() {
                $('#submit-btn').val('Processing...');
            },
            type: 'POST',
            url: '<?php echo base_url('sendMail'); ?>',
            data: form,
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        swal('Success', res.message, 'success', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.reload();
                        }, 3000)

                        break;
                    case 'warning':
                        swal('Warning', res.message, 'warning', {
                            buttons: false,
                        });
                        setTimeout(function() {
                            window.location.reload();
                        }, 3000)

                        break;

                    case 'error':
                        res.message.forEach(function(error) {
                            $('[name=' + error[0] + ']').parent().append('<p style="color:red;font-size:12px">' + error[1] + '</p>');
                        })
                        break;

                }

            },
            complete: function() {
                $('#submit-btn').val('Submit');
            },

        });
    })
</script>