 
<!----Content Section---->
<div class="container" id="location">
    <!---------------------Row 2--->
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <!----=============================Form HTML==================================-->
            <div class="form_main margin-left">
                <div class="formstatus"></div>
                <h3 class="heading">View Details Of Customer</h3>
                <div class="form">
                    <form id="careerForm">
                        <div class=form-group>
                            
                            <input type="text" value="<?php echo (isset($records[0]->name)) ? $records[0]->name : 'No value' ?>" class="form_txt_ctrl" disabled>
                        </div>
                        <div class="form-group"> 
                            <input type="text" value="<?php echo (isset($records[0]->phone)) ? $records[0]->phone : 'No value' ?>" class="form_txt_ctrl" disabled>
                        </div>
                        <div class="form-group"> 
                            <input type="text" value="<?php echo (isset($records[0]->email)) ? $records[0]->email : 'No value' ?>" class="form_txt_ctrl" disabled>
                        </div>
                        <div class="form-group"> 
                            <input type="text" value="<?php echo (isset($records[0]->address)) ? $records[0]->address : 'No value' ?>" class="form_txt_ctrl" disabled>
                        </div>

                        <div class="skillset form_txt_ctrl">
                            <div class="row">
                                <div class="col-md-3">
                                    <b>Skill set:</b>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="html" <?php echo ((strpos($records[0]->skills, 'HTML') == true)) ? 'checked' :'disabled' ?> id="html" name="skills[]" onclick="checkskill(this)" >HTML</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="css3" <?php echo ((strpos($records[0]->skills, 'CSS3') == true)) ? 'checked' :'disabled' ?> id="css3" name="skills[]" onclick="checkskill(this)">CSS3</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="bs" <?php echo ((strpos($records[0]->skills, 'Bootstrap') == true)) ? 'checked' :'disabled' ?> id="bs" name="skills[]" onclick="checkskill(this)">Bootstrap</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="js" <?php echo ((strpos($records[0]->skills, 'Javascript') == true)) ? 'checked' :'disabled' ?> id="js" name="skills[]" onclick="checkskill(this)">Javascript</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="jq" <?php echo ((strpos($records[0]->skills, 'Jquery') == true)) ? 'checked' :'disabled' ?> id="jq" name="skills[]" onclick="checkskill(this)">Jquery</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="php" <?php echo ((strpos($records[0]->skills, 'PHP') == true)) ? 'checked' :'disabled' ?> id="php" name="skills[]" onclick="checkskill(this)">PHP</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="ci" <?php echo ((strpos($records[0]->skills, 'Codeigniter') == true)) ? 'checked' :'disabled' ?> id="ci" name="skills[]" onclick="checkskill(this)">CodeIgniter</label>
                                    </div>
                                </div>
                                <div class="col-md-9 skilllevel">
                                    <b>Expertise level:</b>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'HTML: Beginner') == true)) ? 'checked' :'disabled' ?> name="html_level" id="html_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'HTML: Familiar') == true)) ? 'checked' :'disabled' ?> name="html_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'HTML: Intermediate') == true)) ? 'checked' :'disabled' ?>  name="html_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'HTML: Professional') == true)) ? 'checked' :'disabled' ?> name="html_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'CSS3: Beginner') == true)) ? 'checked' :'disabled' ?> name="css3_level" id="css3_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'CSS3: Familiar') == true)) ? 'checked' :'disabled' ?> name="css3_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'CSS3: Intermediate') == true)) ? 'checked' :'disabled' ?> name="css3_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'CSS3: Professional') == true)) ? 'checked' :'disabled' ?> name="css3_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'Bootstrap: Beginner') == true)) ? 'checked' :'disabled' ?> name="bs_level" id="bs_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'Bootstrap: Familiar') == true)) ? 'checked' :'disabled' ?> name="bs_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'Bootstrap: Intermediate') == true)) ? 'checked' :'disabled' ?> name="bs_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'Bootstrap: Professional') == true)) ? 'checked' :'disabled' ?> name="bs_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'Javascript: Beginner') == true)) ? 'checked' :'disabled' ?> name="js_level" id="js_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'Javascript: Familiar') == true)) ? 'checked' :'disabled' ?> name="js_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'Javascript: Intermediate') == true)) ? 'checked' :'disabled' ?> name="js_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'Javascript: Professional') == true)) ? 'checked' :'disabled' ?> name="js_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'Jquery: Beginner') == true)) ? 'checked' :'disabled' ?> name="jq_level" id="jq_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'Jquery: Familiar') == true)) ? 'checked' :'disabled' ?> name="jq_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'Jquery: Intermediate') == true)) ? 'checked' :'disabled' ?> name="jq_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'Jquery: Professional') == true)) ? 'checked' :'disabled' ?> name="jq_level">Professional</label>
                                    </div>


                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'PHP: Beginner') == true)) ? 'checked' :'disabled' ?> name="php_level" id="php_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'PHP: Familiar') == true)) ? 'checked' :'disabled' ?> name="php_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'PHP: Intermediate') == true)) ? 'checked' :'disabled' ?> name="php_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'PHP: Professional') == true)) ? 'checked' :'disabled' ?> name="php_level">Professional</label>
                                    </div>
                                    <div class="checkbox">
                                        <label><input type="checkbox" value="Beginner" <?php echo ((strpos($records[0]->skills, 'Codeigniter: Beginner') == true)) ? 'checked' :'disabled' ?> name="ci_level" id="ci_level">Beginner</label>
                                        <label><input type="checkbox" value="Familiar" <?php echo ((strpos($records[0]->skills, 'Codeigniter: Familiar') == true)) ? 'checked' :'disabled' ?> name="ci_level">Familiar</label>
                                        <label><input type="checkbox" value="Intermediate" <?php echo ((strpos($records[0]->skills, 'Codeigniter: Intermediate') == true)) ? 'checked' :'disabled' ?> name="ci_level">Intermediate</label>
                                        <label><input type="checkbox" value="Professional" <?php echo ((strpos($records[0]->skills, 'Codeigniter: Professional') == true)) ? 'checked' :'disabled' ?> name="ci_level">Professional</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group"> 
                            <textarea class="form_txt_ctrl" disabled><?php echo (isset($records[0]->whyhire)) ? $records[0]->whyhire : 'No value' ?></textarea>
                        </div> 
                        <a href="<?php echo base_url('applicants') ?>" id="submit-btn" class="default-btn">Back</a>
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
<br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            <p>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.7139739335316!2d55.275120614420096!3d25.21286658388894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f428e9e514339%3A0x4ea8ae12477feeaa!2sAl+Attar+Tower!5e0!3m2!1sen!2s!4v1545891065301" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

            </p>
        </div>
    </div>
</div>