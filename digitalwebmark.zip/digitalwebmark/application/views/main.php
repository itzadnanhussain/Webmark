
<div class="slider-container" id="slider">
    <div id="particles-js" class="animated fadeIn">
    </div>
    <div class="heading-index">
        <div class="animate-header" id="typewriter">
        </div><br>
        <h1>DigitalWebMark - Leading web design, SEO and digital marketing company in Dubai
        </h1>
        <div class="animated bounceInUp margin-top"><a class="default-btn" href="getQuoteForm.php">Get Your Quote</a></div>
    </div>
</div>
 <div class="container-fluid padding ">
     <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-12 col-lg-6">
                <img class="img-responsive img_company" src="<?php echo base_url()?>assets/img/About-Company/company.jpg" alt="Digitalwebmark - web design company in Dubai">
            </div>
            <div class="col-md-6 col-sm-12 col-lg-6 "id="margin">
                <div class="heading"><h2>About DigitalWebMark</h2></div>
                
                <p> We are one team and maintain democracy on all services. Being for over five years in digital marketing, SEO and web design in Dubai, DigitalWebMark have held creative and  experienced professional web developers, content creators and online digital marketers. 
                </p>
                  <h3 class="h4">We Offer:</h3>
                   <p>
                    Our company offers responsive web design with impressive search engine friendly content. We also make custom website according to the client needs. when it comes to SEO, We guarantee top 5 bands in Google organic or local rankings moreover our digital marketing service will boost your business up to next level.</p>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="company-advertising">
                            <ul class="list-inline">
                                <li class="list-inline-item"><i class="icon-checkmark" aria-hidden="true"></i> Free Consultation 
                                </li>
                                <li class="list-inline-item"><i class="icon-checkmark" aria-hidden="true"></i> Free Client Support</li>
                                <li class="list-inline-item"><i class="icon-checkmark" aria-hidden="true"></i> 24/7 Service</li>
                            </ul>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
 </div>
 <section class="padding">
    <div class="container">
        <!--Row 1-->
        <div class="row">
            <div class="heading">
                <h2>Our Web design Services in Dubai</h2>
            </div>
        </div>
        <!--Row 2-->
        <div class="row col-padding services center">
            <!--column 1---->
            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
                <span class="icon-webdesign icon-size default-color"></span><h3 class="h4" class="text-right"> WEB DESIGN &amp; DEVELOPMENT</h3>
                <p class="text-justify">
                    We provide responsive web design with the optimal layout on every screen. Our dedicated team of professional web designers creates custom online solutions. We adopt special strategies for website performance. We always develop dynamic websites, which are easy for the clients to manage after development.
                </p>
                <span class="icon-ecommerce icon-size default-color"></span><h3 class="h4" class="text-right"> ECOMMERCE Web design</h3>
                <p class="text-justify">
                    We are expert in Wordpress, PHP, Nodejs, Asp.Net and Laravel. We Build highly attractive and top performance e-commerce websites. In B2B e-commerce sites we maintain and improve scalability, efficiency, brand awareness and analytics. We also develop custom e-commerce websites according to client's demands.
                </p>
                <span class="icon-adwords icon-size default-color"></span><h3 class="h4" class="text-right"> GOOGLE ADWORDS</h3>
                <p class="text-justify">
                    We improve the visibility of your website by using Google Adwords. Increase in your brand awareness brings instant traffic. We are expert in selecting right keywords which will increase to productivity of the clicks. We will also manage your PPC advertisement for a better return on investment.
                </p>
            </div>
            <div class="col-md-4"><img class="img-responsive" src="<?php echo base_url()?>assets/img/services/platform-service.jpg" alt="web design services by  Digitalwebmark"></div>
            <div class="col-sm-12 col-xs-12 col-md-4 col-lg-4">

                <span class="icon-Blog icon-size default-color"></span><h3 class="h4" class="text-left"> CONTENT WRITING</h3>
                <p class="text-justify">
                    Quality of the content have a great impact on ranking. Our team holds fresh, high-quality content writers, who focus on right keywords for better ranking thus better business. DigitalWebMark also take complex ideas and concise them into easy-to understand language for the comfort of the readers</p>
                <span class="icon-digital icon-size default-color"></span><h3 class="h4" class="text-left"> DIGITAL MARKETING</h3>
                <p class="text-justify">
                    We maintain the ability to transform the way that you reach and engage your clients in Dubai. We provide the most cost-effective ways to explore and enhance your business. Our digital marketing techniques ensures that right clients are seeing your content so that the success rate of clients remain high.
                </p>
                <span class="icon-seo icon-size default-color"></span><h3 class="h4" class="text-left"> SEO</h3>

                <p class="text-justify">
                    Without SEO, clients may never now about your website as it will never appear in Dubai search results. Our SEO services promise improving your rankings in search engine results. We guarantee to rank in top five band in less than six months for organic or local Google rankings . We will also optimize your site performance so that it loads faster.
                </p>
            </div>
        </div>
    </div>
</section>
        <div class="counter center">
            <div class="container">
                    <div class="col-md-4 col-sm-6" >
                        <label class="number" style="color: palegoldenrod;"><span class="count">10</span>+</label>
                        <h2 class="count-title" style="color: rgb(221, 221, 221);"><span>YEARS</span><br>
                            OF EXPERIENCE</h2>
                    </div>
                    <!-- .stat -->

                    <div class="col-md-4 col-sm-6">
                        <label class="number" style="color: palegoldenrod;"><span class="count">15</span>+</label>
                        <h2 class="count-title" style="color: rgb(221, 221, 221);">INDUSTRIES<br>
                            SERVED</h2>
                    </div>
                    <!-- .stat -->

                    <div class="col-md-4">
                        <label class="number" style="color: palegoldenrod;"><span class="count">300</span>+</label>
                        <h2 class="count-title" style="color: rgb(221, 221, 221);">SATISFIED<br>
                            CLIENTS</h2>
                    </div>
            <!--END OF CONTAINER-->
        </div>
        </div>
 <section  class="padding">
     <div class="container">
                 <div class="heading">
                     <h2 class="text-center">Our web development Process</h2>
                 </div>
         <div class="row process center">
             <div class="col-md-3 col-sm-12">
                 <span class="icon-requirement default-color icon-size" aria-hidden="true"></span><h3 class="h4"> Gather requirements</h3>
                 <p>In the first step, we will gather website requirements in detail for better understanding.</p>
             </div>
             <div class="col-md-3 col-sm-12">

                 <span class="icon-milestone default-color icon-size"></span><h3 class="h4"> Strategic Planning</h3>
                 <p>Next, we construct milestones after a complete analysis of your requirements</p>
             </div>
             <div class="col-md-3 col-sm-12">

                 <span class="icon-development default-color icon-size" aria-hidden="true"></span><h3 class="h4">  Design &amp; Develop</h3>
                 <p>We will design as you want with regular response and frequent updates.
                 </p>
             </div>
             <div class="col-md-3 col-sm-12">
                 <span class="icon-support default-color icon-size" aria-hidden="true"></span><h3 class="h4">  Support</h3>
                 <p>After development, our team offers full support whenever you face issues. </p>
             </div>
         </div>
     </div>

 </section>

<section  class="padding"><!--------------Block 1--------> 
    <div class="container">
        <!-------Row 1-->
                <div class="heading">
                    <h2 class="text-center">
                        Web design Industries We hold in Dubai 
                    </h2> 
                </div>
            <!-------column 1-->
            <div class="ind-1">
                <ul class="nav nav-tabs">
                    <li>
                        <a href="#Automotive" data-toggle="tab" class="active show"><i class="icon-automobile"></i>
                            Automotive
                        </a>
                    </li>
                    <li><a href="#b2b" data-toggle="tab" >
                            <i class="icon-credit-card "></i>
                            Business to Business
                        </a>
                    </li>
                    <li><a href="#Mortgage" data-toggle="tab" >
                            <i class="icon-library"></i>
                            Mortgage &amp; Accounting
                        </a>
                    </li>
                    <li><a href="#b2c" data-toggle="tab" >
                            <i class="icon-dollar"></i>
                            Business to Consumer
                        </a>
                    </li>
                    <li><a href="#Education" data-toggle="tab" >
                            <i class="icon-hat"></i>
                            Education
                        </a>
                    </li> 
                </ul> 
            </div>
            <!-------colmn 2-->
            <div class="tab-content">
                <!--------P1111------->
                <div class="tab-pane animated fadeIn active show" id="Automotive">
                    <p>Automotive industry is the one of the leading industry in today's era. DigitalWebMark understands the need that Dubai industry is well populated by many brands so professional, state of the art websites, good SEO and digital marketing campaigns are required to show visibility of brand world wide. </p>
                </div>
                <div class="tab-pane animated fadeIn" id="b2b">
                    <!--------P22222------->
                    <p>Business to Business or B2B is a field where an industry selling products to another business company. Professional skills are needed to develop and manage  B2B digital marketing as companies will like to buy products will only buy from legitmate looking websites. Web design also play an important role because of Populated Dubai's B2B platform.</p>
                </div>
                <div class="tab-pane animated fadeIn" id="Mortgage">
                    <!--------P333333------->
                    <p>Mortgage and accounting are the rising fields as almost all business holders use them to establish the business. Mortgage and accounting websites are to be developed by professionals as the proper calculations of expenditures and profits will ensure the success of the business. DigitalWebMark has stat of the art accountants and economists to help you with all the business situations. </p>
                </div>
                <div class="tab-pane animated fadeIn" id="b2c">
                    <!--------P4444444------->
                    <p>Business to Consumer or B2C refer to services which are directly between clients and companies and the transactions are also direct. B2C websites are developed in artistic manner that clients gets what he searched for in minimum possible time and effort. Filters, sorting and preferences are also key features when it comes to searching within  B2C website. Without digital marketing and SEO these websites will fail as no costumer will find the products online. if you are seeking B2C website design company in Dubai, DigitalWebMark comes on top with years of experience and expertise. Just call for a free consultation today.</p>
                </div>
                <div class="tab-pane animated fadeIn" id="Education">
                    <!--------P6666666------->
                    <p>Education and learning websites are also making investments now a days. Education websites focus on relevant knowledge preferences to the user's liking along with proper searching mechanism. These websites are normally global for every continent and the material provided is applicable world wide. Efficiency and fast loading of web design is key performance evaluation element in this domain.</p>
                </div> 
            </div>
        <!------------------------Row 3 block two content------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
             <!-------colmn 1-->
            <div class="ind-1 margin-top">
                <ul class="nav nav-tabs">
                    <li>
                        <a href="#e-Commerce" data-toggle="tab" class="active show">
                            <i class="icon-cart"></i> E - Commerce	
                        </a>
                    </li>
                    <li >
                        <a href="#medical" data-toggle="tab">
                            <i class="icon-medical"></i>
                            Medical and Health Care			
                        </a>
                    </li>
                    <li >
                        <a href="#food" data-toggle="tab">
                            <i class="icon-coffee"></i>
                            Food &amp; Beverage					
                        </a>
                    </li>
                    <li >
                        <a href="#real" data-toggle="tab" >
                            <i class="icon-home"></i>
                            Real Estate					
                        </a>
                    </li>
                    <li >
                        <a href="#entertain" data-toggle="tab">
                            <i class="icon-music"></i>
                            Entertainment					
                        </a>
                    </li> 
                </ul> 
            </div>
              <!-------colmn 2--> 
              <div class="tab-content">
                <!--------P1111------->
                <div class="tab-pane animated fadeIn active" id="e-Commerce">
                    <p>E-commerce website development is a leading business domain today. About 61% of the Google searches are made to e-commerce websites. Advanced features like voice search, filters on search, responsiveness and many more important features are now important part of every successful key e-commerce website. DigitalWebMark not only develop responsive web design which are fast and efficient but also loaded with advanced technologies. We can develop according to your needs whether you want template built like using Shopify or Woo commerce or custom website.</p>
                </div>
                <div class="tab-pane animated fadeIn" id="medical">
                    <!--------P22222------->
                    <p>Medical and health care websites are becoming popular because of the need of first aid or general knowledge to proper doctor counseling online. Medical websites are now packed with automatic bot counselor which helps to deal with the emergencies and call for the doctor's help if needed. we not only develop these websites but also handles the plugins performance so that patients face no issues getting medical help online.</p>
                </div>
                <div class="tab-pane animated fadeIn" id="food">
                    <!--------P333333------->
                    <p>
                        Food and beverages is an interesting domain for business. Its active B2C service and instant profit domain. 13 Billion investment reached in 2018 in UAE in which Dubai is a big market for this kind of businesses. DigitalWebMark not only develop attractive websites for these businesses.
                    </p>
                </div>
                <div class="tab-pane animated fadeIn" id="real">
                    <!--------P555555------->
                    <p> 
                        Properties along with its natural resources are involved in real estate. Social marketing is an important aspect and DigitalWebMark is always available for counseling and total guidance.
                    </p>
                </div>
                <div class="tab-pane animated fadeIn" id="entertain">
                    <!--------P6666666------->
                    <p>
                        Every one tired from work will look for closest venue for entertainment and online entertainment is always been the closest. whether it is movie website or a gaming one, we have expert developers here in Dubai, UAE who will help you in any scenario along with the SEO  and marketing.
                    </p>
                </div> 
            </div>   
        </div> 
</section>

<section class="padding">
    <div class="container">
        <div class="heading">
            <h2>CHECK OUR AWESOME PORTFOLIO</h2>
        </div>
        <!--  portfolio link button -->
        <div class="center">
            <a class="default-btn" href="portfolioPage.php">View Complete Portfolio</a>
        </div>
        <!--column 1--->
        <div class="row margin-top">
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="green-box">
                    <a href="#" class="caption" rel="nofollow">
                        <img src="<?php echo base_url()?>assets/img/portfolio/booking.jpg" alt="booking website" class="img-responsive">
                    </a>
                </div>
            </div>
            <!--column 2--->
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="green-box">
                    <a href="#" class="caption" rel="nofollow">
                        <img src="<?php echo base_url()?>assets/img/portfolio/etsy.jpg" alt="e-commerce website" class="img-responsive">
                    </a>
                </div>
            </div>
            <!--column 3--->
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="green-box">
                    <a href="#" class="caption" rel="nofollow">
                        <img src="<?php echo base_url()?>assets/img/portfolio/hotwire.jpg" alt="hotel booking web design" class="img-responsive">
                    </a>
                </div>
            </div>

            <!--column 4--->
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="green-box">
                    <a href="#" class="caption" rel="nofollow">
                        <img src="<?php echo base_url()?>assets/img/portfolio/harvey.jpg" alt="Online shopping website" class="img-responsive">
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
 <section class="padding">
     <div class="container">
         <div class="heading">
             <h2>Testimonials</h2>
         </div>
         <div class="owl-carousel owl-theme center" id="testimonial-list">
             <div>
                 <p >"Booking.com is an amazing and responsive website for me. It is secured and filled with full of high-quality functionality .
                     DigitalWebMark understood consciously all my related business requirements and developed awesome website according to my specifications within time"
                 </p>
                 <h5>Mr. Jones</h5>
                 <h5>Director at <span class="blue">booking.com</span></h5>

                 <span class="star">
                     <span class="icon-star-full checked"></span>
                     <span class="icon-star-full checked"></span>
                     <span class="icon-star-full checked"></span>
                     <span class="icon-star-full checked"></span>
                     <span class="icon-star-half checked"></span>
                 </span>
             </div>
         </div>
     </div>
 </section>
<section class="padding">
    <div class="container">
        <div class="heading">
            <h2>Why only us:</h2>

        </div>

        <div class="owl-carousel owl-theme center" id="why-us-list">
            <div class="why-us-shadow">
                <img class="img-responsive" src="<?php echo base_url()?>assets/img/why-us/web.jpg" />
                <p>Online presence boosts number of prospects locally and internationally <br><a href="SearchEngineOptimization.php">Learn More</a>
                </p>
            </div>
            <div class="why-us-shadow">
                <img class="img-responsive" src="<?php echo base_url()?>assets/img/why-us/roi.jpg" />
                <p>Guaranteed ROI by increasing your visibility online <br><a href="SearchEngineOptimization.php">Learn More</a>
                </p>
            </div>
            <div class="why-us-shadow">
                <img class="img-responsive" src="<?php echo base_url()?>assets/img/why-us/seo.jpg" />
                <p>Increased lead generation though Search engine optimization (SEO) <br><a href="SearchEngineOptimization.php">Learn More</a>
                </p>
            </div>
            <div class="why-us-shadow">
                <img class="img-responsive" src="<?php echo base_url()?>assets/img/why-us/digitalmarketing.jpg" />
                <p>Niche Marketing for cost effective lead generation <br><a href="SearchEngineOptimization.php">Learn More</a>
                </p>
            </div>
            <div class="why-us-shadow">
                <img class="img-responsive" src="<?php echo base_url()?>assets/img/why-us/content.jpg" />
                <p>Quality content writing with no keyword stuffing <br><a href="SearchEngineOptimization.php">Learn More</a>
                </p>
            </div>
        </div>
    </div>
</section>




<script>
    var i = 0;
    var txt = 'Boost Your Web Presence...';
    var speed = 80;

    function typeWriter() {
        if (i < txt.length) {
            document.getElementById("typewriter").innerHTML += txt.charAt(i);
            i++;
            setTimeout(typeWriter, speed);
        }
    }
    window.onload = typeWriter;
</script>

    <script>
        /******Below code is only for index page*******/
    <?php
        /******Particle Plugins*******/
        include getcwd().'/assets/js/particles.min.js';
        include getcwd().'/assets/js/app.js';
        /******Particle Plugins********/
        include getcwd().'/assets/js/owl.carousel.min.js';
        include getcwd().'/assets/js/wow.min.js';
    ?>
        new WOW().init();
        /*testimonials-*/
        $(function() {
            $("#testimonial-list").owlCarousel({
                items: 1,
                autoplay: 1000,
                slideSpeed: 10000,
                infinityloop: true,
                autoplayHoverPause: true,
            });

        });
        /*why-us-*/
        $(function() {
            
            items=0;
            if ($(window).width() < 500) {
                items=1;
            }
            else if ($(window).width() < 768) {
                items=2;
            }
            else if ($(window).width() < 960) {
                items=3;
            }
            else{
                items=3;
            }
            $("#why-us-list").owlCarousel({
                items: items,
                autoplay: 1000,
                slideSpeed: 10000,
                infinityloop: true,
                autoplayHoverPause: true,
            });

        });
    </script>




<!--<div class="wrapper fadeInDown">
  <div id="formContent">
     Tabs Titles 


    <div class="fadeIn first">
      <h4>User Login</h4>
    </div>

    <form>
      <input type="text" id="login" class="fadeIn second frmctrl" name="User Name" placeholder="username">
      <input type="password" id="password" class="fadeIn third frmctrl" name="login" placeholder="Password">
      <input type="submit" class="fadeIn fourth btn-success" value="Log In">
    </form>


    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>-->